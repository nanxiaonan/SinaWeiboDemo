/*   1:    */ package com.sina.sso;
/*   2:    */ 
/*   3:    */ import android.os.Binder;
/*   4:    */ import android.os.IBinder;
/*   5:    */ import android.os.IInterface;
/*   6:    */ import android.os.Parcel;
/*   7:    */ import android.os.RemoteException;
/*   8:    */ 
/*   9:    */ public abstract interface RemoteSSO
/*  10:    */   extends IInterface
/*  11:    */ {
/*  12:    */   public abstract String getPackageName()
/*  13:    */     throws RemoteException;
/*  14:    */   
/*  15:    */   public abstract String getActivityName()
/*  16:    */     throws RemoteException;
/*  17:    */   
/*  18:    */   public abstract String getLoginUserName()
/*  19:    */     throws RemoteException;
/*  20:    */   
/*  21:    */   public static abstract class Stub
/*  22:    */     extends Binder
/*  23:    */     implements RemoteSSO
/*  24:    */   {
/*  25:    */     private static final String DESCRIPTOR = "com.sina.sso.RemoteSSO";
/*  26:    */     static final int TRANSACTION_getPackageName = 1;
/*  27:    */     static final int TRANSACTION_getActivityName = 2;
/*  28:    */     static final int TRANSACTION_getLoginUserName = 3;
/*  29:    */     
/*  30:    */     public Stub()
/*  31:    */     {
/*  32: 15 */       attachInterface(this, "com.sina.sso.RemoteSSO");
/*  33:    */     }
/*  34:    */     
/*  35:    */     public static RemoteSSO asInterface(IBinder obj)
/*  36:    */     {
/*  37: 23 */       if (obj == null) {
/*  38: 24 */         return null;
/*  39:    */       }
/*  40: 26 */       IInterface iin = obj.queryLocalInterface("com.sina.sso.RemoteSSO");
/*  41: 27 */       if ((iin != null) && ((iin instanceof RemoteSSO))) {
/*  42: 28 */         return (RemoteSSO)iin;
/*  43:    */       }
/*  44: 30 */       return new Proxy(obj);
/*  45:    */     }
/*  46:    */     
/*  47:    */     public IBinder asBinder()
/*  48:    */     {
/*  49: 34 */       return this;
/*  50:    */     }
/*  51:    */     
/*  52:    */     public boolean onTransact(int code, Parcel data, Parcel reply, int flags)
/*  53:    */       throws RemoteException
/*  54:    */     {
/*  55: 38 */       switch (code)
/*  56:    */       {
/*  57:    */       case 1598968902: 
/*  58: 42 */         reply.writeString("com.sina.sso.RemoteSSO");
/*  59: 43 */         return true;
/*  60:    */       case 1: 
/*  61: 47 */         data.enforceInterface("com.sina.sso.RemoteSSO");
/*  62: 48 */         String _result = getPackageName();
/*  63: 49 */         reply.writeNoException();
/*  64: 50 */         reply.writeString(_result);
/*  65: 51 */         return true;
/*  66:    */       case 2: 
/*  67: 55 */         data.enforceInterface("com.sina.sso.RemoteSSO");
/*  68: 56 */         String _result = getActivityName();
/*  69: 57 */         reply.writeNoException();
/*  70: 58 */         reply.writeString(_result);
/*  71: 59 */         return true;
/*  72:    */       case 3: 
/*  73: 63 */         data.enforceInterface("com.sina.sso.RemoteSSO");
/*  74: 64 */         String _result = getLoginUserName();
/*  75: 65 */         reply.writeNoException();
/*  76: 66 */         reply.writeString(_result);
/*  77: 67 */         return true;
/*  78:    */       }
/*  79: 70 */       return super.onTransact(code, data, reply, flags);
/*  80:    */     }
/*  81:    */     
/*  82:    */     private static class Proxy
/*  83:    */       implements RemoteSSO
/*  84:    */     {
/*  85:    */       private IBinder mRemote;
/*  86:    */       
/*  87:    */       Proxy(IBinder remote)
/*  88:    */       {
/*  89: 77 */         this.mRemote = remote;
/*  90:    */       }
/*  91:    */       
/*  92:    */       public IBinder asBinder()
/*  93:    */       {
/*  94: 81 */         return this.mRemote;
/*  95:    */       }
/*  96:    */       
/*  97:    */       public String getInterfaceDescriptor()
/*  98:    */       {
/*  99: 85 */         return "com.sina.sso.RemoteSSO";
/* 100:    */       }
/* 101:    */       
/* 102:    */       public String getPackageName()
/* 103:    */         throws RemoteException
/* 104:    */       {
/* 105: 89 */         Parcel _data = Parcel.obtain();
/* 106: 90 */         Parcel _reply = Parcel.obtain();
/* 107:    */         String _result;
/* 108:    */         try
/* 109:    */         {
/* 110: 93 */           _data.writeInterfaceToken("com.sina.sso.RemoteSSO");
/* 111: 94 */           this.mRemote.transact(1, _data, _reply, 0);
/* 112: 95 */           _reply.readException();
/* 113: 96 */           _result = _reply.readString();
/* 114:    */         }
/* 115:    */         finally
/* 116:    */         {
/* 117:    */           String _result;
/* 118: 99 */           _reply.recycle();
/* 119:100 */           _data.recycle();
/* 120:    */         }
/* 121:102 */         return _result;
/* 122:    */       }
/* 123:    */       
/* 124:    */       public String getActivityName()
/* 125:    */         throws RemoteException
/* 126:    */       {
/* 127:106 */         Parcel _data = Parcel.obtain();
/* 128:107 */         Parcel _reply = Parcel.obtain();
/* 129:    */         String _result;
/* 130:    */         try
/* 131:    */         {
/* 132:110 */           _data.writeInterfaceToken("com.sina.sso.RemoteSSO");
/* 133:111 */           this.mRemote.transact(2, _data, _reply, 0);
/* 134:112 */           _reply.readException();
/* 135:113 */           _result = _reply.readString();
/* 136:    */         }
/* 137:    */         finally
/* 138:    */         {
/* 139:    */           String _result;
/* 140:116 */           _reply.recycle();
/* 141:117 */           _data.recycle();
/* 142:    */         }
/* 143:119 */         return _result;
/* 144:    */       }
/* 145:    */       
/* 146:    */       public String getLoginUserName()
/* 147:    */         throws RemoteException
/* 148:    */       {
/* 149:123 */         Parcel _data = Parcel.obtain();
/* 150:124 */         Parcel _reply = Parcel.obtain();
/* 151:    */         String _result;
/* 152:    */         try
/* 153:    */         {
/* 154:127 */           _data.writeInterfaceToken("com.sina.sso.RemoteSSO");
/* 155:128 */           this.mRemote.transact(3, _data, _reply, 0);
/* 156:129 */           _reply.readException();
/* 157:130 */           _result = _reply.readString();
/* 158:    */         }
/* 159:    */         finally
/* 160:    */         {
/* 161:    */           String _result;
/* 162:133 */           _reply.recycle();
/* 163:134 */           _data.recycle();
/* 164:    */         }
/* 165:136 */         return _result;
/* 166:    */       }
/* 167:    */     }
/* 168:    */   }
/* 169:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.sso.RemoteSSO
 * JD-Core Version:    0.7.0.1
 */