/*  1:   */ package com.sina.weibo.sdk.api;
/*  2:   */ 
/*  3:   */ import android.os.Parcel;
/*  4:   */ import android.os.Parcelable.Creator;
/*  5:   */ import android.text.TextUtils;
/*  6:   */ import org.json.JSONException;
/*  7:   */ import org.json.JSONObject;
/*  8:   */ 
/*  9:   */ public class WebpageObject
/* 10:   */   extends BaseMediaObject
/* 11:   */ {
/* 12:   */   public static final String EXTRA_KEY_DEFAULTTEXT = "extra_key_defaulttext";
/* 13:   */   public String defaultText;
/* 14:39 */   public static final Parcelable.Creator<WebpageObject> CREATOR = new Parcelable.Creator()
/* 15:   */   {
/* 16:   */     public WebpageObject createFromParcel(Parcel in)
/* 17:   */     {
/* 18:41 */       return new WebpageObject(in);
/* 19:   */     }
/* 20:   */     
/* 21:   */     public WebpageObject[] newArray(int size)
/* 22:   */     {
/* 23:45 */       return new WebpageObject[size];
/* 24:   */     }
/* 25:   */   };
/* 26:   */   
/* 27:   */   public WebpageObject() {}
/* 28:   */   
/* 29:   */   public WebpageObject(Parcel in)
/* 30:   */   {
/* 31:53 */     super(in);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void writeToParcel(Parcel dest, int flags)
/* 35:   */   {
/* 36:58 */     super.writeToParcel(dest, flags);
/* 37:   */   }
/* 38:   */   
/* 39:   */   public boolean checkArgs()
/* 40:   */   {
/* 41:63 */     if (!super.checkArgs()) {
/* 42:64 */       return false;
/* 43:   */     }
/* 44:66 */     return true;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public int getObjType()
/* 48:   */   {
/* 49:71 */     return 5;
/* 50:   */   }
/* 51:   */   
/* 52:   */   protected BaseMediaObject toExtraMediaObject(String str)
/* 53:   */   {
/* 54:76 */     if (!TextUtils.isEmpty(str)) {
/* 55:   */       try
/* 56:   */       {
/* 57:78 */         JSONObject json = new JSONObject(str);
/* 58:79 */         this.defaultText = json.optString("extra_key_defaulttext");
/* 59:   */       }
/* 60:   */       catch (JSONException localJSONException) {}
/* 61:   */     }
/* 62:83 */     return this;
/* 63:   */   }
/* 64:   */   
/* 65:   */   protected String toExtraMediaString()
/* 66:   */   {
/* 67:   */     try
/* 68:   */     {
/* 69:89 */       JSONObject json = new JSONObject();
/* 70:90 */       if (!TextUtils.isEmpty(this.defaultText)) {
/* 71:91 */         json.put("extra_key_defaulttext", this.defaultText);
/* 72:   */       }
/* 73:93 */       return json.toString();
/* 74:   */     }
/* 75:   */     catch (JSONException localJSONException) {}
/* 76:96 */     return "";
/* 77:   */   }
/* 78:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.WebpageObject
 * JD-Core Version:    0.7.0.1
 */