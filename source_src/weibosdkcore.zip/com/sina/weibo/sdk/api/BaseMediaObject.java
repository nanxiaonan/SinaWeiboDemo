/*   1:    */ package com.sina.weibo.sdk.api;
/*   2:    */ 
/*   3:    */ import android.graphics.Bitmap;
/*   4:    */ import android.graphics.Bitmap.CompressFormat;
/*   5:    */ import android.os.Parcel;
/*   6:    */ import android.os.Parcelable;
/*   7:    */ import com.sina.weibo.sdk.utils.LogUtil;
/*   8:    */ import java.io.ByteArrayOutputStream;
/*   9:    */ import java.io.IOException;
/*  10:    */ 
/*  11:    */ public abstract class BaseMediaObject
/*  12:    */   implements Parcelable
/*  13:    */ {
/*  14:    */   public static final int MEDIA_TYPE_TEXT = 1;
/*  15:    */   public static final int MEDIA_TYPE_IMAGE = 2;
/*  16:    */   public static final int MEDIA_TYPE_MUSIC = 3;
/*  17:    */   public static final int MEDIA_TYPE_VIDEO = 4;
/*  18:    */   public static final int MEDIA_TYPE_WEBPAGE = 5;
/*  19:    */   public static final int MEDIA_TYPE_VOICE = 6;
/*  20:    */   public static final int MEDIA_TYPE_CMD = 7;
/*  21:    */   public String actionUrl;
/*  22:    */   public String schema;
/*  23:    */   public String identify;
/*  24:    */   public String title;
/*  25:    */   public String description;
/*  26:    */   public byte[] thumbData;
/*  27:    */   
/*  28:    */   public BaseMediaObject() {}
/*  29:    */   
/*  30:    */   public BaseMediaObject(Parcel in)
/*  31:    */   {
/*  32: 77 */     this.actionUrl = in.readString();
/*  33: 78 */     this.schema = in.readString();
/*  34: 79 */     this.identify = in.readString();
/*  35: 80 */     this.title = in.readString();
/*  36: 81 */     this.description = in.readString();
/*  37: 82 */     this.thumbData = in.createByteArray();
/*  38:    */   }
/*  39:    */   
/*  40:    */   public final void setThumbImage(Bitmap bitmap)
/*  41:    */   {
/*  42: 92 */     ByteArrayOutputStream os = null;
/*  43:    */     try
/*  44:    */     {
/*  45: 94 */       os = new ByteArrayOutputStream();
/*  46: 95 */       bitmap.compress(Bitmap.CompressFormat.JPEG, 85, os);
/*  47: 96 */       this.thumbData = os.toByteArray();
/*  48:    */     }
/*  49:    */     catch (Exception e)
/*  50:    */     {
/*  51: 98 */       e.printStackTrace();
/*  52: 99 */       LogUtil.e("Weibo.BaseMediaObject", "put thumb failed");
/*  53:    */       try
/*  54:    */       {
/*  55:102 */         if (os != null) {
/*  56:103 */           os.close();
/*  57:    */         }
/*  58:    */       }
/*  59:    */       catch (IOException e)
/*  60:    */       {
/*  61:106 */         e.printStackTrace();
/*  62:    */       }
/*  63:    */     }
/*  64:    */     finally
/*  65:    */     {
/*  66:    */       try
/*  67:    */       {
/*  68:102 */         if (os != null) {
/*  69:103 */           os.close();
/*  70:    */         }
/*  71:    */       }
/*  72:    */       catch (IOException e)
/*  73:    */       {
/*  74:106 */         e.printStackTrace();
/*  75:    */       }
/*  76:    */     }
/*  77:    */   }
/*  78:    */   
/*  79:    */   public int describeContents()
/*  80:    */   {
/*  81:116 */     return 0;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void writeToParcel(Parcel dest, int flags)
/*  85:    */   {
/*  86:124 */     dest.writeString(this.actionUrl);
/*  87:125 */     dest.writeString(this.schema);
/*  88:126 */     dest.writeString(this.identify);
/*  89:127 */     dest.writeString(this.title);
/*  90:128 */     dest.writeString(this.description);
/*  91:129 */     dest.writeByteArray(this.thumbData);
/*  92:    */   }
/*  93:    */   
/*  94:    */   public abstract int getObjType();
/*  95:    */   
/*  96:    */   protected boolean checkArgs()
/*  97:    */   {
/*  98:149 */     if ((this.actionUrl == null) || (this.actionUrl.length() > 512))
/*  99:    */     {
/* 100:150 */       LogUtil.e("Weibo.BaseMediaObject", "checkArgs fail, actionUrl is invalid");
/* 101:151 */       return false;
/* 102:    */     }
/* 103:153 */     if ((this.identify == null) || (this.identify.length() > 512))
/* 104:    */     {
/* 105:154 */       LogUtil.e("Weibo.BaseMediaObject", "checkArgs fail, identify is invalid");
/* 106:155 */       return false;
/* 107:    */     }
/* 108:157 */     if ((this.thumbData == null) || (this.thumbData.length > 32768))
/* 109:    */     {
/* 110:158 */       LogUtil.e("Weibo.BaseMediaObject", "checkArgs fail, thumbData is invalid,size is " + (
/* 111:159 */         this.thumbData != null ? this.thumbData.length : -1) + "! more then 32768.");
/* 112:160 */       return false;
/* 113:    */     }
/* 114:162 */     if ((this.title == null) || (this.title.length() > 512))
/* 115:    */     {
/* 116:163 */       LogUtil.e("Weibo.BaseMediaObject", "checkArgs fail, title is invalid");
/* 117:164 */       return false;
/* 118:    */     }
/* 119:166 */     if ((this.description == null) || (this.description.length() > 1024))
/* 120:    */     {
/* 121:167 */       LogUtil.e("Weibo.BaseMediaObject", "checkArgs fail, description is invalid");
/* 122:168 */       return false;
/* 123:    */     }
/* 124:170 */     return true;
/* 125:    */   }
/* 126:    */   
/* 127:    */   protected abstract BaseMediaObject toExtraMediaObject(String paramString);
/* 128:    */   
/* 129:    */   protected abstract String toExtraMediaString();
/* 130:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.BaseMediaObject
 * JD-Core Version:    0.7.0.1
 */