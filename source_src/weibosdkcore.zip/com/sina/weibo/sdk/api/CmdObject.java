/*  1:   */ package com.sina.weibo.sdk.api;
/*  2:   */ 
/*  3:   */ import android.os.Parcel;
/*  4:   */ import android.os.Parcelable.Creator;
/*  5:   */ 
/*  6:   */ public class CmdObject
/*  7:   */   extends BaseMediaObject
/*  8:   */ {
/*  9:   */   public String cmd;
/* 10:   */   public static final String CMD_HOME = "home";
/* 11:34 */   public static final Parcelable.Creator<CmdObject> CREATOR = new Parcelable.Creator()
/* 12:   */   {
/* 13:   */     public CmdObject createFromParcel(Parcel in)
/* 14:   */     {
/* 15:36 */       return new CmdObject(in);
/* 16:   */     }
/* 17:   */     
/* 18:   */     public CmdObject[] newArray(int size)
/* 19:   */     {
/* 20:40 */       return new CmdObject[size];
/* 21:   */     }
/* 22:   */   };
/* 23:   */   
/* 24:   */   public CmdObject() {}
/* 25:   */   
/* 26:   */   public CmdObject(Parcel in)
/* 27:   */   {
/* 28:48 */     this.cmd = in.readString();
/* 29:   */   }
/* 30:   */   
/* 31:   */   public int describeContents()
/* 32:   */   {
/* 33:53 */     return 0;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void writeToParcel(Parcel dest, int flags)
/* 37:   */   {
/* 38:58 */     dest.writeString(this.cmd);
/* 39:   */   }
/* 40:   */   
/* 41:   */   public boolean checkArgs()
/* 42:   */   {
/* 43:62 */     if ((this.cmd == null) || (this.cmd.length() == 0) || (this.cmd.length() > 1024)) {
/* 44:63 */       return false;
/* 45:   */     }
/* 46:65 */     return true;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public int getObjType()
/* 50:   */   {
/* 51:70 */     return 7;
/* 52:   */   }
/* 53:   */   
/* 54:   */   protected BaseMediaObject toExtraMediaObject(String str)
/* 55:   */   {
/* 56:75 */     return this;
/* 57:   */   }
/* 58:   */   
/* 59:   */   protected String toExtraMediaString()
/* 60:   */   {
/* 61:80 */     return "";
/* 62:   */   }
/* 63:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.CmdObject
 * JD-Core Version:    0.7.0.1
 */