/*   1:    */ package com.sina.weibo.sdk.api;
/*   2:    */ 
/*   3:    */ import android.graphics.Bitmap;
/*   4:    */ import android.graphics.Bitmap.CompressFormat;
/*   5:    */ import android.os.Parcel;
/*   6:    */ import android.os.Parcelable.Creator;
/*   7:    */ import com.sina.weibo.sdk.utils.LogUtil;
/*   8:    */ import java.io.ByteArrayOutputStream;
/*   9:    */ import java.io.File;
/*  10:    */ import java.io.IOException;
/*  11:    */ 
/*  12:    */ public class ImageObject
/*  13:    */   extends BaseMediaObject
/*  14:    */ {
/*  15:    */   private static final int DATA_SIZE = 2097152;
/*  16:    */   public byte[] imageData;
/*  17:    */   public String imagePath;
/*  18: 45 */   public static final Parcelable.Creator<ImageObject> CREATOR = new Parcelable.Creator()
/*  19:    */   {
/*  20:    */     public ImageObject createFromParcel(Parcel in)
/*  21:    */     {
/*  22: 47 */       return new ImageObject(in);
/*  23:    */     }
/*  24:    */     
/*  25:    */     public ImageObject[] newArray(int size)
/*  26:    */     {
/*  27: 51 */       return new ImageObject[size];
/*  28:    */     }
/*  29:    */   };
/*  30:    */   
/*  31:    */   public ImageObject() {}
/*  32:    */   
/*  33:    */   public ImageObject(Parcel in)
/*  34:    */   {
/*  35: 59 */     this.imageData = in.createByteArray();
/*  36: 60 */     this.imagePath = in.readString();
/*  37:    */   }
/*  38:    */   
/*  39:    */   public final void setImageObject(Bitmap bitmap)
/*  40:    */   {
/*  41: 64 */     ByteArrayOutputStream os = null;
/*  42:    */     try
/*  43:    */     {
/*  44: 66 */       os = new ByteArrayOutputStream();
/*  45: 67 */       bitmap.compress(Bitmap.CompressFormat.JPEG, 85, os);
/*  46: 68 */       this.imageData = os.toByteArray();
/*  47:    */     }
/*  48:    */     catch (Exception e)
/*  49:    */     {
/*  50: 70 */       e.printStackTrace();
/*  51: 71 */       LogUtil.e("Weibo.ImageObject", "put thumb failed");
/*  52:    */       try
/*  53:    */       {
/*  54: 74 */         if (os != null) {
/*  55: 75 */           os.close();
/*  56:    */         }
/*  57:    */       }
/*  58:    */       catch (IOException e)
/*  59:    */       {
/*  60: 78 */         e.printStackTrace();
/*  61:    */       }
/*  62:    */     }
/*  63:    */     finally
/*  64:    */     {
/*  65:    */       try
/*  66:    */       {
/*  67: 74 */         if (os != null) {
/*  68: 75 */           os.close();
/*  69:    */         }
/*  70:    */       }
/*  71:    */       catch (IOException e)
/*  72:    */       {
/*  73: 78 */         e.printStackTrace();
/*  74:    */       }
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   public int describeContents()
/*  79:    */   {
/*  80: 85 */     return 0;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void writeToParcel(Parcel dest, int flags)
/*  84:    */   {
/*  85: 90 */     dest.writeByteArray(this.imageData);
/*  86: 91 */     dest.writeString(this.imagePath);
/*  87:    */   }
/*  88:    */   
/*  89:    */   public boolean checkArgs()
/*  90:    */   {
/*  91: 95 */     if ((this.imageData == null) && (this.imagePath == null))
/*  92:    */     {
/*  93: 96 */       LogUtil.e("Weibo.ImageObject", "imageData and imagePath are null");
/*  94: 97 */       return false;
/*  95:    */     }
/*  96: 99 */     if ((this.imageData != null) && (this.imageData.length > 2097152))
/*  97:    */     {
/*  98:100 */       LogUtil.e("Weibo.ImageObject", "imageData is too large");
/*  99:101 */       return false;
/* 100:    */     }
/* 101:103 */     if ((this.imagePath != null) && (this.imagePath.length() > 512))
/* 102:    */     {
/* 103:104 */       LogUtil.e("Weibo.ImageObject", "imagePath is too length");
/* 104:105 */       return false;
/* 105:    */     }
/* 106:107 */     if (this.imagePath != null)
/* 107:    */     {
/* 108:108 */       File file = new File(this.imagePath);
/* 109:    */       try
/* 110:    */       {
/* 111:110 */         if ((!file.exists()) || (file.length() == 0L) || (file.length() > 10485760L))
/* 112:    */         {
/* 113:111 */           LogUtil.e("Weibo.ImageObject", 
/* 114:112 */             "checkArgs fail, image content is too large or not exists");
/* 115:113 */           return false;
/* 116:    */         }
/* 117:    */       }
/* 118:    */       catch (SecurityException e)
/* 119:    */       {
/* 120:116 */         LogUtil.e("Weibo.ImageObject", 
/* 121:117 */           "checkArgs fail, image content is too large or not exists");
/* 122:118 */         return false;
/* 123:    */       }
/* 124:    */     }
/* 125:121 */     return true;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public int getObjType()
/* 129:    */   {
/* 130:126 */     return 2;
/* 131:    */   }
/* 132:    */   
/* 133:    */   protected BaseMediaObject toExtraMediaObject(String str)
/* 134:    */   {
/* 135:131 */     return this;
/* 136:    */   }
/* 137:    */   
/* 138:    */   protected String toExtraMediaString()
/* 139:    */   {
/* 140:136 */     return "";
/* 141:    */   }
/* 142:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.ImageObject
 * JD-Core Version:    0.7.0.1
 */