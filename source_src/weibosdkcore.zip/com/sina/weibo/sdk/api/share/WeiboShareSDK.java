/*  1:   */ package com.sina.weibo.sdk.api.share;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ 
/*  5:   */ public class WeiboShareSDK
/*  6:   */ {
/*  7:   */   public static IWeiboShareAPI createWeiboAPI(Context context, String appKey, boolean isDownloadWeibo)
/*  8:   */   {
/*  9:44 */     return new WeiboShareAPIImpl(context, appKey, isDownloadWeibo);
/* 10:   */   }
/* 11:   */   
/* 12:   */   public static IWeiboShareAPI createWeiboAPI(Context context, String appKey)
/* 13:   */   {
/* 14:57 */     return createWeiboAPI(context, appKey, true);
/* 15:   */   }
/* 16:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.share.WeiboShareSDK
 * JD-Core Version:    0.7.0.1
 */