/*   1:    */ package com.sina.weibo.sdk.api.share;
/*   2:    */ 
/*   3:    */ import android.app.Activity;
/*   4:    */ import android.app.Dialog;
/*   5:    */ import android.content.ActivityNotFoundException;
/*   6:    */ import android.content.Context;
/*   7:    */ import android.content.Intent;
/*   8:    */ import android.content.pm.PackageManager;
/*   9:    */ import android.os.Bundle;
/*  10:    */ import android.text.TextUtils;
/*  11:    */ import com.sina.weibo.sdk.exception.WeiboShareException;
/*  12:    */ import com.sina.weibo.sdk.utils.LogUtil;
/*  13:    */ import com.sina.weibo.sdk.utils.MD5;
/*  14:    */ import com.sina.weibo.sdk.utils.Utility;
/*  15:    */ 
/*  16:    */ class WeiboShareAPIImpl
/*  17:    */   implements IWeiboShareAPI
/*  18:    */ {
/*  19:    */   private static final String TAG = "WeiboApiImpl";
/*  20:    */   private Context mContext;
/*  21:    */   private String mAppKey;
/*  22: 55 */   private ApiUtils.WeiboInfo mWeiboInfo = null;
/*  23: 58 */   private boolean mNeedDownloadWeibo = true;
/*  24:    */   private IWeiboDownloadListener mDownloadListener;
/*  25: 64 */   private Dialog mDownloadConfirmDialog = null;
/*  26:    */   
/*  27:    */   public WeiboShareAPIImpl(Context context, String appKey, boolean needDownloadWeibo)
/*  28:    */   {
/*  29: 73 */     this.mContext = context;
/*  30: 74 */     this.mAppKey = appKey;
/*  31: 75 */     this.mNeedDownloadWeibo = needDownloadWeibo;
/*  32:    */     
/*  33:    */ 
/*  34: 78 */     this.mWeiboInfo = ApiUtils.queryWeiboInfo(this.mContext);
/*  35: 79 */     if (this.mWeiboInfo != null) {
/*  36: 80 */       LogUtil.d("WeiboApiImpl", this.mWeiboInfo.toString());
/*  37:    */     } else {
/*  38: 82 */       LogUtil.d("WeiboApiImpl", "WeiboInfo: is null");
/*  39:    */     }
/*  40:    */   }
/*  41:    */   
/*  42:    */   public boolean isWeiboAppInstalled()
/*  43:    */   {
/*  44: 93 */     return this.mWeiboInfo != null;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public boolean isWeiboAppSupportAPI()
/*  48:    */   {
/*  49:103 */     return ApiUtils.isWeiboAppSupportAPI(getWeiboAppSupportAPI());
/*  50:    */   }
/*  51:    */   
/*  52:    */   public int getWeiboAppSupportAPI()
/*  53:    */   {
/*  54:115 */     return this.mWeiboInfo == null ? -1 : this.mWeiboInfo.supportApi;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public boolean registerApp()
/*  58:    */   {
/*  59:    */     try
/*  60:    */     {
/*  61:127 */       if (!checkEnvironment(this.mNeedDownloadWeibo)) {
/*  62:128 */         return false;
/*  63:    */       }
/*  64:    */     }
/*  65:    */     catch (Exception e)
/*  66:    */     {
/*  67:131 */       return false;
/*  68:    */     }
/*  69:134 */     sendBroadcast(this.mContext, "com.sina.weibo.sdk.Intent.ACTION_WEIBO_REGISTER", this.mAppKey, null, null);
/*  70:135 */     return true;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public boolean handleWeiboResponse(Intent intent, IWeiboHandler.Response handler)
/*  74:    */   {
/*  75:154 */     String appPackage = intent.getStringExtra("_weibo_appPackage");
/*  76:156 */     if (appPackage == null)
/*  77:    */     {
/*  78:157 */       LogUtil.e("WeiboApiImpl", "responseListener() faild appPackage is null");
/*  79:158 */       return false;
/*  80:    */     }
/*  81:161 */     if (!(handler instanceof Activity))
/*  82:    */     {
/*  83:162 */       LogUtil.e("WeiboApiImpl", "responseListener() faild handler is not Activity");
/*  84:163 */       return false;
/*  85:    */     }
/*  86:166 */     Activity act = (Activity)handler;
/*  87:167 */     String callPkg = act.getCallingPackage();
/*  88:168 */     LogUtil.d("WeiboApiImpl", "responseListener() callPkg : " + callPkg);
/*  89:170 */     if (intent.getStringExtra("_weibo_transaction") == null)
/*  90:    */     {
/*  91:171 */       LogUtil.e("WeiboApiImpl", "responseListener() faild intent TRAN is null");
/*  92:172 */       return false;
/*  93:    */     }
/*  94:182 */     if (!ApiUtils.validateWeiboSign(this.mContext, appPackage))
/*  95:    */     {
/*  96:183 */       LogUtil.e("WeiboApiImpl", "responseListener() faild appPackage validateSign faild");
/*  97:184 */       return false;
/*  98:    */     }
/*  99:187 */     SendMessageToWeiboResponse data = new SendMessageToWeiboResponse(intent.getExtras());
/* 100:188 */     handler.onResponse(data);
/* 101:189 */     return true;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public boolean handleWeiboRequest(Intent intent, IWeiboHandler.Request handler)
/* 105:    */   {
/* 106:205 */     if ((intent == null) || (handler == null)) {
/* 107:206 */       return false;
/* 108:    */     }
/* 109:209 */     String appPackage = intent.getStringExtra("_weibo_appPackage");
/* 110:210 */     String transaction = intent.getStringExtra("_weibo_transaction");
/* 111:212 */     if (appPackage == null)
/* 112:    */     {
/* 113:213 */       LogUtil.e("WeiboApiImpl", "requestListener() faild appPackage validateSign faild");
/* 114:214 */       handler.onRequest(null);
/* 115:215 */       return false;
/* 116:    */     }
/* 117:216 */     if (transaction == null)
/* 118:    */     {
/* 119:217 */       LogUtil.e("WeiboApiImpl", "requestListener() faild intent TRAN is null");
/* 120:218 */       handler.onRequest(null);
/* 121:219 */       return false;
/* 122:    */     }
/* 123:220 */     if (!ApiUtils.validateWeiboSign(this.mContext, appPackage))
/* 124:    */     {
/* 125:221 */       LogUtil.e("WeiboApiImpl", "requestListener() faild appPackage validateSign faild");
/* 126:222 */       handler.onRequest(null);
/* 127:223 */       return false;
/* 128:    */     }
/* 129:225 */     ProvideMessageForWeiboRequest data = new ProvideMessageForWeiboRequest(intent.getExtras());
/* 130:226 */     handler.onRequest(data);
/* 131:227 */     return true;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public boolean launchWeibo()
/* 135:    */   {
/* 136:238 */     if (this.mWeiboInfo == null)
/* 137:    */     {
/* 138:239 */       LogUtil.e("WeiboApiImpl", "startWeibo() faild winfo is null");
/* 139:240 */       return false;
/* 140:    */     }
/* 141:    */     try
/* 142:    */     {
/* 143:244 */       if (TextUtils.isEmpty(this.mWeiboInfo.packageName))
/* 144:    */       {
/* 145:245 */         LogUtil.e("WeiboApiImpl", "startWeibo() faild packageName is null");
/* 146:246 */         return false;
/* 147:    */       }
/* 148:249 */       this.mContext.startActivity(
/* 149:250 */         this.mContext.getPackageManager().getLaunchIntentForPackage(this.mWeiboInfo.packageName));
/* 150:    */     }
/* 151:    */     catch (Exception e)
/* 152:    */     {
/* 153:252 */       LogUtil.e("WeiboApiImpl", e.getMessage());
/* 154:253 */       return false;
/* 155:    */     }
/* 156:256 */     return true;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public boolean sendRequest(BaseRequest request)
/* 160:    */   {
/* 161:269 */     if (request == null)
/* 162:    */     {
/* 163:270 */       LogUtil.e("WeiboApiImpl", "sendRequest faild act == null or request == null");
/* 164:271 */       return false;
/* 165:    */     }
/* 166:    */     try
/* 167:    */     {
/* 168:275 */       if (!checkEnvironment(this.mNeedDownloadWeibo)) {
/* 169:276 */         return false;
/* 170:    */       }
/* 171:    */     }
/* 172:    */     catch (Exception e)
/* 173:    */     {
/* 174:279 */       return false;
/* 175:    */     }
/* 176:282 */     VersionCheckHandler checkHandler = new VersionCheckHandler(this.mWeiboInfo.packageName);
/* 177:283 */     if (!request.check(this.mContext, checkHandler))
/* 178:    */     {
/* 179:284 */       LogUtil.e("WeiboApiImpl", "sendRequest faild request check faild");
/* 180:285 */       return false;
/* 181:    */     }
/* 182:288 */     Bundle data = new Bundle();
/* 183:289 */     request.toBundle(data);
/* 184:    */     
/* 185:291 */     return launchWeiboActivity((Activity)this.mContext, "com.sina.weibo.sdk.action.ACTION_WEIBO_ACTIVITY", this.mWeiboInfo.packageName, this.mAppKey, data);
/* 186:    */   }
/* 187:    */   
/* 188:    */   public boolean sendResponse(BaseResponse response)
/* 189:    */   {
/* 190:303 */     if (response == null)
/* 191:    */     {
/* 192:304 */       LogUtil.e("WeiboApiImpl", "sendResponse failed response null");
/* 193:305 */       return false;
/* 194:    */     }
/* 195:308 */     if (!response.check(this.mContext, new VersionCheckHandler()))
/* 196:    */     {
/* 197:309 */       LogUtil.e("WeiboApiImpl", "sendResponse checkArgs fail");
/* 198:310 */       return false;
/* 199:    */     }
/* 200:312 */     Bundle data = new Bundle();
/* 201:313 */     response.toBundle(data);
/* 202:314 */     sendBroadcast(this.mContext, "com.sina.weibo.sdk.Intent.ACTION_WEIBO_RESPONSE", this.mAppKey, response.reqPackageName, data);
/* 203:    */     
/* 204:316 */     return true;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public void registerWeiboDownloadListener(IWeiboDownloadListener listener)
/* 208:    */   {
/* 209:327 */     this.mDownloadListener = listener;
/* 210:    */   }
/* 211:    */   
/* 212:    */   public boolean checkEnvironment(boolean bShowDownloadDialog)
/* 213:    */     throws WeiboShareException
/* 214:    */   {
/* 215:340 */     if (this.mWeiboInfo == null)
/* 216:    */     {
/* 217:341 */       if (bShowDownloadDialog)
/* 218:    */       {
/* 219:342 */         if (this.mDownloadConfirmDialog == null)
/* 220:    */         {
/* 221:343 */           this.mDownloadConfirmDialog = WeiboDownloader.createDownloadConfirmDialog(this.mContext, this.mDownloadListener);
/* 222:344 */           this.mDownloadConfirmDialog.show();
/* 223:    */         }
/* 224:346 */         else if (!this.mDownloadConfirmDialog.isShowing())
/* 225:    */         {
/* 226:347 */           this.mDownloadConfirmDialog.show();
/* 227:    */         }
/* 228:350 */         return false;
/* 229:    */       }
/* 230:352 */       throw new WeiboShareException("Weibo is NOT installed!");
/* 231:    */     }
/* 232:356 */     if (!ApiUtils.isWeiboAppSupportAPI(this.mWeiboInfo.supportApi)) {
/* 233:357 */       throw new WeiboShareException("Weibo do NOT support Share API!");
/* 234:    */     }
/* 235:360 */     if (!ApiUtils.validateWeiboSign(this.mContext, this.mWeiboInfo.packageName)) {
/* 236:361 */       throw new WeiboShareException("Weibo signature is incorrect!");
/* 237:    */     }
/* 238:364 */     return true;
/* 239:    */   }
/* 240:    */   
/* 241:    */   private boolean launchWeiboActivity(Activity activity, String action, String pkgName, String appkey, Bundle data)
/* 242:    */   {
/* 243:368 */     if ((activity == null) || 
/* 244:369 */       (TextUtils.isEmpty(action)) || 
/* 245:370 */       (TextUtils.isEmpty(pkgName)) || 
/* 246:371 */       (TextUtils.isEmpty(appkey)))
/* 247:    */     {
/* 248:372 */       LogUtil.e("ActivityHandler", "send fail, invalid arguments");
/* 249:373 */       return false;
/* 250:    */     }
/* 251:376 */     Intent intent = new Intent();
/* 252:377 */     intent.setPackage(pkgName);
/* 253:378 */     intent.setAction(action);
/* 254:379 */     String appPackage = activity.getPackageName();
/* 255:    */     
/* 256:381 */     intent.putExtra("_weibo_sdkVersion", 22);
/* 257:382 */     intent.putExtra("_weibo_appPackage", appPackage);
/* 258:383 */     intent.putExtra("_weibo_appKey", appkey);
/* 259:384 */     intent.putExtra("_weibo_flag", 538116905);
/* 260:385 */     intent.putExtra("_weibo_sign", MD5.hexdigest(Utility.getSign(activity, appPackage)));
/* 261:387 */     if (data != null) {
/* 262:388 */       intent.putExtras(data);
/* 263:    */     }
/* 264:    */     try
/* 265:    */     {
/* 266:392 */       LogUtil.d("WeiboApiImpl", "intent=" + intent + ", extra=" + intent.getExtras());
/* 267:393 */       activity.startActivityForResult(intent, 765);
/* 268:    */     }
/* 269:    */     catch (ActivityNotFoundException e)
/* 270:    */     {
/* 271:395 */       LogUtil.e("WeiboApiImpl", "Failed, target ActivityNotFound");
/* 272:396 */       return false;
/* 273:    */     }
/* 274:399 */     return true;
/* 275:    */   }
/* 276:    */   
/* 277:    */   private void sendBroadcast(Context context, String action, String key, String packageName, Bundle data)
/* 278:    */   {
/* 279:403 */     Intent intent = new Intent(action);
/* 280:404 */     String appPackage = context.getPackageName();
/* 281:405 */     intent.putExtra("_weibo_sdkVersion", 22);
/* 282:406 */     intent.putExtra("_weibo_appPackage", appPackage);
/* 283:407 */     intent.putExtra("_weibo_appKey", key);
/* 284:408 */     intent.putExtra("_weibo_flag", 538116905);
/* 285:409 */     intent.putExtra("_weibo_sign", MD5.hexdigest(Utility.getSign(context, appPackage)));
/* 286:411 */     if (!TextUtils.isEmpty(packageName)) {
/* 287:412 */       intent.setPackage(packageName);
/* 288:    */     }
/* 289:415 */     if (data != null) {
/* 290:416 */       intent.putExtras(data);
/* 291:    */     }
/* 292:419 */     LogUtil.d("WeiboApiImpl", "intent=" + intent + ", extra=" + intent.getExtras());
/* 293:420 */     context.sendBroadcast(intent, "com.sina.weibo.permission.WEIBO_SDK_PERMISSION");
/* 294:    */   }
/* 295:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.share.WeiboShareAPIImpl
 * JD-Core Version:    0.7.0.1
 */