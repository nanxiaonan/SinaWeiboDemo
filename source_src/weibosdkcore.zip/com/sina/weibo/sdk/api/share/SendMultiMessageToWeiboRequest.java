/*  1:   */ package com.sina.weibo.sdk.api.share;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ import android.os.Bundle;
/*  5:   */ import com.sina.weibo.sdk.api.WeiboMultiMessage;
/*  6:   */ 
/*  7:   */ public class SendMultiMessageToWeiboRequest
/*  8:   */   extends BaseRequest
/*  9:   */ {
/* 10:   */   public WeiboMultiMessage multiMessage;
/* 11:   */   
/* 12:   */   public SendMultiMessageToWeiboRequest() {}
/* 13:   */   
/* 14:   */   public SendMultiMessageToWeiboRequest(Bundle data)
/* 15:   */   {
/* 16:39 */     fromBundle(data);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public int getType()
/* 20:   */   {
/* 21:44 */     return 1;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void fromBundle(Bundle data)
/* 25:   */   {
/* 26:49 */     super.fromBundle(data);
/* 27:50 */     this.multiMessage = new WeiboMultiMessage(data);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void toBundle(Bundle data)
/* 31:   */   {
/* 32:55 */     super.toBundle(data);
/* 33:56 */     data.putAll(this.multiMessage.toBundle(data));
/* 34:   */   }
/* 35:   */   
/* 36:   */   final boolean check(Context context, VersionCheckHandler handler)
/* 37:   */   {
/* 38:61 */     if (this.multiMessage == null) {
/* 39:62 */       return false;
/* 40:   */     }
/* 41:65 */     if ((handler != null) && 
/* 42:66 */       (!handler.check(context, this.multiMessage))) {
/* 43:67 */       return false;
/* 44:   */     }
/* 45:71 */     return this.multiMessage.checkArgs();
/* 46:   */   }
/* 47:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.share.SendMultiMessageToWeiboRequest
 * JD-Core Version:    0.7.0.1
 */