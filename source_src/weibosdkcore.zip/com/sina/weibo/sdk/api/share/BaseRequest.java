/*  1:   */ package com.sina.weibo.sdk.api.share;
/*  2:   */ 
/*  3:   */ import android.os.Bundle;
/*  4:   */ 
/*  5:   */ public abstract class BaseRequest
/*  6:   */   extends Base
/*  7:   */ {
/*  8:   */   public String packageName;
/*  9:   */   
/* 10:   */   public void toBundle(Bundle bundle)
/* 11:   */   {
/* 12:41 */     bundle.putInt("_weibo_command_type", getType());
/* 13:42 */     bundle.putString("_weibo_transaction", this.transaction);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public void fromBundle(Bundle bundle)
/* 17:   */   {
/* 18:52 */     this.transaction = bundle.getString("_weibo_transaction");
/* 19:53 */     this.packageName = bundle.getString("_weibo_appPackage");
/* 20:   */   }
/* 21:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.share.BaseRequest
 * JD-Core Version:    0.7.0.1
 */