/*  1:   */ package com.sina.weibo.sdk.api.share;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ import android.os.Bundle;
/*  5:   */ import com.sina.weibo.sdk.api.WeiboMultiMessage;
/*  6:   */ 
/*  7:   */ public class ProvideMultiMessageForWeiboResponse
/*  8:   */   extends BaseResponse
/*  9:   */ {
/* 10:   */   public WeiboMultiMessage multiMessage;
/* 11:   */   
/* 12:   */   public ProvideMultiMessageForWeiboResponse() {}
/* 13:   */   
/* 14:   */   public ProvideMultiMessageForWeiboResponse(Bundle bundle)
/* 15:   */   {
/* 16:39 */     fromBundle(bundle);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public int getType()
/* 20:   */   {
/* 21:44 */     return 2;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void fromBundle(Bundle bundle)
/* 25:   */   {
/* 26:49 */     super.fromBundle(bundle);
/* 27:50 */     this.multiMessage = new WeiboMultiMessage(bundle);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void toBundle(Bundle bundle)
/* 31:   */   {
/* 32:55 */     super.toBundle(bundle);
/* 33:56 */     bundle.putAll(this.multiMessage.toBundle(bundle));
/* 34:   */   }
/* 35:   */   
/* 36:   */   final boolean check(Context context, VersionCheckHandler handler)
/* 37:   */   {
/* 38:61 */     if (this.multiMessage == null) {
/* 39:62 */       return false;
/* 40:   */     }
/* 41:65 */     if (handler != null)
/* 42:   */     {
/* 43:66 */       handler.setPackageName(this.reqPackageName);
/* 44:67 */       if (!handler.check(context, this.multiMessage)) {
/* 45:68 */         return false;
/* 46:   */       }
/* 47:   */     }
/* 48:72 */     return this.multiMessage.checkArgs();
/* 49:   */   }
/* 50:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.share.ProvideMultiMessageForWeiboResponse
 * JD-Core Version:    0.7.0.1
 */