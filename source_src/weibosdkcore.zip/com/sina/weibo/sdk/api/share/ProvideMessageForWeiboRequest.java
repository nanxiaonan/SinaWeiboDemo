/*  1:   */ package com.sina.weibo.sdk.api.share;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ import android.os.Bundle;
/*  5:   */ 
/*  6:   */ public class ProvideMessageForWeiboRequest
/*  7:   */   extends BaseRequest
/*  8:   */ {
/*  9:   */   public ProvideMessageForWeiboRequest() {}
/* 10:   */   
/* 11:   */   public ProvideMessageForWeiboRequest(Bundle bundle)
/* 12:   */   {
/* 13:37 */     fromBundle(bundle);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getType()
/* 17:   */   {
/* 18:42 */     return 2;
/* 19:   */   }
/* 20:   */   
/* 21:   */   final boolean check(Context context, VersionCheckHandler handler)
/* 22:   */   {
/* 23:47 */     return true;
/* 24:   */   }
/* 25:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.share.ProvideMessageForWeiboRequest
 * JD-Core Version:    0.7.0.1
 */