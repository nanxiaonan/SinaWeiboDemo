/*   1:    */ package com.sina.weibo.sdk.api.share;
/*   2:    */ 
/*   3:    */ import android.content.ContentResolver;
/*   4:    */ import android.content.Context;
/*   5:    */ import android.content.Intent;
/*   6:    */ import android.content.pm.ApplicationInfo;
/*   7:    */ import android.content.pm.PackageInfo;
/*   8:    */ import android.content.pm.PackageManager;
/*   9:    */ import android.content.pm.PackageManager.NameNotFoundException;
/*  10:    */ import android.content.pm.ResolveInfo;
/*  11:    */ import android.content.pm.ServiceInfo;
/*  12:    */ import android.content.pm.Signature;
/*  13:    */ import android.content.res.AssetManager;
/*  14:    */ import android.database.Cursor;
/*  15:    */ import android.net.Uri;
/*  16:    */ import android.text.TextUtils;
/*  17:    */ import com.sina.weibo.sdk.utils.LogUtil;
/*  18:    */ import com.sina.weibo.sdk.utils.MD5;
/*  19:    */ import java.io.IOException;
/*  20:    */ import java.io.InputStream;
/*  21:    */ import java.util.List;
/*  22:    */ import org.json.JSONException;
/*  23:    */ import org.json.JSONObject;
/*  24:    */ 
/*  25:    */ public class ApiUtils
/*  26:    */ {
/*  27:    */   private static final String TAG = "ApiUtils";
/*  28:    */   public static final int BUILD_INT = 10350;
/*  29:    */   public static final int BUILD_INT_VER_2_2 = 10351;
/*  30:    */   public static final int BUILD_INT_VER_2_3 = 10352;
/*  31:    */   public static final int BUILD_INT_VER_2_5 = 10353;
/*  32:    */   private static final String WEIBO_IDENTITY_ACTION = "com.sina.weibo.action.sdkidentity";
/*  33: 63 */   private static final Uri WEIBO_NAME_URI = Uri.parse("content://com.sina.weibo.sdkProvider/query/package");
/*  34:    */   private static final String WEIBO_SIGN = "18da2bf10352443a00a5e046d9fca6bd";
/*  35:    */   
/*  36:    */   public static class WeiboInfo
/*  37:    */   {
/*  38:    */     public String packageName;
/*  39:    */     public int supportApi;
/*  40:    */     
/*  41:    */     public String toString()
/*  42:    */     {
/*  43: 79 */       return "WeiboInfo: PackageName = " + this.packageName + ", supportApi = " + this.supportApi;
/*  44:    */     }
/*  45:    */   }
/*  46:    */   
/*  47:    */   public static boolean isWeiboAppSupportAPI(int supportApi)
/*  48:    */   {
/*  49: 91 */     return supportApi >= 10350;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static WeiboInfo queryWeiboInfoByPackage(Context context, String packageName)
/*  53:    */   {
/*  54:103 */     if ((context == null) || (packageName == null)) {
/*  55:104 */       return null;
/*  56:    */     }
/*  57:107 */     WeiboInfo info = queryWeiboInfoByAsset(context, packageName);
/*  58:108 */     if (info != null) {
/*  59:109 */       return info;
/*  60:    */     }
/*  61:112 */     info = queryWeiboInfoByProvider(context);
/*  62:113 */     if ((info != null) && (packageName.equals(info.packageName))) {
/*  63:114 */       return info;
/*  64:    */     }
/*  65:117 */     return null;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public static WeiboInfo queryWeiboInfo(Context context)
/*  69:    */   {
/*  70:128 */     WeiboInfo winfo = queryWeiboInfoByProvider(context);
/*  71:129 */     if (winfo == null) {
/*  72:130 */       return queryWeiboInfoByFile(context);
/*  73:    */     }
/*  74:133 */     return winfo;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public static boolean validateWeiboSign(Context context, String pkgName)
/*  78:    */   {
/*  79:    */     try
/*  80:    */     {
/*  81:147 */       packageInfo = context.getPackageManager().getPackageInfo(
/*  82:148 */         pkgName, 64);
/*  83:    */     }
/*  84:    */     catch (PackageManager.NameNotFoundException localNameNotFoundException)
/*  85:    */     {
/*  86:    */       PackageInfo packageInfo;
/*  87:150 */       return false;
/*  88:    */     }
/*  89:    */     PackageInfo packageInfo;
/*  90:153 */     return containSign(packageInfo.signatures, "18da2bf10352443a00a5e046d9fca6bd");
/*  91:    */   }
/*  92:    */   
/*  93:    */   public static boolean containSign(Signature[] signatures, String destSign)
/*  94:    */   {
/*  95:165 */     if ((signatures == null) || (destSign == null)) {
/*  96:166 */       return false;
/*  97:    */     }
/*  98:169 */     Signature[] arrayOfSignature = signatures;int j = signatures.length;
/*  99:169 */     for (int i = 0; i < j; i++)
/* 100:    */     {
/* 101:169 */       Signature signature = arrayOfSignature[i];
/* 102:170 */       String s = MD5.hexdigest(signature.toByteArray());
/* 103:171 */       if (destSign.equals(s))
/* 104:    */       {
/* 105:172 */         LogUtil.d("ApiUtils", "check pass");
/* 106:173 */         return true;
/* 107:    */       }
/* 108:    */     }
/* 109:177 */     return false;
/* 110:    */   }
/* 111:    */   
/* 112:    */   private static WeiboInfo queryWeiboInfoByProvider(Context context)
/* 113:    */   {
/* 114:188 */     ContentResolver cr = context.getContentResolver();
/* 115:189 */     Cursor cursor = null;
/* 116:    */     try
/* 117:    */     {
/* 118:191 */       cursor = cr.query(WEIBO_NAME_URI, null, null, null, null);
/* 119:192 */       if (cursor == null) {
/* 120:193 */         return null;
/* 121:    */       }
/* 122:196 */       int supportApiIndex = cursor.getColumnIndex("support_api");
/* 123:197 */       int packageIndex = cursor.getColumnIndex("package");
/* 124:198 */       if (cursor.moveToFirst())
/* 125:    */       {
/* 126:199 */         int supportApiInt = -1;
/* 127:200 */         String supportApi = cursor.getString(supportApiIndex);
/* 128:    */         try
/* 129:    */         {
/* 130:202 */           supportApiInt = Integer.parseInt(supportApi);
/* 131:    */         }
/* 132:    */         catch (NumberFormatException e)
/* 133:    */         {
/* 134:204 */           e.printStackTrace();
/* 135:    */         }
/* 136:207 */         String packageName = cursor.getString(packageIndex);
/* 137:208 */         if ((!TextUtils.isEmpty(packageName)) && (validateWeiboSign(context, packageName)))
/* 138:    */         {
/* 139:209 */           WeiboInfo winfo = new WeiboInfo();
/* 140:210 */           winfo.packageName = packageName;
/* 141:211 */           winfo.supportApi = supportApiInt;
/* 142:212 */           return winfo;
/* 143:    */         }
/* 144:    */       }
/* 145:    */     }
/* 146:    */     catch (Exception e)
/* 147:    */     {
/* 148:216 */       e.printStackTrace();
/* 149:217 */       LogUtil.e("ApiUtils", e.getMessage());
/* 150:    */     }
/* 151:    */     finally
/* 152:    */     {
/* 153:219 */       if (cursor != null)
/* 154:    */       {
/* 155:220 */         cursor.close();
/* 156:221 */         cursor = null;
/* 157:    */       }
/* 158:    */     }
/* 159:219 */     if (cursor != null)
/* 160:    */     {
/* 161:220 */       cursor.close();
/* 162:221 */       cursor = null;
/* 163:    */     }
/* 164:224 */     return null;
/* 165:    */   }
/* 166:    */   
/* 167:    */   private static WeiboInfo queryWeiboInfoByFile(Context context)
/* 168:    */   {
/* 169:235 */     Intent intent = new Intent("com.sina.weibo.action.sdkidentity");
/* 170:236 */     intent.addCategory("android.intent.category.DEFAULT");
/* 171:237 */     List<ResolveInfo> list = context.getPackageManager().queryIntentServices(intent, 0);
/* 172:238 */     if ((list == null) || (list.isEmpty())) {
/* 173:239 */       return null;
/* 174:    */     }
/* 175:242 */     for (ResolveInfo ri : list) {
/* 176:243 */       if ((ri.serviceInfo != null) && 
/* 177:244 */         (ri.serviceInfo.applicationInfo != null) && 
/* 178:245 */         (ri.serviceInfo.applicationInfo.packageName != null) && 
/* 179:246 */         (ri.serviceInfo.applicationInfo.packageName.length() != 0))
/* 180:    */       {
/* 181:250 */         String packageName = ri.serviceInfo.applicationInfo.packageName;
/* 182:251 */         WeiboInfo winfo = queryWeiboInfoByAsset(context, packageName);
/* 183:252 */         if (winfo != null) {
/* 184:253 */           return winfo;
/* 185:    */         }
/* 186:    */       }
/* 187:    */     }
/* 188:257 */     return null;
/* 189:    */   }
/* 190:    */   
/* 191:    */   private static WeiboInfo queryWeiboInfoByAsset(Context context, String packageName)
/* 192:    */   {
/* 193:269 */     if ((context == null) || (packageName == null)) {
/* 194:270 */       return null;
/* 195:    */     }
/* 196:273 */     InputStream is = null;
/* 197:    */     try
/* 198:    */     {
/* 199:275 */       Context weiboContext = 
/* 200:276 */         context.createPackageContext(packageName, 2);
/* 201:    */       
/* 202:278 */       int bufferSize = 1024;
/* 203:279 */       byte[] buf = new byte[1024];
/* 204:    */       
/* 205:281 */       is = weiboContext.getAssets().open("weibo_for_sdk.json");
/* 206:282 */       StringBuilder sbContent = new StringBuilder();
/* 207:    */       int readNum;
/* 208:284 */       while ((readNum = is.read(buf, 0, 1024)) != -1)
/* 209:    */       {
/* 210:    */         int readNum;
/* 211:285 */         sbContent.append(new String(buf, 0, readNum));
/* 212:    */       }
/* 213:288 */       if ((TextUtils.isEmpty(sbContent.toString())) || (!validateWeiboSign(context, packageName))) {
/* 214:289 */         return null;
/* 215:    */       }
/* 216:292 */       JSONObject json = new JSONObject(sbContent.toString());
/* 217:293 */       int supportApi = json.optInt("support_api", -1);
/* 218:    */       
/* 219:295 */       WeiboInfo winfo = new WeiboInfo();
/* 220:296 */       winfo.packageName = packageName;
/* 221:297 */       winfo.supportApi = supportApi;
/* 222:298 */       return winfo;
/* 223:    */     }
/* 224:    */     catch (PackageManager.NameNotFoundException e)
/* 225:    */     {
/* 226:301 */       e.printStackTrace();
/* 227:    */     }
/* 228:    */     catch (IOException e)
/* 229:    */     {
/* 230:303 */       e.printStackTrace();
/* 231:    */     }
/* 232:    */     catch (JSONException e)
/* 233:    */     {
/* 234:305 */       e.printStackTrace();
/* 235:    */     }
/* 236:    */     catch (Exception e)
/* 237:    */     {
/* 238:307 */       LogUtil.e("ApiUtils", e.getMessage());
/* 239:    */     }
/* 240:    */     finally
/* 241:    */     {
/* 242:309 */       if (is != null) {
/* 243:    */         try
/* 244:    */         {
/* 245:311 */           is.close();
/* 246:    */         }
/* 247:    */         catch (IOException localIOException7) {}
/* 248:    */       }
/* 249:    */     }
/* 250:317 */     return null;
/* 251:    */   }
/* 252:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.share.ApiUtils
 * JD-Core Version:    0.7.0.1
 */