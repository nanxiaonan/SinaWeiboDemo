package com.sina.weibo.sdk.api.share;

import android.content.Context;
import android.os.Bundle;

public abstract class Base
{
  public String transaction;
  
  public abstract void toBundle(Bundle paramBundle);
  
  public abstract void fromBundle(Bundle paramBundle);
  
  public abstract int getType();
  
  abstract boolean check(Context paramContext, VersionCheckHandler paramVersionCheckHandler);
}


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.share.Base
 * JD-Core Version:    0.7.0.1
 */