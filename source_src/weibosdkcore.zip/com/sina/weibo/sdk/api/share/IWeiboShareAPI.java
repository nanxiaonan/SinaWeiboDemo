package com.sina.weibo.sdk.api.share;

import android.content.Intent;
import com.sina.weibo.sdk.exception.WeiboShareException;

public abstract interface IWeiboShareAPI
{
  public abstract boolean isWeiboAppInstalled();
  
  public abstract boolean isWeiboAppSupportAPI();
  
  public abstract int getWeiboAppSupportAPI();
  
  public abstract boolean registerApp();
  
  public abstract boolean handleWeiboResponse(Intent paramIntent, IWeiboHandler.Response paramResponse);
  
  public abstract boolean handleWeiboRequest(Intent paramIntent, IWeiboHandler.Request paramRequest);
  
  public abstract boolean launchWeibo();
  
  public abstract boolean sendRequest(BaseRequest paramBaseRequest);
  
  public abstract boolean sendResponse(BaseResponse paramBaseResponse);
  
  public abstract void registerWeiboDownloadListener(IWeiboDownloadListener paramIWeiboDownloadListener);
  
  public abstract boolean checkEnvironment(boolean paramBoolean)
    throws WeiboShareException;
}


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.share.IWeiboShareAPI
 * JD-Core Version:    0.7.0.1
 */