/*   1:    */ package com.sina.weibo.sdk.api.share;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import com.sina.weibo.sdk.api.CmdObject;
/*   5:    */ import com.sina.weibo.sdk.api.VoiceObject;
/*   6:    */ import com.sina.weibo.sdk.api.WeiboMessage;
/*   7:    */ import com.sina.weibo.sdk.api.WeiboMultiMessage;
/*   8:    */ import com.sina.weibo.sdk.utils.LogUtil;
/*   9:    */ 
/*  10:    */ public class VersionCheckHandler
/*  11:    */   implements IVersionCheckHandler
/*  12:    */ {
/*  13:    */   private static final String TAG = "VersionCheckHandler";
/*  14:    */   private String mPackageName;
/*  15:    */   
/*  16:    */   public VersionCheckHandler(String packageName)
/*  17:    */   {
/*  18: 41 */     this.mPackageName = packageName;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public VersionCheckHandler() {}
/*  22:    */   
/*  23:    */   public void setPackageName(String packageName)
/*  24:    */   {
/*  25: 48 */     this.mPackageName = packageName;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public boolean check(Context context, WeiboMessage message)
/*  29:    */   {
/*  30: 53 */     LogUtil.d("VersionCheckHandler", "check WeiboMessage package : " + this.mPackageName);
/*  31: 55 */     if ((this.mPackageName == null) || (this.mPackageName.length() == 0)) {
/*  32: 56 */       return false;
/*  33:    */     }
/*  34: 59 */     ApiUtils.WeiboInfo winfo = ApiUtils.queryWeiboInfoByPackage(context, this.mPackageName);
/*  35: 60 */     if (winfo == null) {
/*  36: 61 */       return false;
/*  37:    */     }
/*  38: 64 */     LogUtil.d("VersionCheckHandler", "check WeiboMessage WeiboInfo supportApi : " + winfo.supportApi);
/*  39: 66 */     if (winfo.supportApi < 10351) {
/*  40: 68 */       if ((message.mediaObject != null) && ((message.mediaObject instanceof VoiceObject))) {
/*  41: 69 */         message.mediaObject = null;
/*  42:    */       }
/*  43:    */     }
/*  44: 73 */     if (winfo.supportApi < 10352) {
/*  45: 75 */       if ((message.mediaObject != null) && ((message.mediaObject instanceof CmdObject))) {
/*  46: 76 */         message.mediaObject = null;
/*  47:    */       }
/*  48:    */     }
/*  49: 80 */     return true;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public boolean check(Context context, WeiboMultiMessage message)
/*  53:    */   {
/*  54: 85 */     LogUtil.d("VersionCheckHandler", "check WeiboMultiMessage package : " + this.mPackageName);
/*  55: 87 */     if ((this.mPackageName == null) || (this.mPackageName.length() == 0)) {
/*  56: 88 */       return false;
/*  57:    */     }
/*  58: 91 */     ApiUtils.WeiboInfo winfo = ApiUtils.queryWeiboInfoByPackage(context, this.mPackageName);
/*  59: 92 */     if (winfo == null) {
/*  60: 93 */       return false;
/*  61:    */     }
/*  62: 96 */     LogUtil.d("VersionCheckHandler", "check WeiboMultiMessage WeiboInfo supportApi : " + winfo.supportApi);
/*  63: 98 */     if (winfo.supportApi < 10351) {
/*  64:100 */       return false;
/*  65:    */     }
/*  66:103 */     if (winfo.supportApi < 10352) {
/*  67:105 */       if ((message.mediaObject != null) && ((message.mediaObject instanceof CmdObject))) {
/*  68:106 */         message.mediaObject = null;
/*  69:    */       }
/*  70:    */     }
/*  71:110 */     return true;
/*  72:    */   }
/*  73:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.share.VersionCheckHandler
 * JD-Core Version:    0.7.0.1
 */