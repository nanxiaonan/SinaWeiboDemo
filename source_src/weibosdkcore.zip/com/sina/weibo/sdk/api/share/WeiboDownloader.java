/*   1:    */ package com.sina.weibo.sdk.api.share;
/*   2:    */ 
/*   3:    */ import android.app.AlertDialog.Builder;
/*   4:    */ import android.app.Dialog;
/*   5:    */ import android.content.Context;
/*   6:    */ import android.content.DialogInterface;
/*   7:    */ import android.content.DialogInterface.OnClickListener;
/*   8:    */ import android.content.Intent;
/*   9:    */ import android.net.Uri;
/*  10:    */ import com.sina.weibo.sdk.utils.Utility;
/*  11:    */ 
/*  12:    */ public class WeiboDownloader
/*  13:    */ {
/*  14:    */   private static final String TITLE_CHINESS = "提示";
/*  15:    */   private static final String PROMPT_CHINESS = "未安装微博客户端，是否现在去下载？";
/*  16:    */   private static final String OK_CHINESS = "现在下载";
/*  17:    */   private static final String CANCEL_CHINESS = "以后再说";
/*  18:    */   private static final String TITLE_ENGLISH = "Notice";
/*  19:    */   private static final String PROMPT_ENGLISH = "Sina Weibo client is not installed, download now?";
/*  20:    */   private static final String OK_ENGLISH = "Download Now";
/*  21:    */   private static final String CANCEL_ENGLISH = "Download Later";
/*  22:    */   
/*  23:    */   public static Dialog createDownloadConfirmDialog(Context context, IWeiboDownloadListener listener)
/*  24:    */   {
/*  25: 56 */     String title = "提示";
/*  26: 57 */     String prompt = "未安装微博客户端，是否现在去下载？";
/*  27: 58 */     String ok = "现在下载";
/*  28: 59 */     String cancel = "以后再说";
/*  29: 61 */     if (!Utility.isChineseLocale(context.getApplicationContext()))
/*  30:    */     {
/*  31: 62 */       title = "Notice";
/*  32: 63 */       prompt = "Sina Weibo client is not installed, download now?";
/*  33: 64 */       ok = "Download Now";
/*  34: 65 */       cancel = "Download Later";
/*  35:    */     }
/*  36: 68 */     Dialog dialog = new AlertDialog.Builder(context)
/*  37: 69 */       .setMessage(prompt)
/*  38: 70 */       .setTitle(title)
/*  39: 71 */       .setPositiveButton(ok, new DialogInterface.OnClickListener()
/*  40:    */       {
/*  41:    */         public void onClick(DialogInterface dialog, int which)
/*  42:    */         {
/*  43: 74 */           WeiboDownloader.downloadWeibo(WeiboDownloader.this);
/*  44:    */         }
/*  45: 76 */       }).setNegativeButton(cancel, new DialogInterface.OnClickListener()
/*  46:    */       {
/*  47:    */         public void onClick(DialogInterface dialog, int which)
/*  48:    */         {
/*  49: 79 */           if (WeiboDownloader.this != null) {
/*  50: 80 */             WeiboDownloader.this.onCancel();
/*  51:    */           }
/*  52:    */         }
/*  53: 84 */       }).create();
/*  54: 85 */     return dialog;
/*  55:    */   }
/*  56:    */   
/*  57:    */   private static void downloadWeibo(Context context)
/*  58:    */   {
/*  59: 94 */     Intent intent = new Intent();
/*  60: 95 */     intent.setAction("android.intent.action.VIEW");
/*  61: 96 */     intent.setFlags(268435456);
/*  62: 97 */     Uri url = Uri.parse("http://app.sina.cn/appdetail.php?appID=84560");
/*  63: 98 */     intent.setData(url);
/*  64:    */     try
/*  65:    */     {
/*  66:100 */       context.startActivity(intent);
/*  67:    */     }
/*  68:    */     catch (Exception e)
/*  69:    */     {
/*  70:102 */       e.printStackTrace();
/*  71:    */     }
/*  72:    */   }
/*  73:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.share.WeiboDownloader
 * JD-Core Version:    0.7.0.1
 */