/*  1:   */ package com.sina.weibo.sdk.api.share;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ import android.os.Bundle;
/*  5:   */ 
/*  6:   */ public class SendMessageToWeiboResponse
/*  7:   */   extends BaseResponse
/*  8:   */ {
/*  9:   */   public SendMessageToWeiboResponse() {}
/* 10:   */   
/* 11:   */   public SendMessageToWeiboResponse(Bundle data)
/* 12:   */   {
/* 13:37 */     fromBundle(data);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public int getType()
/* 17:   */   {
/* 18:42 */     return 1;
/* 19:   */   }
/* 20:   */   
/* 21:   */   final boolean check(Context context, VersionCheckHandler handler)
/* 22:   */   {
/* 23:47 */     return true;
/* 24:   */   }
/* 25:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.share.SendMessageToWeiboResponse
 * JD-Core Version:    0.7.0.1
 */