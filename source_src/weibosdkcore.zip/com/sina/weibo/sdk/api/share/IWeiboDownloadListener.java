package com.sina.weibo.sdk.api.share;

public abstract interface IWeiboDownloadListener
{
  public abstract void onCancel();
}


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.share.IWeiboDownloadListener
 * JD-Core Version:    0.7.0.1
 */