/*  1:   */ package com.sina.weibo.sdk.api.share;
/*  2:   */ 
/*  3:   */ import android.content.Context;
/*  4:   */ import android.os.Bundle;
/*  5:   */ import com.sina.weibo.sdk.api.WeiboMessage;
/*  6:   */ 
/*  7:   */ public class SendMessageToWeiboRequest
/*  8:   */   extends BaseRequest
/*  9:   */ {
/* 10:   */   public WeiboMessage message;
/* 11:   */   
/* 12:   */   public SendMessageToWeiboRequest() {}
/* 13:   */   
/* 14:   */   public SendMessageToWeiboRequest(Bundle data)
/* 15:   */   {
/* 16:39 */     fromBundle(data);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public int getType()
/* 20:   */   {
/* 21:44 */     return 1;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public void fromBundle(Bundle data)
/* 25:   */   {
/* 26:49 */     super.fromBundle(data);
/* 27:50 */     this.message = new WeiboMessage(data);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void toBundle(Bundle data)
/* 31:   */   {
/* 32:55 */     super.toBundle(data);
/* 33:56 */     data.putAll(this.message.toBundle(data));
/* 34:   */   }
/* 35:   */   
/* 36:   */   final boolean check(Context context, VersionCheckHandler handler)
/* 37:   */   {
/* 38:61 */     if (this.message == null) {
/* 39:62 */       return false;
/* 40:   */     }
/* 41:65 */     if ((handler != null) && 
/* 42:66 */       (!handler.check(context, this.message))) {
/* 43:67 */       return false;
/* 44:   */     }
/* 45:71 */     return this.message.checkArgs();
/* 46:   */   }
/* 47:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.share.SendMessageToWeiboRequest
 * JD-Core Version:    0.7.0.1
 */