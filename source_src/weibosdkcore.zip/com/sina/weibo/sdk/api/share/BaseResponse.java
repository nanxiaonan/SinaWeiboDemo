/*  1:   */ package com.sina.weibo.sdk.api.share;
/*  2:   */ 
/*  3:   */ import android.os.Bundle;
/*  4:   */ 
/*  5:   */ public abstract class BaseResponse
/*  6:   */   extends Base
/*  7:   */ {
/*  8:   */   public int errCode;
/*  9:   */   public String errMsg;
/* 10:   */   public String reqPackageName;
/* 11:   */   
/* 12:   */   public void toBundle(Bundle bundle)
/* 13:   */   {
/* 14:44 */     bundle.putInt("_weibo_command_type", getType());
/* 15:45 */     bundle.putInt("_weibo_resp_errcode", this.errCode);
/* 16:46 */     bundle.putString("_weibo_resp_errstr", this.errMsg);
/* 17:47 */     bundle.putString("_weibo_transaction", this.transaction);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void fromBundle(Bundle bundle)
/* 21:   */   {
/* 22:56 */     this.errCode = bundle.getInt("_weibo_resp_errcode");
/* 23:57 */     this.errMsg = bundle.getString("_weibo_resp_errstr");
/* 24:58 */     this.transaction = bundle.getString("_weibo_transaction");
/* 25:59 */     this.reqPackageName = bundle.getString("_weibo_appPackage");
/* 26:   */   }
/* 27:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.share.BaseResponse
 * JD-Core Version:    0.7.0.1
 */