package com.sina.weibo.sdk.api.share;

public abstract interface IWeiboHandler
{
  public static abstract interface Request
  {
    public abstract void onRequest(BaseRequest paramBaseRequest);
  }
  
  public static abstract interface Response
  {
    public abstract void onResponse(BaseResponse paramBaseResponse);
  }
}


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.share.IWeiboHandler
 * JD-Core Version:    0.7.0.1
 */