/*  1:   */ package com.sina.weibo.sdk.api;
/*  2:   */ 
/*  3:   */ import android.os.Parcel;
/*  4:   */ import android.os.Parcelable.Creator;
/*  5:   */ import com.sina.weibo.sdk.utils.LogUtil;
/*  6:   */ 
/*  7:   */ public class TextObject
/*  8:   */   extends BaseMediaObject
/*  9:   */ {
/* 10:   */   public String text;
/* 11:   */   
/* 12:   */   public TextObject() {}
/* 13:   */   
/* 14:   */   public TextObject(Parcel in)
/* 15:   */   {
/* 16:39 */     this.text = in.readString();
/* 17:   */   }
/* 18:   */   
/* 19:42 */   public static final Parcelable.Creator<TextObject> CREATOR = new Parcelable.Creator()
/* 20:   */   {
/* 21:   */     public TextObject createFromParcel(Parcel in)
/* 22:   */     {
/* 23:44 */       return new TextObject(in);
/* 24:   */     }
/* 25:   */     
/* 26:   */     public TextObject[] newArray(int size)
/* 27:   */     {
/* 28:48 */       return new TextObject[size];
/* 29:   */     }
/* 30:   */   };
/* 31:   */   
/* 32:   */   public int describeContents()
/* 33:   */   {
/* 34:54 */     return 0;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void writeToParcel(Parcel dest, int flags)
/* 38:   */   {
/* 39:59 */     dest.writeString(this.text);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public boolean checkArgs()
/* 43:   */   {
/* 44:63 */     if ((this.text == null) || (this.text.length() == 0) || (this.text.length() > 1024))
/* 45:   */     {
/* 46:64 */       LogUtil.e("Weibo.TextObject", "checkArgs fail, text is invalid");
/* 47:65 */       return false;
/* 48:   */     }
/* 49:67 */     return true;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public int getObjType()
/* 53:   */   {
/* 54:72 */     return 1;
/* 55:   */   }
/* 56:   */   
/* 57:   */   protected BaseMediaObject toExtraMediaObject(String str)
/* 58:   */   {
/* 59:77 */     return this;
/* 60:   */   }
/* 61:   */   
/* 62:   */   protected String toExtraMediaString()
/* 63:   */   {
/* 64:82 */     return "";
/* 65:   */   }
/* 66:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.TextObject
 * JD-Core Version:    0.7.0.1
 */