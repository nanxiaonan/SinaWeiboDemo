/*   1:    */ package com.sina.weibo.sdk.api;
/*   2:    */ 
/*   3:    */ import android.os.Parcel;
/*   4:    */ import android.os.Parcelable.Creator;
/*   5:    */ import android.text.TextUtils;
/*   6:    */ import com.sina.weibo.sdk.utils.LogUtil;
/*   7:    */ import org.json.JSONException;
/*   8:    */ import org.json.JSONObject;
/*   9:    */ 
/*  10:    */ public class VoiceObject
/*  11:    */   extends BaseMediaObject
/*  12:    */ {
/*  13:    */   public static final String EXTRA_KEY_DEFAULTTEXT = "extra_key_defaulttext";
/*  14:    */   public String defaultText;
/*  15:    */   public String h5Url;
/*  16:    */   public String dataUrl;
/*  17:    */   public String dataHdUrl;
/*  18:    */   public int duration;
/*  19: 53 */   public static final Parcelable.Creator<VoiceObject> CREATOR = new Parcelable.Creator()
/*  20:    */   {
/*  21:    */     public VoiceObject createFromParcel(Parcel in)
/*  22:    */     {
/*  23: 55 */       return new VoiceObject(in);
/*  24:    */     }
/*  25:    */     
/*  26:    */     public VoiceObject[] newArray(int size)
/*  27:    */     {
/*  28: 59 */       return new VoiceObject[size];
/*  29:    */     }
/*  30:    */   };
/*  31:    */   
/*  32:    */   public VoiceObject() {}
/*  33:    */   
/*  34:    */   public VoiceObject(Parcel in)
/*  35:    */   {
/*  36: 67 */     super(in);
/*  37: 68 */     this.h5Url = in.readString();
/*  38: 69 */     this.dataUrl = in.readString();
/*  39: 70 */     this.dataHdUrl = in.readString();
/*  40: 71 */     this.duration = in.readInt();
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void writeToParcel(Parcel dest, int flags)
/*  44:    */   {
/*  45: 76 */     super.writeToParcel(dest, flags);
/*  46: 77 */     dest.writeString(this.h5Url);
/*  47: 78 */     dest.writeString(this.dataUrl);
/*  48: 79 */     dest.writeString(this.dataHdUrl);
/*  49: 80 */     dest.writeInt(this.duration);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public boolean checkArgs()
/*  53:    */   {
/*  54: 85 */     if (!super.checkArgs()) {
/*  55: 86 */       return false;
/*  56:    */     }
/*  57: 88 */     if ((this.dataUrl != null) && (this.dataUrl.length() > 512))
/*  58:    */     {
/*  59: 89 */       LogUtil.e("Weibo.VoiceObject", "checkArgs fail, dataUrl is invalid");
/*  60: 90 */       return false;
/*  61:    */     }
/*  62: 92 */     if ((this.dataHdUrl != null) && (this.dataHdUrl.length() > 512))
/*  63:    */     {
/*  64: 93 */       LogUtil.e("Weibo.VoiceObject", "checkArgs fail, dataHdUrl is invalid");
/*  65: 94 */       return false;
/*  66:    */     }
/*  67: 96 */     if (this.duration <= 0)
/*  68:    */     {
/*  69: 97 */       LogUtil.e("Weibo.VoiceObject", "checkArgs fail, duration is invalid");
/*  70: 98 */       return false;
/*  71:    */     }
/*  72:100 */     return true;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public int getObjType()
/*  76:    */   {
/*  77:105 */     return 6;
/*  78:    */   }
/*  79:    */   
/*  80:    */   protected BaseMediaObject toExtraMediaObject(String str)
/*  81:    */   {
/*  82:110 */     if (!TextUtils.isEmpty(str)) {
/*  83:    */       try
/*  84:    */       {
/*  85:112 */         JSONObject json = new JSONObject(str);
/*  86:113 */         this.defaultText = json.optString("extra_key_defaulttext");
/*  87:    */       }
/*  88:    */       catch (JSONException localJSONException) {}
/*  89:    */     }
/*  90:117 */     return this;
/*  91:    */   }
/*  92:    */   
/*  93:    */   protected String toExtraMediaString()
/*  94:    */   {
/*  95:    */     try
/*  96:    */     {
/*  97:123 */       JSONObject json = new JSONObject();
/*  98:124 */       if (!TextUtils.isEmpty(this.defaultText)) {
/*  99:125 */         json.put("extra_key_defaulttext", this.defaultText);
/* 100:    */       }
/* 101:127 */       return json.toString();
/* 102:    */     }
/* 103:    */     catch (JSONException localJSONException) {}
/* 104:130 */     return "";
/* 105:    */   }
/* 106:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.VoiceObject
 * JD-Core Version:    0.7.0.1
 */