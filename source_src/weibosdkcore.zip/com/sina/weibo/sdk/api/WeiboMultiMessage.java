/*   1:    */ package com.sina.weibo.sdk.api;
/*   2:    */ 
/*   3:    */ import android.os.Bundle;
/*   4:    */ import com.sina.weibo.sdk.utils.LogUtil;
/*   5:    */ 
/*   6:    */ public final class WeiboMultiMessage
/*   7:    */ {
/*   8:    */   private static final String TAG = "WeiboMultiMessage";
/*   9:    */   public TextObject textObject;
/*  10:    */   public ImageObject imageObject;
/*  11:    */   public BaseMediaObject mediaObject;
/*  12:    */   
/*  13:    */   public WeiboMultiMessage() {}
/*  14:    */   
/*  15:    */   public WeiboMultiMessage(Bundle data)
/*  16:    */   {
/*  17: 48 */     toBundle(data);
/*  18:    */   }
/*  19:    */   
/*  20:    */   public Bundle toBundle(Bundle data)
/*  21:    */   {
/*  22: 52 */     if (this.textObject != null)
/*  23:    */     {
/*  24: 53 */       data.putParcelable("_weibo_message_text", this.textObject);
/*  25: 54 */       data.putString("_weibo_message_text_extra", this.textObject.toExtraMediaString());
/*  26:    */     }
/*  27: 56 */     if (this.imageObject != null)
/*  28:    */     {
/*  29: 57 */       data.putParcelable("_weibo_message_image", this.imageObject);
/*  30: 58 */       data.putString("_weibo_message_image_extra", this.imageObject.toExtraMediaString());
/*  31:    */     }
/*  32: 60 */     if (this.mediaObject != null)
/*  33:    */     {
/*  34: 61 */       data.putParcelable("_weibo_message_media", this.mediaObject);
/*  35: 62 */       data.putString("_weibo_message_media_extra", this.mediaObject.toExtraMediaString());
/*  36:    */     }
/*  37: 64 */     return data;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public WeiboMultiMessage toObject(Bundle data)
/*  41:    */   {
/*  42: 68 */     this.textObject = ((TextObject)data.getParcelable("_weibo_message_text"));
/*  43: 69 */     if (this.textObject != null) {
/*  44: 70 */       this.textObject.toExtraMediaObject(data.getString("_weibo_message_text_extra"));
/*  45:    */     }
/*  46: 72 */     this.imageObject = ((ImageObject)data.getParcelable("_weibo_message_image"));
/*  47: 73 */     if (this.imageObject != null) {
/*  48: 74 */       this.imageObject.toExtraMediaObject(data.getString("_weibo_message_image_extra"));
/*  49:    */     }
/*  50: 76 */     this.mediaObject = ((BaseMediaObject)data.getParcelable("_weibo_message_media"));
/*  51: 77 */     if (this.mediaObject != null) {
/*  52: 78 */       this.mediaObject.toExtraMediaObject(data.getString("_weibo_message_media_extra"));
/*  53:    */     }
/*  54: 80 */     return this;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public boolean checkArgs()
/*  58:    */   {
/*  59: 84 */     if ((this.textObject != null) && (!this.textObject.checkArgs()))
/*  60:    */     {
/*  61: 85 */       LogUtil.e("WeiboMultiMessage", "checkArgs fail, textObject is invalid");
/*  62: 86 */       return false;
/*  63:    */     }
/*  64: 88 */     if ((this.imageObject != null) && (!this.imageObject.checkArgs()))
/*  65:    */     {
/*  66: 89 */       LogUtil.e("WeiboMultiMessage", "checkArgs fail, imageObject is invalid");
/*  67: 90 */       return false;
/*  68:    */     }
/*  69: 92 */     if ((this.mediaObject != null) && (!this.mediaObject.checkArgs()))
/*  70:    */     {
/*  71: 93 */       LogUtil.e("WeiboMultiMessage", "checkArgs fail, mediaObject is invalid");
/*  72: 94 */       return false;
/*  73:    */     }
/*  74: 96 */     if ((this.textObject == null) && (this.imageObject == null) && (this.mediaObject == null))
/*  75:    */     {
/*  76: 97 */       LogUtil.e("WeiboMultiMessage", "checkArgs fail, textObject and imageObject and mediaObject is null");
/*  77: 98 */       return false;
/*  78:    */     }
/*  79:100 */     return true;
/*  80:    */   }
/*  81:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.WeiboMultiMessage
 * JD-Core Version:    0.7.0.1
 */