/*  1:   */ package com.sina.weibo.sdk.api;
/*  2:   */ 
/*  3:   */ import android.os.Bundle;
/*  4:   */ import com.sina.weibo.sdk.utils.LogUtil;
/*  5:   */ 
/*  6:   */ public final class WeiboMessage
/*  7:   */ {
/*  8:   */   public BaseMediaObject mediaObject;
/*  9:   */   
/* 10:   */   public WeiboMessage() {}
/* 11:   */   
/* 12:   */   public WeiboMessage(Bundle data)
/* 13:   */   {
/* 14:39 */     toBundle(data);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public Bundle toBundle(Bundle data)
/* 18:   */   {
/* 19:43 */     if (this.mediaObject != null)
/* 20:   */     {
/* 21:44 */       data.putParcelable("_weibo_message_media", this.mediaObject);
/* 22:45 */       data.putString("_weibo_message_media_extra", this.mediaObject.toExtraMediaString());
/* 23:   */     }
/* 24:47 */     return data;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public WeiboMessage toObject(Bundle data)
/* 28:   */   {
/* 29:51 */     this.mediaObject = ((BaseMediaObject)data.getParcelable("_weibo_message_media"));
/* 30:52 */     if (this.mediaObject != null) {
/* 31:53 */       this.mediaObject.toExtraMediaObject(data.getString("_weibo_message_media_extra"));
/* 32:   */     }
/* 33:55 */     return this;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public boolean checkArgs()
/* 37:   */   {
/* 38:59 */     if (this.mediaObject == null)
/* 39:   */     {
/* 40:60 */       LogUtil.e("Weibo.WeiboMessage", "checkArgs fail, mediaObject is null");
/* 41:61 */       return false;
/* 42:   */     }
/* 43:63 */     if ((this.mediaObject != null) && (!this.mediaObject.checkArgs()))
/* 44:   */     {
/* 45:64 */       LogUtil.e("Weibo.WeiboMessage", "checkArgs fail, mediaObject is invalid");
/* 46:65 */       return false;
/* 47:   */     }
/* 48:67 */     return true;
/* 49:   */   }
/* 50:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.WeiboMessage
 * JD-Core Version:    0.7.0.1
 */