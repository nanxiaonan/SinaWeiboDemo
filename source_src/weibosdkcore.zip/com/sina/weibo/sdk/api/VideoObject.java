/*   1:    */ package com.sina.weibo.sdk.api;
/*   2:    */ 
/*   3:    */ import android.os.Parcel;
/*   4:    */ import android.os.Parcelable.Creator;
/*   5:    */ import android.text.TextUtils;
/*   6:    */ import com.sina.weibo.sdk.utils.LogUtil;
/*   7:    */ import org.json.JSONException;
/*   8:    */ import org.json.JSONObject;
/*   9:    */ 
/*  10:    */ public class VideoObject
/*  11:    */   extends BaseMediaObject
/*  12:    */ {
/*  13:    */   public static final String EXTRA_KEY_DEFAULTTEXT = "extra_key_defaulttext";
/*  14:    */   public String defaultText;
/*  15:    */   public String h5Url;
/*  16:    */   public String dataUrl;
/*  17:    */   public String dataHdUrl;
/*  18:    */   public int duration;
/*  19: 54 */   public static final Parcelable.Creator<VideoObject> CREATOR = new Parcelable.Creator()
/*  20:    */   {
/*  21:    */     public VideoObject createFromParcel(Parcel in)
/*  22:    */     {
/*  23: 56 */       return new VideoObject(in);
/*  24:    */     }
/*  25:    */     
/*  26:    */     public VideoObject[] newArray(int size)
/*  27:    */     {
/*  28: 60 */       return new VideoObject[size];
/*  29:    */     }
/*  30:    */   };
/*  31:    */   
/*  32:    */   public VideoObject() {}
/*  33:    */   
/*  34:    */   public VideoObject(Parcel in)
/*  35:    */   {
/*  36: 68 */     super(in);
/*  37: 69 */     this.h5Url = in.readString();
/*  38: 70 */     this.dataUrl = in.readString();
/*  39: 71 */     this.dataHdUrl = in.readString();
/*  40: 72 */     this.duration = in.readInt();
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void writeToParcel(Parcel dest, int flags)
/*  44:    */   {
/*  45: 77 */     super.writeToParcel(dest, flags);
/*  46: 78 */     dest.writeString(this.h5Url);
/*  47: 79 */     dest.writeString(this.dataUrl);
/*  48: 80 */     dest.writeString(this.dataHdUrl);
/*  49: 81 */     dest.writeInt(this.duration);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public boolean checkArgs()
/*  53:    */   {
/*  54: 86 */     if (!super.checkArgs()) {
/*  55: 87 */       return false;
/*  56:    */     }
/*  57: 89 */     if ((this.dataUrl != null) && (this.dataUrl.length() > 512))
/*  58:    */     {
/*  59: 90 */       LogUtil.e("Weibo.VideoObject", "checkArgs fail, dataUrl is invalid");
/*  60: 91 */       return false;
/*  61:    */     }
/*  62: 93 */     if ((this.dataHdUrl != null) && (this.dataHdUrl.length() > 512))
/*  63:    */     {
/*  64: 94 */       LogUtil.e("Weibo.VideoObject", "checkArgs fail, dataHdUrl is invalid");
/*  65: 95 */       return false;
/*  66:    */     }
/*  67: 97 */     if (this.duration <= 0)
/*  68:    */     {
/*  69: 98 */       LogUtil.e("Weibo.VideoObject", "checkArgs fail, duration is invalid");
/*  70: 99 */       return false;
/*  71:    */     }
/*  72:101 */     return true;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public int getObjType()
/*  76:    */   {
/*  77:106 */     return 4;
/*  78:    */   }
/*  79:    */   
/*  80:    */   protected BaseMediaObject toExtraMediaObject(String str)
/*  81:    */   {
/*  82:111 */     if (!TextUtils.isEmpty(str)) {
/*  83:    */       try
/*  84:    */       {
/*  85:113 */         JSONObject json = new JSONObject(str);
/*  86:114 */         this.defaultText = json.optString("extra_key_defaulttext");
/*  87:    */       }
/*  88:    */       catch (JSONException localJSONException) {}
/*  89:    */     }
/*  90:118 */     return this;
/*  91:    */   }
/*  92:    */   
/*  93:    */   protected String toExtraMediaString()
/*  94:    */   {
/*  95:    */     try
/*  96:    */     {
/*  97:124 */       JSONObject json = new JSONObject();
/*  98:125 */       if (!TextUtils.isEmpty(this.defaultText)) {
/*  99:126 */         json.put("extra_key_defaulttext", this.defaultText);
/* 100:    */       }
/* 101:128 */       return json.toString();
/* 102:    */     }
/* 103:    */     catch (JSONException localJSONException) {}
/* 104:131 */     return "";
/* 105:    */   }
/* 106:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.api.VideoObject
 * JD-Core Version:    0.7.0.1
 */