/*  1:   */ package com.sina.weibo.sdk.exception;
/*  2:   */ 
/*  3:   */ public class WeiboShareException
/*  4:   */   extends WeiboException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 1L;
/*  7:   */   
/*  8:   */   public WeiboShareException() {}
/*  9:   */   
/* 10:   */   public WeiboShareException(String message)
/* 11:   */   {
/* 12:41 */     super(message);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public WeiboShareException(String detailMessage, Throwable throwable)
/* 16:   */   {
/* 17:51 */     super(detailMessage, throwable);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public WeiboShareException(Throwable throwable)
/* 21:   */   {
/* 22:60 */     super(throwable);
/* 23:   */   }
/* 24:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.exception.WeiboShareException
 * JD-Core Version:    0.7.0.1
 */