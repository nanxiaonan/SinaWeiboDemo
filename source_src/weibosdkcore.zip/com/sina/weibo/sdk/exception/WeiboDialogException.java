/*  1:   */ package com.sina.weibo.sdk.exception;
/*  2:   */ 
/*  3:   */ public class WeiboDialogException
/*  4:   */   extends WeiboException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 1L;
/*  7:   */   private int mErrorCode;
/*  8:   */   private String mFailingUrl;
/*  9:   */   
/* 10:   */   public WeiboDialogException(String message, int errorCode, String failingUrl)
/* 11:   */   {
/* 12:45 */     super(message);
/* 13:46 */     this.mErrorCode = errorCode;
/* 14:47 */     this.mFailingUrl = failingUrl;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public int getErrorCode()
/* 18:   */   {
/* 19:58 */     return this.mErrorCode;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getFailingUrl()
/* 23:   */   {
/* 24:67 */     return this.mFailingUrl;
/* 25:   */   }
/* 26:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.exception.WeiboDialogException
 * JD-Core Version:    0.7.0.1
 */