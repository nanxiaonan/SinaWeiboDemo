/*  1:   */ package com.sina.weibo.sdk.exception;
/*  2:   */ 
/*  3:   */ public class WeiboAuthException
/*  4:   */   extends WeiboException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 1L;
/*  7:   */   public static final String DEFAULT_AUTH_ERROR_CODE = "-1";
/*  8:   */   public static final String DEFAULT_AUTH_ERROR_DESC = "Unknown Error Description";
/*  9:   */   public static final String DEFAULT_AUTH_ERROR_TYPE = "Unknown Error Type";
/* 10:   */   private final String mErrorType;
/* 11:   */   private final String mErrorCode;
/* 12:   */   
/* 13:   */   public WeiboAuthException(String errorCode, String errorType, String errorDescription)
/* 14:   */   {
/* 15:63 */     super(errorDescription);
/* 16:64 */     this.mErrorType = errorType;
/* 17:65 */     this.mErrorCode = errorCode;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String getErrorType()
/* 21:   */   {
/* 22:74 */     return this.mErrorType;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public String getErrorCode()
/* 26:   */   {
/* 27:83 */     return this.mErrorCode;
/* 28:   */   }
/* 29:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.exception.WeiboAuthException
 * JD-Core Version:    0.7.0.1
 */