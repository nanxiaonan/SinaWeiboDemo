/*   1:    */ package com.sina.weibo.sdk.net;
/*   2:    */ 
/*   3:    */ import android.graphics.Bitmap;
/*   4:    */ import android.text.TextUtils;
/*   5:    */ import com.sina.weibo.sdk.utils.LogUtil;
/*   6:    */ import java.io.ByteArrayOutputStream;
/*   7:    */ import java.io.UnsupportedEncodingException;
/*   8:    */ import java.net.URLEncoder;
/*   9:    */ import java.util.LinkedHashMap;
/*  10:    */ import java.util.Set;
/*  11:    */ 
/*  12:    */ public class WeiboParameters
/*  13:    */ {
/*  14:    */   private static final String DEFAULT_CHARSET = "UTF-8";
/*  15: 39 */   private LinkedHashMap<String, Object> mParams = new LinkedHashMap();
/*  16:    */   
/*  17:    */   public LinkedHashMap<String, Object> getParams()
/*  18:    */   {
/*  19: 42 */     return this.mParams;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public void setParams(LinkedHashMap<String, Object> params)
/*  23:    */   {
/*  24: 46 */     this.mParams = params;
/*  25:    */   }
/*  26:    */   
/*  27:    */   @Deprecated
/*  28:    */   public void add(String key, String val)
/*  29:    */   {
/*  30: 51 */     this.mParams.put(key, val);
/*  31:    */   }
/*  32:    */   
/*  33:    */   @Deprecated
/*  34:    */   public void add(String key, int value)
/*  35:    */   {
/*  36: 56 */     this.mParams.put(key, String.valueOf(value));
/*  37:    */   }
/*  38:    */   
/*  39:    */   @Deprecated
/*  40:    */   public void add(String key, long value)
/*  41:    */   {
/*  42: 61 */     this.mParams.put(key, String.valueOf(value));
/*  43:    */   }
/*  44:    */   
/*  45:    */   @Deprecated
/*  46:    */   public void add(String key, Object val)
/*  47:    */   {
/*  48: 66 */     this.mParams.put(key, val.toString());
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void put(String key, String val)
/*  52:    */   {
/*  53: 70 */     this.mParams.put(key, val);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void put(String key, int value)
/*  57:    */   {
/*  58: 74 */     this.mParams.put(key, String.valueOf(value));
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void put(String key, long value)
/*  62:    */   {
/*  63: 78 */     this.mParams.put(key, String.valueOf(value));
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void put(String key, Bitmap bitmap)
/*  67:    */   {
/*  68: 82 */     this.mParams.put(key, bitmap);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void put(String key, Object val)
/*  72:    */   {
/*  73: 86 */     this.mParams.put(key, val.toString());
/*  74:    */   }
/*  75:    */   
/*  76:    */   public Object get(String key)
/*  77:    */   {
/*  78: 90 */     return this.mParams.get(key);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void remove(String key)
/*  82:    */   {
/*  83: 94 */     if (this.mParams.containsKey(key))
/*  84:    */     {
/*  85: 95 */       this.mParams.remove(key);
/*  86: 96 */       this.mParams.remove(this.mParams.get(key));
/*  87:    */     }
/*  88:    */   }
/*  89:    */   
/*  90:    */   public Set<String> keySet()
/*  91:    */   {
/*  92:101 */     return this.mParams.keySet();
/*  93:    */   }
/*  94:    */   
/*  95:    */   public boolean containsKey(String key)
/*  96:    */   {
/*  97:105 */     return this.mParams.containsKey(key);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public boolean containsValue(String value)
/* 101:    */   {
/* 102:109 */     return this.mParams.containsValue(value);
/* 103:    */   }
/* 104:    */   
/* 105:    */   public int size()
/* 106:    */   {
/* 107:113 */     return this.mParams.size();
/* 108:    */   }
/* 109:    */   
/* 110:    */   public String encodeUrl()
/* 111:    */   {
/* 112:118 */     StringBuilder sb = new StringBuilder();
/* 113:119 */     boolean first = true;
/* 114:120 */     for (String key : this.mParams.keySet())
/* 115:    */     {
/* 116:121 */       if (first) {
/* 117:122 */         first = false;
/* 118:    */       } else {
/* 119:124 */         sb.append("&");
/* 120:    */       }
/* 121:127 */       Object value = this.mParams.get(key);
/* 122:128 */       if ((value instanceof String))
/* 123:    */       {
/* 124:129 */         String param = (String)value;
/* 125:130 */         if (!TextUtils.isEmpty(param)) {
/* 126:    */           try
/* 127:    */           {
/* 128:132 */             sb.append(URLEncoder.encode(key, "UTF-8") + "=" + 
/* 129:133 */               URLEncoder.encode(param, "UTF-8"));
/* 130:    */           }
/* 131:    */           catch (UnsupportedEncodingException e)
/* 132:    */           {
/* 133:135 */             e.printStackTrace();
/* 134:    */           }
/* 135:    */         }
/* 136:138 */         LogUtil.i("encodeUrl", sb.toString());
/* 137:    */       }
/* 138:    */     }
/* 139:142 */     return sb.toString();
/* 140:    */   }
/* 141:    */   
/* 142:    */   public boolean hasBinaryData()
/* 143:    */   {
/* 144:146 */     Set<String> keys = this.mParams.keySet();
/* 145:147 */     for (String key : keys)
/* 146:    */     {
/* 147:148 */       Object value = this.mParams.get(key);
/* 148:149 */       if (((value instanceof ByteArrayOutputStream)) || 
/* 149:150 */         ((value instanceof Bitmap))) {
/* 150:151 */         return true;
/* 151:    */       }
/* 152:    */     }
/* 153:155 */     return false;
/* 154:    */   }
/* 155:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.net.WeiboParameters
 * JD-Core Version:    0.7.0.1
 */