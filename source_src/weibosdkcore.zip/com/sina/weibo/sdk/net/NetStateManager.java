/*  1:   */ package com.sina.weibo.sdk.net;
/*  2:   */ 
/*  3:   */ import android.content.BroadcastReceiver;
/*  4:   */ import android.content.ContentResolver;
/*  5:   */ import android.content.Context;
/*  6:   */ import android.content.Intent;
/*  7:   */ import android.database.Cursor;
/*  8:   */ import android.net.Uri;
/*  9:   */ import android.net.wifi.WifiInfo;
/* 10:   */ import android.net.wifi.WifiManager;
/* 11:   */ import org.apache.http.HttpHost;
/* 12:   */ 
/* 13:   */ public class NetStateManager
/* 14:   */ {
/* 15:   */   private static Context mContext;
/* 16:40 */   public static NetState CUR_NETSTATE = NetState.Mobile;
/* 17:   */   
/* 18:   */   public static enum NetState
/* 19:   */   {
/* 20:43 */     Mobile,  WIFI,  NOWAY;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public class NetStateReceive
/* 24:   */     extends BroadcastReceiver
/* 25:   */   {
/* 26:   */     public NetStateReceive() {}
/* 27:   */     
/* 28:   */     public void onReceive(Context context, Intent intent)
/* 29:   */     {
/* 30:49 */       NetStateManager.mContext = context;
/* 31:50 */       if ("android.net.conn.CONNECTIVITY_CHANGE".equals(intent.getAction()))
/* 32:   */       {
/* 33:51 */         WifiManager wifiManager = (WifiManager)context.getSystemService("wifi");
/* 34:52 */         WifiInfo info = wifiManager.getConnectionInfo();
/* 35:53 */         if ((!wifiManager.isWifiEnabled()) || (-1 == info.getNetworkId())) {
/* 36:54 */           NetStateManager.CUR_NETSTATE = NetStateManager.NetState.Mobile;
/* 37:   */         }
/* 38:   */       }
/* 39:   */     }
/* 40:   */   }
/* 41:   */   
/* 42:   */   public static HttpHost getAPN()
/* 43:   */   {
/* 44:66 */     HttpHost proxy = null;
/* 45:67 */     Uri uri = Uri.parse("content://telephony/carriers/preferapn");
/* 46:68 */     Cursor mCursor = null;
/* 47:69 */     if (mContext != null) {
/* 48:70 */       mCursor = mContext.getContentResolver().query(uri, null, null, null, null);
/* 49:   */     }
/* 50:72 */     if ((mCursor != null) && (mCursor.moveToFirst()))
/* 51:   */     {
/* 52:74 */       String proxyStr = mCursor.getString(mCursor.getColumnIndex("proxy"));
/* 53:75 */       if ((proxyStr != null) && (proxyStr.trim().length() > 0)) {
/* 54:76 */         proxy = new HttpHost(proxyStr, 80);
/* 55:   */       }
/* 56:78 */       mCursor.close();
/* 57:   */     }
/* 58:80 */     return proxy;
/* 59:   */   }
/* 60:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.net.NetStateManager
 * JD-Core Version:    0.7.0.1
 */