package com.sina.weibo.sdk.net;

import com.sina.weibo.sdk.exception.WeiboException;

public abstract interface RequestListener
{
  public abstract void onComplete(String paramString);
  
  public abstract void onWeiboException(WeiboException paramWeiboException);
}


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.net.RequestListener
 * JD-Core Version:    0.7.0.1
 */