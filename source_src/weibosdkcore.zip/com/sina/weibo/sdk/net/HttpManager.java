/*   1:    */ package com.sina.weibo.sdk.net;
/*   2:    */ 
/*   3:    */ import android.graphics.Bitmap;
/*   4:    */ import android.graphics.Bitmap.CompressFormat;
/*   5:    */ import com.sina.weibo.sdk.exception.WeiboException;
/*   6:    */ import com.sina.weibo.sdk.exception.WeiboHttpException;
/*   7:    */ import java.io.ByteArrayOutputStream;
/*   8:    */ import java.io.IOException;
/*   9:    */ import java.io.InputStream;
/*  10:    */ import java.io.OutputStream;
/*  11:    */ import java.security.KeyStore;
/*  12:    */ import java.security.cert.Certificate;
/*  13:    */ import java.security.cert.CertificateFactory;
/*  14:    */ import java.util.Set;
/*  15:    */ import java.util.zip.GZIPInputStream;
/*  16:    */ import org.apache.http.Header;
/*  17:    */ import org.apache.http.HttpEntity;
/*  18:    */ import org.apache.http.HttpResponse;
/*  19:    */ import org.apache.http.HttpVersion;
/*  20:    */ import org.apache.http.StatusLine;
/*  21:    */ import org.apache.http.client.HttpClient;
/*  22:    */ import org.apache.http.client.methods.HttpDelete;
/*  23:    */ import org.apache.http.client.methods.HttpGet;
/*  24:    */ import org.apache.http.client.methods.HttpPost;
/*  25:    */ import org.apache.http.client.methods.HttpUriRequest;
/*  26:    */ import org.apache.http.conn.ClientConnectionManager;
/*  27:    */ import org.apache.http.conn.scheme.PlainSocketFactory;
/*  28:    */ import org.apache.http.conn.scheme.Scheme;
/*  29:    */ import org.apache.http.conn.scheme.SchemeRegistry;
/*  30:    */ import org.apache.http.conn.ssl.SSLSocketFactory;
/*  31:    */ import org.apache.http.entity.ByteArrayEntity;
/*  32:    */ import org.apache.http.impl.client.DefaultHttpClient;
/*  33:    */ import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
/*  34:    */ import org.apache.http.params.BasicHttpParams;
/*  35:    */ import org.apache.http.params.HttpConnectionParams;
/*  36:    */ import org.apache.http.params.HttpParams;
/*  37:    */ import org.apache.http.params.HttpProtocolParams;
/*  38:    */ 
/*  39:    */ class HttpManager
/*  40:    */ {
/*  41: 67 */   private static final String BOUNDARY = ;
/*  42: 68 */   private static final String MP_BOUNDARY = "--" + BOUNDARY;
/*  43: 69 */   private static final String END_MP_BOUNDARY = "--" + BOUNDARY + "--";
/*  44:    */   private static final String MULTIPART_FORM_DATA = "multipart/form-data";
/*  45:    */   private static final String HTTP_METHOD_POST = "POST";
/*  46:    */   private static final String HTTP_METHOD_GET = "GET";
/*  47:    */   private static final int CONNECTION_TIMEOUT = 5000;
/*  48:    */   private static final int SOCKET_TIMEOUT = 20000;
/*  49:    */   private static final int BUFFER_SIZE = 8192;
/*  50:    */   private static SSLSocketFactory sSSLSocketFactory;
/*  51:    */   
/*  52:    */   public static String openUrl(String url, String method, WeiboParameters params)
/*  53:    */     throws WeiboException
/*  54:    */   {
/*  55: 91 */     HttpResponse response = requestHttpExecute(url, method, params);
/*  56: 92 */     return readRsponse(response);
/*  57:    */   }
/*  58:    */   
/*  59:    */   private static HttpResponse requestHttpExecute(String url, String method, WeiboParameters params)
/*  60:    */   {
/*  61:106 */     HttpResponse response = null;
/*  62:    */     try
/*  63:    */     {
/*  64:109 */       HttpClient client = getNewHttpClient();
/*  65:110 */       client.getParams().setParameter("http.route.default-proxy", NetStateManager.getAPN());
/*  66:    */       
/*  67:112 */       HttpUriRequest request = null;
/*  68:113 */       ByteArrayOutputStream baos = null;
/*  69:116 */       if (method.equals("GET"))
/*  70:    */       {
/*  71:117 */         url = url + "?" + params.encodeUrl();
/*  72:118 */         request = new HttpGet(url);
/*  73:    */       }
/*  74:120 */       else if (method.equals("POST"))
/*  75:    */       {
/*  76:121 */         HttpPost post = new HttpPost(url);
/*  77:122 */         request = post;
/*  78:    */         
/*  79:124 */         baos = new ByteArrayOutputStream();
/*  80:125 */         if (params.hasBinaryData())
/*  81:    */         {
/*  82:126 */           post.setHeader("Content-Type", "multipart/form-data; boundary=" + BOUNDARY);
/*  83:127 */           buildParams(baos, params);
/*  84:    */         }
/*  85:    */         else
/*  86:    */         {
/*  87:129 */           Object value = params.get("content-type");
/*  88:130 */           if ((value != null) && ((value instanceof String)))
/*  89:    */           {
/*  90:131 */             params.remove("content-type");
/*  91:132 */             post.setHeader("Content-Type", (String)value);
/*  92:    */           }
/*  93:    */           else
/*  94:    */           {
/*  95:134 */             post.setHeader("Content-Type", "application/x-www-form-urlencoded");
/*  96:    */           }
/*  97:138 */           String postParam = params.encodeUrl();
/*  98:139 */           baos.write(postParam.getBytes("UTF-8"));
/*  99:    */         }
/* 100:141 */         post.setEntity(new ByteArrayEntity(baos.toByteArray()));
/* 101:142 */         baos.close();
/* 102:    */       }
/* 103:144 */       else if (method.equals("DELETE"))
/* 104:    */       {
/* 105:145 */         request = new HttpDelete(url);
/* 106:    */       }
/* 107:149 */       response = client.execute(request);
/* 108:150 */       StatusLine status = response.getStatusLine();
/* 109:151 */       int statusCode = status.getStatusCode();
/* 110:154 */       if (statusCode != 200)
/* 111:    */       {
/* 112:155 */         String result = readRsponse(response);
/* 113:156 */         throw new WeiboHttpException(result, statusCode);
/* 114:    */       }
/* 115:    */     }
/* 116:    */     catch (IOException e)
/* 117:    */     {
/* 118:159 */       throw new WeiboException(e);
/* 119:    */     }
/* 120:162 */     return response;
/* 121:    */   }
/* 122:    */   
/* 123:    */   private static HttpClient getNewHttpClient()
/* 124:    */   {
/* 125:    */     try
/* 126:    */     {
/* 127:170 */       HttpParams params = new BasicHttpParams();
/* 128:171 */       HttpProtocolParams.setVersion(params, HttpVersion.HTTP_1_1);
/* 129:172 */       HttpProtocolParams.setContentCharset(params, "UTF-8");
/* 130:    */       
/* 131:174 */       SchemeRegistry registry = new SchemeRegistry();
/* 132:175 */       registry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
/* 133:176 */       registry.register(new Scheme("https", getSSLSocketFactory(), 443));
/* 134:    */       
/* 135:178 */       ClientConnectionManager ccm = new ThreadSafeClientConnManager(params, registry);
/* 136:179 */       HttpConnectionParams.setConnectionTimeout(params, 5000);
/* 137:180 */       HttpConnectionParams.setSoTimeout(params, 20000);
/* 138:181 */       return new DefaultHttpClient(ccm, params);
/* 139:    */     }
/* 140:    */     catch (Exception e) {}
/* 141:184 */     return new DefaultHttpClient();
/* 142:    */   }
/* 143:    */   
/* 144:    */   private static void buildParams(OutputStream baos, WeiboParameters params)
/* 145:    */     throws WeiboException
/* 146:    */   {
/* 147:    */     try
/* 148:    */     {
/* 149:198 */       Set<String> keys = params.keySet();
/* 150:201 */       for (String key : keys)
/* 151:    */       {
/* 152:202 */         Object value = params.get(key);
/* 153:203 */         if ((value instanceof String))
/* 154:    */         {
/* 155:204 */           StringBuilder sb = new StringBuilder(100);
/* 156:205 */           sb.setLength(0);
/* 157:206 */           sb.append(MP_BOUNDARY).append("\r\n");
/* 158:207 */           sb.append("content-disposition: form-data; name=\"").append(key).append("\"\r\n\r\n");
/* 159:208 */           sb.append(params.get(key)).append("\r\n");
/* 160:    */           
/* 161:210 */           baos.write(sb.toString().getBytes());
/* 162:    */         }
/* 163:    */       }
/* 164:215 */       for (String key : keys)
/* 165:    */       {
/* 166:216 */         Object value = params.get(key);
/* 167:217 */         if ((value instanceof Bitmap))
/* 168:    */         {
/* 169:218 */           StringBuilder sb = new StringBuilder();
/* 170:219 */           sb.append(MP_BOUNDARY).append("\r\n");
/* 171:220 */           sb.append("content-disposition: form-data; name=\"").append(key).append("\"; filename=\"file\"\r\n");
/* 172:221 */           sb.append("Content-Type: application/octet-stream; charset=utf-8\r\n\r\n");
/* 173:222 */           baos.write(sb.toString().getBytes());
/* 174:    */           
/* 175:224 */           Bitmap bmp = (Bitmap)value;
/* 176:225 */           ByteArrayOutputStream stream = new ByteArrayOutputStream();
/* 177:226 */           bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
/* 178:227 */           byte[] bytes = stream.toByteArray();
/* 179:    */           
/* 180:229 */           baos.write(bytes);
/* 181:230 */           baos.write("\r\n".getBytes());
/* 182:    */         }
/* 183:231 */         else if ((value instanceof ByteArrayOutputStream))
/* 184:    */         {
/* 185:232 */           StringBuilder sb = new StringBuilder();
/* 186:233 */           sb.append(MP_BOUNDARY).append("\r\n");
/* 187:234 */           sb.append("content-disposition: form-data; name=\"").append(key).append("\"; filename=\"file\"\r\n");
/* 188:235 */           sb.append("Content-Type: application/octet-stream; charset=utf-8\r\n\r\n");
/* 189:236 */           baos.write(sb.toString().getBytes());
/* 190:    */           
/* 191:238 */           ByteArrayOutputStream stream = (ByteArrayOutputStream)value;
/* 192:239 */           baos.write(stream.toByteArray());
/* 193:240 */           baos.write("\r\n".getBytes());
/* 194:241 */           stream.close();
/* 195:    */         }
/* 196:    */       }
/* 197:244 */       baos.write(("\r\n" + END_MP_BOUNDARY).getBytes());
/* 198:    */     }
/* 199:    */     catch (IOException e)
/* 200:    */     {
/* 201:246 */       throw new WeiboException(e);
/* 202:    */     }
/* 203:    */   }
/* 204:    */   
/* 205:    */   private static String readRsponse(HttpResponse response)
/* 206:    */     throws WeiboException
/* 207:    */   {
/* 208:259 */     if (response == null) {
/* 209:260 */       return null;
/* 210:    */     }
/* 211:263 */     HttpEntity entity = response.getEntity();
/* 212:264 */     InputStream inputStream = null;
/* 213:265 */     ByteArrayOutputStream content = new ByteArrayOutputStream();
/* 214:    */     try
/* 215:    */     {
/* 216:267 */       inputStream = entity.getContent();
/* 217:268 */       Header header = response.getFirstHeader("Content-Encoding");
/* 218:269 */       if ((header != null) && (header.getValue().toLowerCase().indexOf("gzip") > -1)) {
/* 219:270 */         inputStream = new GZIPInputStream(inputStream);
/* 220:    */       }
/* 221:273 */       int readBytes = 0;
/* 222:274 */       byte[] buffer = new byte[8192];
/* 223:275 */       while ((readBytes = inputStream.read(buffer)) != -1) {
/* 224:276 */         content.write(buffer, 0, readBytes);
/* 225:    */       }
/* 226:279 */       return new String(content.toByteArray(), "UTF-8");
/* 227:    */     }
/* 228:    */     catch (IOException e)
/* 229:    */     {
/* 230:281 */       throw new WeiboException(e);
/* 231:    */     }
/* 232:    */     finally
/* 233:    */     {
/* 234:283 */       if (inputStream != null) {
/* 235:    */         try
/* 236:    */         {
/* 237:285 */           inputStream.close();
/* 238:    */         }
/* 239:    */         catch (IOException e)
/* 240:    */         {
/* 241:287 */           e.printStackTrace();
/* 242:    */         }
/* 243:    */       }
/* 244:    */     }
/* 245:    */   }
/* 246:    */   
/* 247:    */   private static String getBoundry()
/* 248:    */   {
/* 249:297 */     StringBuffer sb = new StringBuffer();
/* 250:298 */     for (int t = 1; t < 12; t++)
/* 251:    */     {
/* 252:299 */       long time = System.currentTimeMillis() + t;
/* 253:300 */       if (time % 3L == 0L) {
/* 254:301 */         sb.append((char)(int)time % '\t');
/* 255:302 */       } else if (time % 3L == 1L) {
/* 256:303 */         sb.append((char)(int)(65L + time % 26L));
/* 257:    */       } else {
/* 258:305 */         sb.append((char)(int)(97L + time % 26L));
/* 259:    */       }
/* 260:    */     }
/* 261:308 */     return sb.toString();
/* 262:    */   }
/* 263:    */   
/* 264:    */   private static SSLSocketFactory getSSLSocketFactory()
/* 265:    */   {
/* 266:313 */     if (sSSLSocketFactory == null) {
/* 267:    */       try
/* 268:    */       {
/* 269:317 */         CertificateFactory cf = CertificateFactory.getInstance("X.509");
/* 270:318 */         InputStream caInput = HttpManager.class.getResourceAsStream("cacert.cer");
/* 271:    */         Certificate ca;
/* 272:    */         try
/* 273:    */         {
/* 274:321 */           ca = cf.generateCertificate(caInput);
/* 275:    */         }
/* 276:    */         finally
/* 277:    */         {
/* 278:    */           Certificate ca;
/* 279:323 */           caInput.close();
/* 280:    */         }
/* 281:327 */         String keyStoreType = KeyStore.getDefaultType();
/* 282:328 */         KeyStore keyStore = KeyStore.getInstance(keyStoreType);
/* 283:329 */         keyStore.load(null, null);
/* 284:330 */         keyStore.setCertificateEntry("ca", ca);
/* 285:    */         
/* 286:332 */         sSSLSocketFactory = new SSLSocketFactory(keyStore);
/* 287:    */       }
/* 288:    */       catch (Exception e)
/* 289:    */       {
/* 290:334 */         e.printStackTrace();
/* 291:    */         
/* 292:336 */         sSSLSocketFactory = SSLSocketFactory.getSocketFactory();
/* 293:    */       }
/* 294:    */     }
/* 295:339 */     return sSSLSocketFactory;
/* 296:    */   }
/* 297:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.net.HttpManager
 * JD-Core Version:    0.7.0.1
 */