/*   1:    */ package com.sina.weibo.sdk.net;
/*   2:    */ 
/*   3:    */ import android.os.AsyncTask;
/*   4:    */ import com.sina.weibo.sdk.exception.WeiboException;
/*   5:    */ 
/*   6:    */ public class AsyncWeiboRunner
/*   7:    */ {
/*   8:    */   @Deprecated
/*   9:    */   public static void requestByThread(String url, final WeiboParameters params, final String httpMethod, final RequestListener listener)
/*  10:    */   {
/*  11: 60 */     new Thread()
/*  12:    */     {
/*  13:    */       public void run()
/*  14:    */       {
/*  15:    */         try
/*  16:    */         {
/*  17: 50 */           String resp = HttpManager.openUrl(AsyncWeiboRunner.this, httpMethod, params);
/*  18: 51 */           if (listener != null) {
/*  19: 52 */             listener.onComplete(resp);
/*  20:    */           }
/*  21:    */         }
/*  22:    */         catch (WeiboException e)
/*  23:    */         {
/*  24: 55 */           if (listener != null) {
/*  25: 56 */             listener.onWeiboException(e);
/*  26:    */           }
/*  27:    */         }
/*  28:    */       }
/*  29:    */     }.start();
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static String request(String url, WeiboParameters params, String httpMethod)
/*  33:    */     throws WeiboException
/*  34:    */   {
/*  35: 76 */     return HttpManager.openUrl(url, httpMethod, params);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static void requestAsync(String url, WeiboParameters params, String httpMethod, RequestListener listener)
/*  39:    */   {
/*  40: 93 */     new RequestRunner(url, params, httpMethod, listener).execute(new Void[1]);
/*  41:    */   }
/*  42:    */   
/*  43:    */   private static class RequestRunner
/*  44:    */     extends AsyncTask<Void, Void, AsyncWeiboRunner.AsyncTaskResult<String>>
/*  45:    */   {
/*  46:    */     private final String mUrl;
/*  47:    */     private final WeiboParameters mParams;
/*  48:    */     private final String mHttpMethod;
/*  49:    */     private final RequestListener mListener;
/*  50:    */     
/*  51:    */     public RequestRunner(String url, WeiboParameters params, String httpMethod, RequestListener listener)
/*  52:    */     {
/*  53:112 */       this.mUrl = url;
/*  54:113 */       this.mParams = params;
/*  55:114 */       this.mHttpMethod = httpMethod;
/*  56:115 */       this.mListener = listener;
/*  57:    */     }
/*  58:    */     
/*  59:    */     protected AsyncWeiboRunner.AsyncTaskResult<String> doInBackground(Void... params)
/*  60:    */     {
/*  61:    */       try
/*  62:    */       {
/*  63:121 */         String result = HttpManager.openUrl(this.mUrl, this.mHttpMethod, this.mParams);
/*  64:122 */         return new AsyncWeiboRunner.AsyncTaskResult(result);
/*  65:    */       }
/*  66:    */       catch (WeiboException e)
/*  67:    */       {
/*  68:125 */         return new AsyncWeiboRunner.AsyncTaskResult(e);
/*  69:    */       }
/*  70:    */     }
/*  71:    */     
/*  72:    */     protected void onPreExecute() {}
/*  73:    */     
/*  74:    */     protected void onPostExecute(AsyncWeiboRunner.AsyncTaskResult<String> result)
/*  75:    */     {
/*  76:135 */       WeiboException exception = result.getError();
/*  77:136 */       if (exception != null) {
/*  78:137 */         this.mListener.onWeiboException(exception);
/*  79:    */       } else {
/*  80:139 */         this.mListener.onComplete((String)result.getResult());
/*  81:    */       }
/*  82:    */     }
/*  83:    */   }
/*  84:    */   
/*  85:    */   private static class AsyncTaskResult<T>
/*  86:    */   {
/*  87:    */     private T result;
/*  88:    */     private WeiboException error;
/*  89:    */     
/*  90:    */     public T getResult()
/*  91:    */     {
/*  92:149 */       return this.result;
/*  93:    */     }
/*  94:    */     
/*  95:    */     public WeiboException getError()
/*  96:    */     {
/*  97:153 */       return this.error;
/*  98:    */     }
/*  99:    */     
/* 100:    */     public AsyncTaskResult(T result)
/* 101:    */     {
/* 102:158 */       this.result = result;
/* 103:    */     }
/* 104:    */     
/* 105:    */     public AsyncTaskResult(WeiboException error)
/* 106:    */     {
/* 107:163 */       this.error = error;
/* 108:    */     }
/* 109:    */   }
/* 110:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.net.AsyncWeiboRunner
 * JD-Core Version:    0.7.0.1
 */