package com.sina.weibo.sdk;

public final class BuildConfig
{
  public static final boolean DEBUG = true;
}


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.BuildConfig
 * JD-Core Version:    0.7.0.1
 */