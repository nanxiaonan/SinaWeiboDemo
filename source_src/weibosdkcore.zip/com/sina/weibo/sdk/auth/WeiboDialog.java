/*   1:    */ package com.sina.weibo.sdk.auth;
/*   2:    */ 
/*   3:    */ import android.annotation.SuppressLint;
/*   4:    */ import android.app.Dialog;
/*   5:    */ import android.app.ProgressDialog;
/*   6:    */ import android.content.Context;
/*   7:    */ import android.content.Intent;
/*   8:    */ import android.content.res.Resources;
/*   9:    */ import android.graphics.Bitmap;
/*  10:    */ import android.graphics.drawable.Drawable;
/*  11:    */ import android.os.Bundle;
/*  12:    */ import android.util.DisplayMetrics;
/*  13:    */ import android.view.View;
/*  14:    */ import android.view.View.OnClickListener;
/*  15:    */ import android.view.ViewGroup.LayoutParams;
/*  16:    */ import android.view.Window;
/*  17:    */ import android.webkit.WebSettings;
/*  18:    */ import android.webkit.WebView;
/*  19:    */ import android.webkit.WebViewClient;
/*  20:    */ import android.widget.ImageView;
/*  21:    */ import android.widget.RelativeLayout;
/*  22:    */ import android.widget.RelativeLayout.LayoutParams;
/*  23:    */ import com.sina.weibo.sdk.exception.WeiboAuthException;
/*  24:    */ import com.sina.weibo.sdk.exception.WeiboDialogException;
/*  25:    */ import com.sina.weibo.sdk.utils.LogUtil;
/*  26:    */ import com.sina.weibo.sdk.utils.NetworkHelper;
/*  27:    */ import com.sina.weibo.sdk.utils.ResourceManager;
/*  28:    */ import com.sina.weibo.sdk.utils.Utility;
/*  29:    */ 
/*  30:    */ public class WeiboDialog
/*  31:    */   extends Dialog
/*  32:    */ {
/*  33:    */   private static final String TAG = "WeiboDialog";
/*  34:    */   private static final int WEBVIEW_CONTAINER_MARGIN_TOP = 25;
/*  35:    */   private static final int WEBVIEW_MARGIN = 10;
/*  36:    */   private Context mContext;
/*  37:    */   private RelativeLayout mRootContainer;
/*  38:    */   private RelativeLayout mWebViewContainer;
/*  39:    */   private ProgressDialog mLoadingDlg;
/*  40:    */   private WebView mWebView;
/*  41: 73 */   private boolean mIsDetached = false;
/*  42:    */   private String mAuthUrl;
/*  43:    */   private WeiboAuthListener mListener;
/*  44:    */   private WeiboAuth mWeibo;
/*  45: 83 */   private static int theme = 16973840;
/*  46:    */   
/*  47:    */   public WeiboDialog(Context context, String authUrl, WeiboAuthListener listener, WeiboAuth weibo)
/*  48:    */   {
/*  49: 93 */     super(context, theme);
/*  50: 94 */     this.mAuthUrl = authUrl;
/*  51: 95 */     this.mListener = listener;
/*  52: 96 */     this.mContext = context;
/*  53: 97 */     this.mWeibo = weibo;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void onBackPressed()
/*  57:    */   {
/*  58:106 */     super.onBackPressed();
/*  59:108 */     if (this.mListener != null) {
/*  60:109 */       this.mListener.onCancel();
/*  61:    */     }
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void dismiss()
/*  65:    */   {
/*  66:119 */     if (!this.mIsDetached)
/*  67:    */     {
/*  68:120 */       if ((this.mLoadingDlg != null) && (this.mLoadingDlg.isShowing())) {
/*  69:121 */         this.mLoadingDlg.dismiss();
/*  70:    */       }
/*  71:124 */       super.dismiss();
/*  72:    */     }
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void onAttachedToWindow()
/*  76:    */   {
/*  77:130 */     this.mIsDetached = false;
/*  78:131 */     super.onAttachedToWindow();
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void onDetachedFromWindow()
/*  82:    */   {
/*  83:139 */     if (this.mWebView != null)
/*  84:    */     {
/*  85:140 */       this.mWebViewContainer.removeView(this.mWebView);
/*  86:141 */       this.mWebView.stopLoading();
/*  87:142 */       this.mWebView.removeAllViews();
/*  88:143 */       this.mWebView.destroy();
/*  89:144 */       this.mWebView = null;
/*  90:    */     }
/*  91:147 */     this.mIsDetached = true;
/*  92:148 */     super.onDetachedFromWindow();
/*  93:    */   }
/*  94:    */   
/*  95:    */   protected void onCreate(Bundle savedInstanceState)
/*  96:    */   {
/*  97:157 */     super.onCreate(savedInstanceState);
/*  98:    */     
/*  99:    */ 
/* 100:160 */     initWindow();
/* 101:    */     
/* 102:162 */     initLoadingDlg();
/* 103:    */     
/* 104:164 */     initWebView();
/* 105:    */     
/* 106:166 */     initCloseButton();
/* 107:    */   }
/* 108:    */   
/* 109:    */   private void initWindow()
/* 110:    */   {
/* 111:173 */     requestWindowFeature(1);
/* 112:174 */     getWindow().setFeatureDrawableAlpha(0, 0);
/* 113:175 */     getWindow().setSoftInputMode(16);
/* 114:    */     
/* 115:177 */     this.mRootContainer = new RelativeLayout(getContext());
/* 116:178 */     this.mRootContainer.setBackgroundColor(0);
/* 117:179 */     addContentView(this.mRootContainer, new ViewGroup.LayoutParams(-1, -1));
/* 118:    */   }
/* 119:    */   
/* 120:    */   private void initLoadingDlg()
/* 121:    */   {
/* 122:187 */     this.mLoadingDlg = new ProgressDialog(getContext());
/* 123:    */     
/* 124:189 */     this.mLoadingDlg.requestWindowFeature(1);
/* 125:    */     
/* 126:191 */     this.mLoadingDlg.setMessage(ResourceManager.getString(this.mContext, 1));
/* 127:    */   }
/* 128:    */   
/* 129:    */   @SuppressLint({"SetJavaScriptEnabled"})
/* 130:    */   private void initWebView()
/* 131:    */   {
/* 132:199 */     this.mWebViewContainer = new RelativeLayout(getContext());
/* 133:200 */     this.mWebView = new WebView(getContext());
/* 134:201 */     this.mWebView.getSettings().setJavaScriptEnabled(true);
/* 135:    */     
/* 136:203 */     this.mWebView.getSettings().setSavePassword(false);
/* 137:204 */     this.mWebView.setWebViewClient(new WeiboWebViewClient(null));
/* 138:205 */     this.mWebView.requestFocus();
/* 139:206 */     this.mWebView.setScrollBarStyle(0);
/* 140:207 */     this.mWebView.setVisibility(4);
/* 141:    */     
/* 142:    */ 
/* 143:210 */     NetworkHelper.clearCookies(this.mContext, this.mAuthUrl);
/* 144:211 */     this.mWebView.loadUrl(this.mAuthUrl);
/* 145:    */     
/* 146:213 */     RelativeLayout.LayoutParams webViewContainerLayout = new RelativeLayout.LayoutParams(
/* 147:214 */       -1, -1);
/* 148:    */     
/* 149:216 */     RelativeLayout.LayoutParams webviewLayout = new RelativeLayout.LayoutParams(
/* 150:217 */       -1, -1);
/* 151:    */     
/* 152:    */ 
/* 153:220 */     DisplayMetrics dm = getContext().getResources().getDisplayMetrics();
/* 154:221 */     float density = dm.density;
/* 155:222 */     int margin = (int)(10.0F * density);
/* 156:223 */     webviewLayout.setMargins(margin, margin, margin, margin);
/* 157:224 */     Drawable background = ResourceManager.getNinePatchDrawable(this.mContext, 1);
/* 158:    */     
/* 159:226 */     this.mWebViewContainer.setBackgroundDrawable(background);
/* 160:    */     
/* 161:    */ 
/* 162:229 */     this.mWebViewContainer.addView(this.mWebView, webviewLayout);
/* 163:230 */     this.mWebViewContainer.setGravity(17);
/* 164:    */     
/* 165:232 */     Drawable drawable = ResourceManager.getDrawable(this.mContext, 2);
/* 166:233 */     int width = drawable.getIntrinsicWidth() / 2 + 1;
/* 167:    */     
/* 168:    */ 
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:242 */     webViewContainerLayout.setMargins(width, (int)(25.0F * dm.density), width, width);
/* 176:243 */     this.mRootContainer.addView(this.mWebViewContainer, webViewContainerLayout);
/* 177:    */   }
/* 178:    */   
/* 179:    */   private void initCloseButton()
/* 180:    */   {
/* 181:250 */     ImageView closeImage = new ImageView(this.mContext);
/* 182:251 */     Drawable drawable = ResourceManager.getDrawable(this.mContext, 2);
/* 183:252 */     closeImage.setImageDrawable(drawable);
/* 184:253 */     closeImage.setOnClickListener(new View.OnClickListener()
/* 185:    */     {
/* 186:    */       public void onClick(View v)
/* 187:    */       {
/* 188:256 */         WeiboDialog.this.dismiss();
/* 189:258 */         if (WeiboDialog.this.mListener != null) {
/* 190:259 */           WeiboDialog.this.mListener.onCancel();
/* 191:    */         }
/* 192:    */       }
/* 193:265 */     });
/* 194:266 */     RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(
/* 195:267 */       -2, -2);
/* 196:268 */     RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams)this.mWebViewContainer.getLayoutParams();
/* 197:269 */     layoutParams.leftMargin = (params.leftMargin - drawable.getIntrinsicWidth() / 2 + 5);
/* 198:270 */     layoutParams.topMargin = (params.topMargin - drawable.getIntrinsicHeight() / 2 + 5);
/* 199:271 */     this.mRootContainer.addView(closeImage, layoutParams);
/* 200:    */   }
/* 201:    */   
/* 202:    */   private class WeiboWebViewClient
/* 203:    */     extends WebViewClient
/* 204:    */   {
/* 205:279 */     private boolean isCallBacked = false;
/* 206:    */     
/* 207:    */     private WeiboWebViewClient() {}
/* 208:    */     
/* 209:    */     public boolean shouldOverrideUrlLoading(WebView view, String url)
/* 210:    */     {
/* 211:283 */       LogUtil.i("WeiboDialog", "load URL: " + url);
/* 212:286 */       if (url.startsWith("sms:"))
/* 213:    */       {
/* 214:287 */         Intent sendIntent = new Intent("android.intent.action.VIEW");
/* 215:288 */         sendIntent.putExtra("address", url.replace("sms:", ""));
/* 216:289 */         sendIntent.setType("vnd.android-dir/mms-sms");
/* 217:290 */         WeiboDialog.this.getContext().startActivity(sendIntent);
/* 218:291 */         return true;
/* 219:    */       }
/* 220:293 */       return super.shouldOverrideUrlLoading(view, url);
/* 221:    */     }
/* 222:    */     
/* 223:    */     public void onReceivedError(WebView view, int errorCode, String description, String failingUrl)
/* 224:    */     {
/* 225:298 */       LogUtil.d("WeiboDialog", "onReceivedError: errorCode = " + errorCode + 
/* 226:299 */         ", description = " + description + 
/* 227:300 */         ", failingUrl = " + failingUrl);
/* 228:301 */       super.onReceivedError(view, errorCode, description, failingUrl);
/* 229:303 */       if (WeiboDialog.this.mListener != null) {
/* 230:304 */         WeiboDialog.this.mListener.onWeiboException(new WeiboDialogException(description, errorCode, failingUrl));
/* 231:    */       }
/* 232:306 */       WeiboDialog.this.dismiss();
/* 233:    */     }
/* 234:    */     
/* 235:    */     public void onPageStarted(WebView view, String url, Bitmap favicon)
/* 236:    */     {
/* 237:311 */       LogUtil.d("WeiboDialog", "onPageStarted URL: " + url);
/* 238:312 */       if ((url.startsWith(WeiboDialog.this.mWeibo.getAuthInfo().getRedirectUrl())) && 
/* 239:313 */         (!this.isCallBacked))
/* 240:    */       {
/* 241:314 */         this.isCallBacked = true;
/* 242:315 */         WeiboDialog.this.handleRedirectUrl(url);
/* 243:316 */         view.stopLoading();
/* 244:317 */         WeiboDialog.this.dismiss();
/* 245:    */         
/* 246:319 */         return;
/* 247:    */       }
/* 248:322 */       super.onPageStarted(view, url, favicon);
/* 249:324 */       if ((!WeiboDialog.this.mIsDetached) && (WeiboDialog.this.mLoadingDlg != null) && (!WeiboDialog.this.mLoadingDlg.isShowing())) {
/* 250:325 */         WeiboDialog.this.mLoadingDlg.show();
/* 251:    */       }
/* 252:    */     }
/* 253:    */     
/* 254:    */     public void onPageFinished(WebView view, String url)
/* 255:    */     {
/* 256:331 */       LogUtil.d("WeiboDialog", "onPageFinished URL: " + url);
/* 257:332 */       super.onPageFinished(view, url);
/* 258:333 */       if ((!WeiboDialog.this.mIsDetached) && (WeiboDialog.this.mLoadingDlg != null)) {
/* 259:334 */         WeiboDialog.this.mLoadingDlg.dismiss();
/* 260:    */       }
/* 261:337 */       if (WeiboDialog.this.mWebView != null) {
/* 262:338 */         WeiboDialog.this.mWebView.setVisibility(0);
/* 263:    */       }
/* 264:    */     }
/* 265:    */   }
/* 266:    */   
/* 267:    */   private void handleRedirectUrl(String url)
/* 268:    */   {
/* 269:355 */     Bundle values = Utility.parseUrl(url);
/* 270:    */     
/* 271:357 */     String errorType = values.getString("error");
/* 272:358 */     String errorCode = values.getString("error_code");
/* 273:359 */     String errorDescription = values.getString("error_description");
/* 274:361 */     if ((errorType == null) && (errorCode == null)) {
/* 275:362 */       this.mListener.onComplete(values);
/* 276:    */     } else {
/* 277:364 */       this.mListener.onWeiboException(
/* 278:365 */         new WeiboAuthException(errorCode, errorType, errorDescription));
/* 279:    */     }
/* 280:    */   }
/* 281:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.auth.WeiboDialog
 * JD-Core Version:    0.7.0.1
 */