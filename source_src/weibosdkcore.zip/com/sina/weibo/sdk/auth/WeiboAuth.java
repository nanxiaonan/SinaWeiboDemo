/*   1:    */ package com.sina.weibo.sdk.auth;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.os.Bundle;
/*   5:    */ import com.sina.weibo.sdk.net.WeiboParameters;
/*   6:    */ import com.sina.weibo.sdk.utils.LogUtil;
/*   7:    */ import com.sina.weibo.sdk.utils.NetworkHelper;
/*   8:    */ import com.sina.weibo.sdk.utils.ResourceManager;
/*   9:    */ import com.sina.weibo.sdk.utils.UIUtils;
/*  10:    */ import com.sina.weibo.sdk.utils.Utility;
/*  11:    */ 
/*  12:    */ public class WeiboAuth
/*  13:    */ {
/*  14:    */   public static final String TAG = "Weibo_web_login";
/*  15:    */   private static final String OAUTH2_BASE_URL = "https://open.weibo.cn/oauth2/authorize?";
/*  16:    */   public static final int OBTAIN_AUTH_CODE = 0;
/*  17:    */   public static final int OBTAIN_AUTH_TOKEN = 1;
/*  18:    */   private Context mContext;
/*  19:    */   private AuthInfo mAuthInfo;
/*  20:    */   
/*  21:    */   public static class AuthInfo
/*  22:    */   {
/*  23: 58 */     private String mAppKey = "";
/*  24: 60 */     private String mRedirectUrl = "";
/*  25: 62 */     private String mScope = "";
/*  26: 64 */     private String mPackageName = "";
/*  27: 66 */     private String mKeyHash = "";
/*  28: 68 */     private Bundle mBundle = null;
/*  29:    */     
/*  30:    */     public AuthInfo(Context context, String appKey, String redirectUrl, String scope)
/*  31:    */     {
/*  32: 71 */       this.mAppKey = appKey;
/*  33: 72 */       this.mRedirectUrl = redirectUrl;
/*  34: 73 */       this.mScope = scope;
/*  35:    */       
/*  36: 75 */       this.mPackageName = context.getPackageName();
/*  37: 76 */       this.mKeyHash = Utility.getSign(context, this.mPackageName);
/*  38:    */       
/*  39: 78 */       initAuthBundle();
/*  40:    */     }
/*  41:    */     
/*  42:    */     public String getAppKey()
/*  43:    */     {
/*  44: 82 */       return this.mAppKey;
/*  45:    */     }
/*  46:    */     
/*  47:    */     public String getRedirectUrl()
/*  48:    */     {
/*  49: 86 */       return this.mRedirectUrl;
/*  50:    */     }
/*  51:    */     
/*  52:    */     public String getScope()
/*  53:    */     {
/*  54: 90 */       return this.mScope;
/*  55:    */     }
/*  56:    */     
/*  57:    */     public String getPackageName()
/*  58:    */     {
/*  59: 94 */       return this.mPackageName;
/*  60:    */     }
/*  61:    */     
/*  62:    */     public String getKeyHash()
/*  63:    */     {
/*  64: 98 */       return this.mKeyHash;
/*  65:    */     }
/*  66:    */     
/*  67:    */     public Bundle getAuthBundle()
/*  68:    */     {
/*  69:102 */       return this.mBundle;
/*  70:    */     }
/*  71:    */     
/*  72:    */     private void initAuthBundle()
/*  73:    */     {
/*  74:106 */       this.mBundle = new Bundle();
/*  75:107 */       this.mBundle.putString("appKey", this.mAppKey);
/*  76:108 */       this.mBundle.putString("redirectUri", this.mRedirectUrl);
/*  77:109 */       this.mBundle.putString("scope", this.mScope);
/*  78:110 */       this.mBundle.putString("packagename", this.mPackageName);
/*  79:111 */       this.mBundle.putString("key_hash", this.mKeyHash);
/*  80:    */     }
/*  81:    */   }
/*  82:    */   
/*  83:    */   public WeiboAuth(Context context, String appKey, String redirectUrl, String scope)
/*  84:    */   {
/*  85:126 */     this.mContext = context;
/*  86:127 */     this.mAuthInfo = new AuthInfo(context, appKey, redirectUrl, scope);
/*  87:    */   }
/*  88:    */   
/*  89:    */   public WeiboAuth(Context context, AuthInfo authInfo)
/*  90:    */   {
/*  91:137 */     this.mContext = context;
/*  92:138 */     this.mAuthInfo = authInfo;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public AuthInfo getAuthInfo()
/*  96:    */   {
/*  97:147 */     return this.mAuthInfo;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public void setAuthInfo(AuthInfo authInfo)
/* 101:    */   {
/* 102:156 */     this.mAuthInfo = authInfo;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void anthorize(WeiboAuthListener listener)
/* 106:    */   {
/* 107:165 */     authorize(listener, 1);
/* 108:    */   }
/* 109:    */   
/* 110:    */   public void authorize(WeiboAuthListener listener, int type)
/* 111:    */   {
/* 112:177 */     startDialog(listener, type);
/* 113:    */   }
/* 114:    */   
/* 115:    */   private void startDialog(WeiboAuthListener listener, int type)
/* 116:    */   {
/* 117:188 */     if (listener == null) {
/* 118:189 */       return;
/* 119:    */     }
/* 120:192 */     WeiboParameters requestParams = new WeiboParameters();
/* 121:193 */     requestParams.put("client_id", this.mAuthInfo.mAppKey);
/* 122:194 */     requestParams.put("redirect_uri", this.mAuthInfo.mRedirectUrl);
/* 123:195 */     requestParams.put("scope", this.mAuthInfo.mScope);
/* 124:196 */     requestParams.put("response_type", "code");
/* 125:197 */     requestParams.put("display", "mobile");
/* 126:200 */     if (1 == type)
/* 127:    */     {
/* 128:201 */       requestParams.put("packagename", this.mAuthInfo.mPackageName);
/* 129:202 */       requestParams.put("key_hash", this.mAuthInfo.mKeyHash);
/* 130:    */     }
/* 131:205 */     String url = "https://open.weibo.cn/oauth2/authorize?" + requestParams.encodeUrl();
/* 132:206 */     if (!NetworkHelper.hasInternetPermission(this.mContext))
/* 133:    */     {
/* 134:207 */       UIUtils.showAlert(this.mContext, "Error", "Application requires permission to access the Internet");
/* 135:    */     }
/* 136:209 */     else if (NetworkHelper.isNetworkAvailable(this.mContext))
/* 137:    */     {
/* 138:210 */       new WeiboDialog(this.mContext, url, listener, this).show();
/* 139:    */     }
/* 140:    */     else
/* 141:    */     {
/* 142:212 */       String networkNotAvailable = ResourceManager.getString(this.mContext, 2);
/* 143:213 */       LogUtil.i("Weibo_web_login", "String: " + networkNotAvailable);
/* 144:214 */       UIUtils.showToast(this.mContext, networkNotAvailable, 0);
/* 145:    */     }
/* 146:    */   }
/* 147:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.auth.WeiboAuth
 * JD-Core Version:    0.7.0.1
 */