/*   1:    */ package com.sina.weibo.sdk.auth;
/*   2:    */ 
/*   3:    */ import android.os.Bundle;
/*   4:    */ import android.text.TextUtils;
/*   5:    */ import org.json.JSONException;
/*   6:    */ import org.json.JSONObject;
/*   7:    */ 
/*   8:    */ public class Oauth2AccessToken
/*   9:    */ {
/*  10:    */   private static final String KEY_UID = "uid";
/*  11:    */   private static final String KEY_ACCESS_TOKEN = "access_token";
/*  12:    */   private static final String KEY_EXPIRES_IN = "expires_in";
/*  13:    */   private static final String KEY_REFRESH_TOKEN = "refresh_token";
/*  14: 40 */   private String mUid = "";
/*  15: 42 */   private String mAccessToken = "";
/*  16: 44 */   private String mRefreshToken = "";
/*  17: 46 */   private long mExpiresTime = 0L;
/*  18:    */   
/*  19:    */   public Oauth2AccessToken() {}
/*  20:    */   
/*  21:    */   @Deprecated
/*  22:    */   public Oauth2AccessToken(String responseText)
/*  23:    */   {
/*  24: 62 */     if ((responseText != null) && 
/*  25: 63 */       (responseText.indexOf("{") >= 0)) {
/*  26:    */       try
/*  27:    */       {
/*  28: 65 */         JSONObject json = new JSONObject(responseText);
/*  29: 66 */         setUid(json.optString("uid"));
/*  30: 67 */         setToken(json.optString("access_token"));
/*  31: 68 */         setExpiresIn(json.optString("expires_in"));
/*  32: 69 */         setRefreshToken(json.optString("refresh_token"));
/*  33:    */       }
/*  34:    */       catch (JSONException e)
/*  35:    */       {
/*  36: 71 */         e.printStackTrace();
/*  37:    */       }
/*  38:    */     }
/*  39:    */   }
/*  40:    */   
/*  41:    */   public Oauth2AccessToken(String accessToken, String expiresIn)
/*  42:    */   {
/*  43: 84 */     this.mAccessToken = accessToken;
/*  44: 85 */     this.mExpiresTime = System.currentTimeMillis();
/*  45: 86 */     if (expiresIn != null) {
/*  46: 87 */       this.mExpiresTime += Long.parseLong(expiresIn) * 1000L;
/*  47:    */     }
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static Oauth2AccessToken parseAccessToken(String responseJsonText)
/*  51:    */   {
/*  52: 99 */     if ((!TextUtils.isEmpty(responseJsonText)) && 
/*  53:100 */       (responseJsonText.indexOf("{") >= 0)) {
/*  54:    */       try
/*  55:    */       {
/*  56:102 */         JSONObject json = new JSONObject(responseJsonText);
/*  57:103 */         Oauth2AccessToken token = new Oauth2AccessToken();
/*  58:104 */         token.setUid(json.optString("uid"));
/*  59:105 */         token.setToken(json.optString("access_token"));
/*  60:106 */         token.setExpiresIn(json.optString("expires_in"));
/*  61:107 */         token.setRefreshToken(json.optString("refresh_token"));
/*  62:    */         
/*  63:109 */         return token;
/*  64:    */       }
/*  65:    */       catch (JSONException e)
/*  66:    */       {
/*  67:111 */         e.printStackTrace();
/*  68:    */       }
/*  69:    */     }
/*  70:116 */     return null;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public static Oauth2AccessToken parseAccessToken(Bundle bundle)
/*  74:    */   {
/*  75:127 */     if (bundle != null)
/*  76:    */     {
/*  77:128 */       Oauth2AccessToken accessToken = new Oauth2AccessToken();
/*  78:129 */       accessToken.setUid(getString(bundle, "uid", ""));
/*  79:130 */       accessToken.setToken(getString(bundle, "access_token", ""));
/*  80:131 */       accessToken.setExpiresIn(getString(bundle, "expires_in", ""));
/*  81:132 */       accessToken.setRefreshToken(getString(bundle, "refresh_token", ""));
/*  82:    */       
/*  83:134 */       return accessToken;
/*  84:    */     }
/*  85:137 */     return null;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public boolean isSessionValid()
/*  89:    */   {
/*  90:146 */     return (!TextUtils.isEmpty(this.mAccessToken)) && 
/*  91:147 */       (this.mExpiresTime != 0L) && (
/*  92:148 */       System.currentTimeMillis() < this.mExpiresTime);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public Bundle toBundle()
/*  96:    */   {
/*  97:156 */     Bundle bundle = new Bundle();
/*  98:157 */     bundle.putString("uid", this.mUid);
/*  99:158 */     bundle.putString("access_token", this.mAccessToken);
/* 100:159 */     bundle.putString("refresh_token", this.mRefreshToken);
/* 101:160 */     bundle.putString("expires_in", Long.toString(this.mExpiresTime));
/* 102:161 */     return bundle;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public String toString()
/* 106:    */   {
/* 107:169 */     return 
/* 108:    */     
/* 109:    */ 
/* 110:172 */       "uid: " + this.mUid + ", " + "access_token" + ": " + this.mAccessToken + ", " + "refresh_token" + ": " + this.mRefreshToken + ", " + "expires_in" + ": " + Long.toString(this.mExpiresTime);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public String getUid()
/* 114:    */   {
/* 115:181 */     return this.mUid;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public void setUid(String uid)
/* 119:    */   {
/* 120:190 */     this.mUid = uid;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public String getToken()
/* 124:    */   {
/* 125:197 */     return this.mAccessToken;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public void setToken(String mToken)
/* 129:    */   {
/* 130:206 */     this.mAccessToken = mToken;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public String getRefreshToken()
/* 134:    */   {
/* 135:213 */     return this.mRefreshToken;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void setRefreshToken(String refreshToken)
/* 139:    */   {
/* 140:222 */     this.mRefreshToken = refreshToken;
/* 141:    */   }
/* 142:    */   
/* 143:    */   public long getExpiresTime()
/* 144:    */   {
/* 145:230 */     return this.mExpiresTime;
/* 146:    */   }
/* 147:    */   
/* 148:    */   public void setExpiresTime(long mExpiresTime)
/* 149:    */   {
/* 150:240 */     this.mExpiresTime = mExpiresTime;
/* 151:    */   }
/* 152:    */   
/* 153:    */   public void setExpiresIn(String expiresIn)
/* 154:    */   {
/* 155:249 */     if ((!TextUtils.isEmpty(expiresIn)) && (!expiresIn.equals("0"))) {
/* 156:250 */       setExpiresTime(System.currentTimeMillis() + Long.parseLong(expiresIn) * 1000L);
/* 157:    */     }
/* 158:    */   }
/* 159:    */   
/* 160:    */   private static String getString(Bundle bundle, String key, String defaultValue)
/* 161:    */   {
/* 162:268 */     if (bundle != null)
/* 163:    */     {
/* 164:269 */       String value = bundle.getString(key);
/* 165:270 */       return value != null ? value : defaultValue;
/* 166:    */     }
/* 167:273 */     return defaultValue;
/* 168:    */   }
/* 169:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.auth.Oauth2AccessToken
 * JD-Core Version:    0.7.0.1
 */