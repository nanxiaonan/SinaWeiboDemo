package com.sina.weibo.sdk.auth;

import android.os.Bundle;
import com.sina.weibo.sdk.exception.WeiboException;

public abstract interface WeiboAuthListener
{
  public abstract void onComplete(Bundle paramBundle);
  
  public abstract void onWeiboException(WeiboException paramWeiboException);
  
  public abstract void onCancel();
}


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.auth.WeiboAuthListener
 * JD-Core Version:    0.7.0.1
 */