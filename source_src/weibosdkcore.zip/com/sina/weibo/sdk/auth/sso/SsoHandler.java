/*   1:    */ package com.sina.weibo.sdk.auth.sso;
/*   2:    */ 
/*   3:    */ import android.app.Activity;
/*   4:    */ import android.app.ActivityManager;
/*   5:    */ import android.app.ActivityManager.RunningServiceInfo;
/*   6:    */ import android.content.ActivityNotFoundException;
/*   7:    */ import android.content.ComponentName;
/*   8:    */ import android.content.Context;
/*   9:    */ import android.content.Intent;
/*  10:    */ import android.content.ServiceConnection;
/*  11:    */ import android.os.Bundle;
/*  12:    */ import android.os.IBinder;
/*  13:    */ import android.os.RemoteException;
/*  14:    */ import android.text.TextUtils;
/*  15:    */ import com.sina.sso.RemoteSSO;
/*  16:    */ import com.sina.sso.RemoteSSO.Stub;
/*  17:    */ import com.sina.weibo.sdk.auth.Oauth2AccessToken;
/*  18:    */ import com.sina.weibo.sdk.auth.WeiboAuth;
/*  19:    */ import com.sina.weibo.sdk.auth.WeiboAuth.AuthInfo;
/*  20:    */ import com.sina.weibo.sdk.auth.WeiboAuthListener;
/*  21:    */ import com.sina.weibo.sdk.exception.WeiboDialogException;
/*  22:    */ import com.sina.weibo.sdk.utils.LogUtil;
/*  23:    */ import com.sina.weibo.sdk.utils.SecurityHelper;
/*  24:    */ import java.util.List;
/*  25:    */ 
/*  26:    */ public class SsoHandler
/*  27:    */ {
/*  28:    */   private static final String TAG = "Weibo_SSO_login";
/*  29:    */   private static final String DEFAULT_SINA_WEIBO_PACKAGE_NAME = "com.sina.weibo";
/*  30:    */   private static final String DEFAULT_WEIBO_REMOTE_SSO_SERVICE_NAME = "com.sina.weibo.remotessoservice";
/*  31:    */   private static final int REQUEST_CODE_SSO_AUTH = 32973;
/*  32:    */   private WeiboAuth mWeiboAuth;
/*  33:    */   private WeiboAuthListener mAuthListener;
/*  34:    */   private Activity mAuthActivity;
/*  35:    */   private int mSSOAuthRequestCode;
/*  36: 72 */   private ServiceConnection mConnection = new ServiceConnection()
/*  37:    */   {
/*  38:    */     public void onServiceDisconnected(ComponentName name)
/*  39:    */     {
/*  40: 75 */       SsoHandler.this.mWeiboAuth.anthorize(SsoHandler.this.mAuthListener);
/*  41:    */     }
/*  42:    */     
/*  43:    */     public void onServiceConnected(ComponentName name, IBinder service)
/*  44:    */     {
/*  45: 80 */       RemoteSSO remoteSSOservice = RemoteSSO.Stub.asInterface(service);
/*  46:    */       try
/*  47:    */       {
/*  48: 82 */         String ssoPackageName = remoteSSOservice.getPackageName();
/*  49: 83 */         String ssoActivityName = remoteSSOservice.getActivityName();
/*  50:    */         
/*  51:    */ 
/*  52: 86 */         SsoHandler.this.mAuthActivity.getApplicationContext().unbindService(SsoHandler.this.mConnection);
/*  53: 88 */         if (!SsoHandler.this.startSingleSignOn(ssoPackageName, ssoActivityName)) {
/*  54: 89 */           SsoHandler.this.mWeiboAuth.anthorize(SsoHandler.this.mAuthListener);
/*  55:    */         }
/*  56:    */       }
/*  57:    */       catch (RemoteException e)
/*  58:    */       {
/*  59: 92 */         e.printStackTrace();
/*  60:    */       }
/*  61:    */     }
/*  62:    */   };
/*  63:    */   
/*  64:    */   public SsoHandler(Activity activity, WeiboAuth weiboAuth)
/*  65:    */   {
/*  66:104 */     this.mAuthActivity = activity;
/*  67:105 */     this.mWeiboAuth = weiboAuth;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public void authorize(WeiboAuthListener listener)
/*  71:    */   {
/*  72:115 */     authorize(32973, listener, null);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void authorize(WeiboAuthListener listener, String packageName)
/*  76:    */   {
/*  77:128 */     authorize(32973, listener, packageName);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public void authorize(int requestCode, WeiboAuthListener listener, String packageName)
/*  81:    */   {
/*  82:139 */     this.mSSOAuthRequestCode = requestCode;
/*  83:140 */     this.mAuthListener = listener;
/*  84:    */     
/*  85:    */ 
/*  86:143 */     boolean bindSucced = bindRemoteSSOService(this.mAuthActivity.getApplicationContext(), packageName);
/*  87:146 */     if ((!bindSucced) && 
/*  88:147 */       (this.mWeiboAuth != null)) {
/*  89:148 */       this.mWeiboAuth.anthorize(this.mAuthListener);
/*  90:    */     }
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void authorizeCallBack(int requestCode, int resultCode, Intent data)
/*  94:    */   {
/*  95:173 */     LogUtil.d("Weibo_SSO_login", "requestCode: " + requestCode + ", resultCode: " + resultCode + ", data: " + data);
/*  96:174 */     if (requestCode == this.mSSOAuthRequestCode) {
/*  97:177 */       if (resultCode == -1)
/*  98:    */       {
/*  99:178 */         if (!SecurityHelper.checkResponseAppLegal(this.mAuthActivity, data)) {
/* 100:179 */           return;
/* 101:    */         }
/* 102:183 */         String error = data.getStringExtra("error");
/* 103:184 */         if (error == null) {
/* 104:185 */           error = data.getStringExtra("error_type");
/* 105:    */         }
/* 106:189 */         if (error != null)
/* 107:    */         {
/* 108:190 */           if ((error.equals("access_denied")) || (error.equals("OAuthAccessDeniedException")))
/* 109:    */           {
/* 110:191 */             LogUtil.d("Weibo_SSO_login", "Login canceled by user.");
/* 111:    */             
/* 112:193 */             this.mAuthListener.onCancel();
/* 113:    */           }
/* 114:    */           else
/* 115:    */           {
/* 116:195 */             String description = data.getStringExtra("error_description");
/* 117:196 */             if (description != null) {
/* 118:197 */               error = error + ":" + description;
/* 119:    */             }
/* 120:200 */             LogUtil.d("Weibo_SSO_login", "Login failed: " + error);
/* 121:201 */             this.mAuthListener.onWeiboException(
/* 122:202 */               new WeiboDialogException(error, resultCode, description));
/* 123:    */           }
/* 124:    */         }
/* 125:    */         else
/* 126:    */         {
/* 127:206 */           Bundle bundle = data.getExtras();
/* 128:207 */           Oauth2AccessToken accessToken = Oauth2AccessToken.parseAccessToken(bundle);
/* 129:209 */           if ((accessToken != null) && (accessToken.isSessionValid()))
/* 130:    */           {
/* 131:210 */             LogUtil.d("Weibo_SSO_login", "Login Success! " + accessToken.toString());
/* 132:211 */             this.mAuthListener.onComplete(bundle);
/* 133:    */           }
/* 134:    */           else
/* 135:    */           {
/* 136:213 */             LogUtil.d("Weibo_SSO_login", "Failed to receive access token by SSO");
/* 137:    */             
/* 138:215 */             this.mWeiboAuth.anthorize(this.mAuthListener);
/* 139:    */           }
/* 140:    */         }
/* 141:    */       }
/* 142:220 */       else if (resultCode == 0)
/* 143:    */       {
/* 144:223 */         if (data != null)
/* 145:    */         {
/* 146:224 */           LogUtil.d("Weibo_SSO_login", "Login failed: " + data.getStringExtra("error"));
/* 147:225 */           this.mAuthListener.onWeiboException(
/* 148:226 */             new WeiboDialogException(
/* 149:227 */             data.getStringExtra("error"), 
/* 150:228 */             data.getIntExtra("error_code", -1), 
/* 151:229 */             data.getStringExtra("failing_url")));
/* 152:    */         }
/* 153:    */         else
/* 154:    */         {
/* 155:232 */           LogUtil.d("Weibo_SSO_login", "Login canceled by user.");
/* 156:233 */           this.mAuthListener.onCancel();
/* 157:    */         }
/* 158:    */       }
/* 159:    */     }
/* 160:    */   }
/* 161:    */   
/* 162:    */   public static ComponentName isServiceExisted(Context context, String packageName)
/* 163:    */   {
/* 164:248 */     ActivityManager activityManager = 
/* 165:249 */       (ActivityManager)context.getSystemService("activity");
/* 166:250 */     List<ActivityManager.RunningServiceInfo> serviceList = 
/* 167:251 */       activityManager.getRunningServices(2147483647);
/* 168:253 */     for (ActivityManager.RunningServiceInfo runningServiceInfo : serviceList)
/* 169:    */     {
/* 170:254 */       ComponentName serviceName = runningServiceInfo.service;
/* 171:256 */       if ((serviceName.getPackageName().equals(packageName)) && 
/* 172:257 */         (serviceName.getClassName().equals(packageName + ".business.RemoteSSOService"))) {
/* 173:258 */         return serviceName;
/* 174:    */       }
/* 175:    */     }
/* 176:263 */     return null;
/* 177:    */   }
/* 178:    */   
/* 179:    */   private boolean bindRemoteSSOService(Context context, String packageName)
/* 180:    */   {
/* 181:276 */     String tempPkgName = (TextUtils.isEmpty(packageName)) || (packageName.trim().equals("")) ? 
/* 182:277 */       "com.sina.weibo" : packageName;
/* 183:278 */     Intent intent = new Intent("com.sina.weibo.remotessoservice");
/* 184:279 */     intent.setPackage(tempPkgName);
/* 185:281 */     if (!context.bindService(intent, this.mConnection, 1))
/* 186:    */     {
/* 187:282 */       intent = new Intent("com.sina.weibo.remotessoservice");
/* 188:283 */       return context.bindService(intent, this.mConnection, 1);
/* 189:    */     }
/* 190:286 */     return true;
/* 191:    */   }
/* 192:    */   
/* 193:    */   private boolean startSingleSignOn(String ssoPackageName, String ssoActivityName)
/* 194:    */   {
/* 195:299 */     boolean bSucceed = true;
/* 196:300 */     Intent intent = new Intent();
/* 197:    */     
/* 198:302 */     intent.setClassName(ssoPackageName, ssoActivityName);
/* 199:    */     
/* 200:    */ 
/* 201:305 */     intent.putExtras(this.mWeiboAuth.getAuthInfo().getAuthBundle());
/* 202:    */     
/* 203:    */ 
/* 204:308 */     intent.putExtra("_weibo_command_type", 3);
/* 205:309 */     intent.putExtra("_weibo_transaction", String.valueOf(System.currentTimeMillis()));
/* 206:312 */     if (!SecurityHelper.validateAppSignatureForIntent(this.mAuthActivity, intent)) {
/* 207:313 */       return false;
/* 208:    */     }
/* 209:    */     try
/* 210:    */     {
/* 211:318 */       this.mAuthActivity.startActivityForResult(intent, this.mSSOAuthRequestCode);
/* 212:    */     }
/* 213:    */     catch (ActivityNotFoundException e)
/* 214:    */     {
/* 215:320 */       bSucceed = false;
/* 216:    */     }
/* 217:325 */     return bSucceed;
/* 218:    */   }
/* 219:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.auth.sso.SsoHandler
 * JD-Core Version:    0.7.0.1
 */