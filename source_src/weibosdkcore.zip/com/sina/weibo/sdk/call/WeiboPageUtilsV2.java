/*   1:    */ package com.sina.weibo.sdk.call;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.text.TextUtils;
/*   5:    */ import java.util.HashMap;
/*   6:    */ 
/*   7:    */ public final class WeiboPageUtilsV2
/*   8:    */ {
/*   9:    */   public static void postNewWeibo(Context context, HashMap<String, String> params)
/*  10:    */     throws WeiboNotInstalledException
/*  11:    */   {
/*  12: 67 */     if (context == null) {
/*  13: 68 */       throw new WeiboIllegalParameterException("context不能为空");
/*  14:    */     }
/*  15: 71 */     StringBuilder uri = null;
/*  16:    */     
/*  17: 73 */     uri = new StringBuilder("sinaweibo://sendweibo");
/*  18: 74 */     if (params != null) {
/*  19: 75 */       uri.append(CommonUtils.buildUriQuery(params));
/*  20:    */     }
/*  21: 78 */     StringBuilder packageuri = null;
/*  22: 79 */     if ((params != null) && (!TextUtils.isEmpty((CharSequence)params.get("packagename"))))
/*  23:    */     {
/*  24: 80 */       packageuri = new StringBuilder("sinaweibo://sendweibo");
/*  25: 83 */       if (params != null) {
/*  26: 84 */         packageuri.append(CommonUtils.buildUriQuery(params));
/*  27:    */       }
/*  28: 87 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), 
/*  29: 88 */         (String)params.get("packagename"));
/*  30:    */     }
/*  31:    */     else
/*  32:    */     {
/*  33: 90 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), null);
/*  34:    */     }
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static void viewNearbyPeople(Context context, HashMap<String, String> params)
/*  38:    */     throws WeiboNotInstalledException
/*  39:    */   {
/*  40:116 */     if (context == null) {
/*  41:117 */       throw new WeiboIllegalParameterException("context不能为空");
/*  42:    */     }
/*  43:120 */     StringBuilder uri = new StringBuilder("sinaweibo://nearbypeople");
/*  44:121 */     if (params != null) {
/*  45:122 */       uri.append(CommonUtils.buildUriQuery(params));
/*  46:    */     }
/*  47:124 */     StringBuilder packageuri = null;
/*  48:125 */     if ((params != null) && (!TextUtils.isEmpty((CharSequence)params.get("packagename"))))
/*  49:    */     {
/*  50:126 */       packageuri = new StringBuilder("sinaweibo://nearbypeople");
/*  51:129 */       if (params != null) {
/*  52:130 */         packageuri.append(CommonUtils.buildUriQuery(params));
/*  53:    */       }
/*  54:133 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), 
/*  55:134 */         (String)params.get("packagename"));
/*  56:    */     }
/*  57:    */     else
/*  58:    */     {
/*  59:136 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), null);
/*  60:    */     }
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static void viewNearbyWeibo(Context context, HashMap<String, String> params)
/*  64:    */     throws WeiboNotInstalledException
/*  65:    */   {
/*  66:162 */     if (context == null) {
/*  67:163 */       throw new WeiboIllegalParameterException("context不能为空");
/*  68:    */     }
/*  69:166 */     StringBuilder uri = new StringBuilder("sinaweibo://nearbyweibo");
/*  70:168 */     if (params != null) {
/*  71:169 */       uri.append(CommonUtils.buildUriQuery(params));
/*  72:    */     }
/*  73:172 */     StringBuilder packageuri = null;
/*  74:173 */     if ((params != null) && (!TextUtils.isEmpty((CharSequence)params.get("packagename"))))
/*  75:    */     {
/*  76:174 */       packageuri = new StringBuilder("sinaweibo://nearbyweibo");
/*  77:177 */       if (params != null) {
/*  78:178 */         packageuri.append(CommonUtils.buildUriQuery(params));
/*  79:    */       }
/*  80:181 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), 
/*  81:182 */         (String)params.get("packagename"));
/*  82:    */     }
/*  83:    */     else
/*  84:    */     {
/*  85:184 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), null);
/*  86:    */     }
/*  87:    */   }
/*  88:    */   
/*  89:    */   public static void viewUserInfo(Context context, HashMap<String, String> params)
/*  90:    */     throws WeiboNotInstalledException
/*  91:    */   {
/*  92:209 */     if (context == null) {
/*  93:210 */       throw new WeiboIllegalParameterException("context不能为空");
/*  94:    */     }
/*  95:213 */     if ((params == null) || ((TextUtils.isEmpty((CharSequence)params.get("uid"))) && 
/*  96:214 */       (TextUtils.isEmpty((CharSequence)params.get("nick"))))) {
/*  97:215 */       throw new WeiboIllegalParameterException("uid和nick必须至少有一个不为空");
/*  98:    */     }
/*  99:218 */     StringBuilder uri = new StringBuilder("sinaweibo://userinfo");
/* 100:220 */     if (params != null) {
/* 101:221 */       uri.append(CommonUtils.buildUriQuery(params));
/* 102:    */     }
/* 103:223 */     StringBuilder packageuri = null;
/* 104:224 */     if ((params != null) && (!TextUtils.isEmpty((CharSequence)params.get("packagename"))))
/* 105:    */     {
/* 106:225 */       packageuri = new StringBuilder("sinaweibo://userinfo");
/* 107:228 */       if (params != null) {
/* 108:229 */         packageuri.append(CommonUtils.buildUriQuery(params));
/* 109:    */       }
/* 110:232 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), 
/* 111:233 */         (String)params.get("packagename"));
/* 112:    */     }
/* 113:    */     else
/* 114:    */     {
/* 115:235 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), null);
/* 116:    */     }
/* 117:    */   }
/* 118:    */   
/* 119:    */   public static void viewUsertrends(Context context, HashMap<String, String> params)
/* 120:    */     throws WeiboNotInstalledException
/* 121:    */   {
/* 122:256 */     if (context == null) {
/* 123:257 */       throw new WeiboIllegalParameterException("context不能为空");
/* 124:    */     }
/* 125:259 */     if ((params == null) || (TextUtils.isEmpty((CharSequence)params.get("uid")))) {
/* 126:260 */       throw new WeiboIllegalParameterException("uid和nick必须至少有一个不为空");
/* 127:    */     }
/* 128:263 */     StringBuilder uri = new StringBuilder("sinaweibo://usertrends");
/* 129:264 */     if (params != null) {
/* 130:265 */       uri.append(CommonUtils.buildUriQuery(params));
/* 131:    */     }
/* 132:268 */     StringBuilder packageuri = null;
/* 133:269 */     if ((params != null) && (!TextUtils.isEmpty((CharSequence)params.get("packagename"))))
/* 134:    */     {
/* 135:270 */       packageuri = new StringBuilder("sinaweibo://usertrends");
/* 136:271 */       if (params != null) {
/* 137:272 */         packageuri.append(CommonUtils.buildUriQuery(params));
/* 138:    */       }
/* 139:275 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), 
/* 140:276 */         (String)params.get("packagename"));
/* 141:    */     }
/* 142:    */     else
/* 143:    */     {
/* 144:278 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), null);
/* 145:    */     }
/* 146:    */   }
/* 147:    */   
/* 148:    */   public static void viewPageInfo(Context context, HashMap<String, String> params)
/* 149:    */     throws WeiboNotInstalledException
/* 150:    */   {
/* 151:301 */     if (context == null) {
/* 152:302 */       throw new WeiboIllegalParameterException("context不能为空");
/* 153:    */     }
/* 154:304 */     if ((params == null) || (TextUtils.isEmpty((CharSequence)params.get("pageid")))) {
/* 155:305 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 156:    */     }
/* 157:308 */     StringBuilder uri = new StringBuilder("sinaweibo://pageinfo");
/* 158:310 */     if (params != null) {
/* 159:311 */       uri.append(CommonUtils.buildUriQuery(params));
/* 160:    */     }
/* 161:314 */     StringBuilder packageuri = null;
/* 162:315 */     if ((params != null) && (!TextUtils.isEmpty((CharSequence)params.get("packagename"))))
/* 163:    */     {
/* 164:316 */       packageuri = new StringBuilder("sinaweibo://pageinfo");
/* 165:317 */       if (params != null) {
/* 166:318 */         packageuri.append(CommonUtils.buildUriQuery(params));
/* 167:    */       }
/* 168:321 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), 
/* 169:322 */         (String)params.get("packagename"));
/* 170:    */     }
/* 171:    */     else
/* 172:    */     {
/* 173:324 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), null);
/* 174:    */     }
/* 175:    */   }
/* 176:    */   
/* 177:    */   public static void viewPageProductList(Context context, HashMap<String, String> params)
/* 178:    */     throws WeiboNotInstalledException
/* 179:    */   {
/* 180:351 */     if (context == null) {
/* 181:352 */       throw new WeiboIllegalParameterException("context不能为空");
/* 182:    */     }
/* 183:355 */     if (params == null) {
/* 184:356 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 185:    */     }
/* 186:359 */     if (TextUtils.isEmpty((CharSequence)params.get("pageid"))) {
/* 187:360 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 188:    */     }
/* 189:362 */     if (TextUtils.isEmpty((CharSequence)params.get("cardid"))) {
/* 190:363 */       throw new WeiboIllegalParameterException("cardId不能为空");
/* 191:    */     }
/* 192:365 */     int count = -1;
/* 193:    */     try
/* 194:    */     {
/* 195:367 */       count = Integer.parseInt((String)params.get("count"));
/* 196:    */     }
/* 197:    */     catch (NumberFormatException e)
/* 198:    */     {
/* 199:369 */       count = -1;
/* 200:    */     }
/* 201:371 */     if (count < 0) {
/* 202:372 */       throw new WeiboIllegalParameterException("count不能为负数");
/* 203:    */     }
/* 204:375 */     StringBuilder uri = new StringBuilder("sinaweibo://pageproductlist");
/* 205:377 */     if (params != null) {
/* 206:378 */       uri.append(CommonUtils.buildUriQuery(params));
/* 207:    */     }
/* 208:381 */     StringBuilder packageuri = null;
/* 209:382 */     if ((params != null) && (!TextUtils.isEmpty((CharSequence)params.get("packagename"))))
/* 210:    */     {
/* 211:383 */       packageuri = new StringBuilder("sinaweibo://pageproductlist");
/* 212:384 */       if (params != null) {
/* 213:385 */         packageuri.append(CommonUtils.buildUriQuery(params));
/* 214:    */       }
/* 215:388 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), 
/* 216:389 */         (String)params.get("packagename"));
/* 217:    */     }
/* 218:    */     else
/* 219:    */     {
/* 220:391 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), null);
/* 221:    */     }
/* 222:    */   }
/* 223:    */   
/* 224:    */   public static void viewPageUserList(Context context, HashMap<String, String> params)
/* 225:    */     throws WeiboNotInstalledException
/* 226:    */   {
/* 227:418 */     if (context == null) {
/* 228:419 */       throw new WeiboIllegalParameterException("context不能为空");
/* 229:    */     }
/* 230:421 */     if (params == null) {
/* 231:422 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 232:    */     }
/* 233:425 */     if (TextUtils.isEmpty((CharSequence)params.get("pageid"))) {
/* 234:426 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 235:    */     }
/* 236:428 */     if (TextUtils.isEmpty((CharSequence)params.get("cardid"))) {
/* 237:429 */       throw new WeiboIllegalParameterException("cardId不能为空");
/* 238:    */     }
/* 239:431 */     int count = -1;
/* 240:    */     try
/* 241:    */     {
/* 242:433 */       count = Integer.parseInt((String)params.get("count"));
/* 243:    */     }
/* 244:    */     catch (NumberFormatException e)
/* 245:    */     {
/* 246:435 */       count = -1;
/* 247:    */     }
/* 248:437 */     if (count < 0) {
/* 249:438 */       throw new WeiboIllegalParameterException("count不能为负数");
/* 250:    */     }
/* 251:441 */     StringBuilder uri = new StringBuilder("sinaweibo://pageuserlist");
/* 252:443 */     if (params != null) {
/* 253:444 */       uri.append(CommonUtils.buildUriQuery(params));
/* 254:    */     }
/* 255:447 */     StringBuilder packageuri = null;
/* 256:448 */     if ((params != null) && (!TextUtils.isEmpty((CharSequence)params.get("packagename"))))
/* 257:    */     {
/* 258:449 */       packageuri = new StringBuilder("sinaweibo://pageuserlist");
/* 259:450 */       if (params != null) {
/* 260:451 */         packageuri.append(CommonUtils.buildUriQuery(params));
/* 261:    */       }
/* 262:454 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), 
/* 263:455 */         (String)params.get("packagename"));
/* 264:    */     }
/* 265:    */     else
/* 266:    */     {
/* 267:457 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), null);
/* 268:    */     }
/* 269:    */   }
/* 270:    */   
/* 271:    */   public static void viewPageWeiboList(Context context, HashMap<String, String> params)
/* 272:    */     throws WeiboNotInstalledException
/* 273:    */   {
/* 274:484 */     if (context == null) {
/* 275:485 */       throw new WeiboIllegalParameterException("context不能为空");
/* 276:    */     }
/* 277:487 */     if (params == null) {
/* 278:488 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 279:    */     }
/* 280:491 */     if (TextUtils.isEmpty((CharSequence)params.get("pageid"))) {
/* 281:492 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 282:    */     }
/* 283:494 */     if (TextUtils.isEmpty((CharSequence)params.get("cardid"))) {
/* 284:495 */       throw new WeiboIllegalParameterException("cardId不能为空");
/* 285:    */     }
/* 286:497 */     int count = -1;
/* 287:    */     try
/* 288:    */     {
/* 289:499 */       count = Integer.parseInt((String)params.get("count"));
/* 290:    */     }
/* 291:    */     catch (NumberFormatException e)
/* 292:    */     {
/* 293:501 */       count = -1;
/* 294:    */     }
/* 295:503 */     if (count < 0) {
/* 296:504 */       throw new WeiboIllegalParameterException("count不能为负数");
/* 297:    */     }
/* 298:507 */     StringBuilder uri = new StringBuilder("sinaweibo://pageweibolist");
/* 299:509 */     if (params != null) {
/* 300:510 */       uri.append(CommonUtils.buildUriQuery(params));
/* 301:    */     }
/* 302:513 */     StringBuilder packageuri = null;
/* 303:514 */     if ((params != null) && (!TextUtils.isEmpty((CharSequence)params.get("packagename"))))
/* 304:    */     {
/* 305:515 */       packageuri = new StringBuilder("sinaweibo://pageweibolist");
/* 306:516 */       if (params != null) {
/* 307:517 */         packageuri.append(CommonUtils.buildUriQuery(params));
/* 308:    */       }
/* 309:520 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), 
/* 310:521 */         (String)params.get("packagename"));
/* 311:    */     }
/* 312:    */     else
/* 313:    */     {
/* 314:523 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), null);
/* 315:    */     }
/* 316:    */   }
/* 317:    */   
/* 318:    */   public static void viewPagePhotoList(Context context, HashMap<String, String> params)
/* 319:    */     throws WeiboNotInstalledException
/* 320:    */   {
/* 321:550 */     if (context == null) {
/* 322:551 */       throw new WeiboIllegalParameterException("context不能为空");
/* 323:    */     }
/* 324:553 */     if (params == null) {
/* 325:554 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 326:    */     }
/* 327:557 */     if (TextUtils.isEmpty((CharSequence)params.get("pageid"))) {
/* 328:558 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 329:    */     }
/* 330:560 */     if (TextUtils.isEmpty((CharSequence)params.get("cardid"))) {
/* 331:561 */       throw new WeiboIllegalParameterException("cardId不能为空");
/* 332:    */     }
/* 333:563 */     int count = -1;
/* 334:    */     try
/* 335:    */     {
/* 336:565 */       count = Integer.parseInt((String)params.get("count"));
/* 337:    */     }
/* 338:    */     catch (NumberFormatException e)
/* 339:    */     {
/* 340:567 */       count = -1;
/* 341:    */     }
/* 342:569 */     if (count < 0) {
/* 343:570 */       throw new WeiboIllegalParameterException("count不能为负数");
/* 344:    */     }
/* 345:573 */     StringBuilder uri = new StringBuilder("sinaweibo://pagephotolist");
/* 346:574 */     if (params != null) {
/* 347:575 */       uri.append(CommonUtils.buildUriQuery(params));
/* 348:    */     }
/* 349:578 */     StringBuilder packageuri = null;
/* 350:579 */     if ((params != null) && (!TextUtils.isEmpty((CharSequence)params.get("packagename"))))
/* 351:    */     {
/* 352:580 */       packageuri = new StringBuilder("sinaweibo://pagephotolist");
/* 353:581 */       if (params != null) {
/* 354:582 */         packageuri.append(CommonUtils.buildUriQuery(params));
/* 355:    */       }
/* 356:585 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), 
/* 357:586 */         (String)params.get("packagename"));
/* 358:    */     }
/* 359:    */     else
/* 360:    */     {
/* 361:588 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), null);
/* 362:    */     }
/* 363:    */   }
/* 364:    */   
/* 365:    */   public static void viewPageDetailInfo(Context context, HashMap<String, String> params)
/* 366:    */     throws WeiboNotInstalledException
/* 367:    */   {
/* 368:613 */     if (context == null) {
/* 369:614 */       throw new WeiboIllegalParameterException("context不能为空");
/* 370:    */     }
/* 371:616 */     if (params == null) {
/* 372:617 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 373:    */     }
/* 374:620 */     if (TextUtils.isEmpty((CharSequence)params.get("pageid"))) {
/* 375:621 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 376:    */     }
/* 377:623 */     if (TextUtils.isEmpty((CharSequence)params.get("cardid"))) {
/* 378:624 */       throw new WeiboIllegalParameterException("cardId不能为空");
/* 379:    */     }
/* 380:627 */     StringBuilder uri = new StringBuilder("sinaweibo://pagedetailinfo");
/* 381:629 */     if (params != null) {
/* 382:630 */       uri.append(CommonUtils.buildUriQuery(params));
/* 383:    */     }
/* 384:633 */     StringBuilder packageuri = null;
/* 385:634 */     if ((params != null) && (!TextUtils.isEmpty((CharSequence)params.get("packagename"))))
/* 386:    */     {
/* 387:635 */       packageuri = new StringBuilder("sinaweibo://pagedetailinfo");
/* 388:636 */       if (params != null) {
/* 389:637 */         packageuri.append(CommonUtils.buildUriQuery(params));
/* 390:    */       }
/* 391:640 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), 
/* 392:641 */         (String)params.get("packagename"));
/* 393:    */     }
/* 394:    */     else
/* 395:    */     {
/* 396:643 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), null);
/* 397:    */     }
/* 398:    */   }
/* 399:    */   
/* 400:    */   public static void openInWeiboBrowser(Context context, String url, String sinainternalbrowser, String extParam, String packageName)
/* 401:    */     throws WeiboNotInstalledException
/* 402:    */   {
/* 403:667 */     if (context == null) {
/* 404:668 */       throw new WeiboIllegalParameterException("context不能为空");
/* 405:    */     }
/* 406:671 */     if (TextUtils.isEmpty(url)) {
/* 407:672 */       throw new WeiboIllegalParameterException("url不能为空");
/* 408:    */     }
/* 409:675 */     if ((!TextUtils.isEmpty(sinainternalbrowser)) && 
/* 410:676 */       (!"topnav".equals(sinainternalbrowser)) && (!"default".equals(sinainternalbrowser)) && 
/* 411:677 */       (!"fullscreen".equals(sinainternalbrowser))) {
/* 412:678 */       throw new WeiboIllegalParameterException(
/* 413:679 */         "sinainternalbrowser不合法");
/* 414:    */     }
/* 415:683 */     StringBuilder uri = new StringBuilder("sinaweibo://browser");
/* 416:    */     
/* 417:685 */     HashMap<String, String> paramMap = new HashMap();
/* 418:    */     
/* 419:687 */     paramMap.put("url", url);
/* 420:688 */     paramMap.put("sinainternalbrowser", sinainternalbrowser);
/* 421:689 */     paramMap.put("extparam", extParam);
/* 422:    */     
/* 423:691 */     uri.append(CommonUtils.buildUriQuery(paramMap));
/* 424:    */     
/* 425:693 */     StringBuilder packageuri = null;
/* 426:694 */     if (!TextUtils.isEmpty(packageName))
/* 427:    */     {
/* 428:695 */       packageuri = new StringBuilder("sinaweibo://browser");
/* 429:696 */       if (paramMap != null) {
/* 430:697 */         packageuri.append(CommonUtils.buildUriQuery(paramMap));
/* 431:    */       }
/* 432:700 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), packageName);
/* 433:    */     }
/* 434:    */     else
/* 435:    */     {
/* 436:702 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), null);
/* 437:    */     }
/* 438:    */   }
/* 439:    */   
/* 440:    */   public static void displayInWeiboMap(Context context, HashMap<String, String> params)
/* 441:    */     throws WeiboNotInstalledException
/* 442:    */   {
/* 443:723 */     if (context == null) {
/* 444:724 */       throw new WeiboIllegalParameterException("context不能为空");
/* 445:    */     }
/* 446:727 */     String mapUrl = "http://weibo.cn/dpool/ttt/maps.php?xy=%s,%s&amp;size=320x320&amp;offset=%s";
/* 447:728 */     String lon = "";
/* 448:729 */     String lat = "";
/* 449:730 */     String offset = "";
/* 450:732 */     if (params != null)
/* 451:    */     {
/* 452:733 */       lon = (String)params.get("longitude");
/* 453:734 */       lat = (String)params.get("latitude");
/* 454:735 */       offset = (String)params.get("offset");
/* 455:    */     }
/* 456:738 */     String packageName = null;
/* 457:739 */     if ((params != null) && (!TextUtils.isEmpty((CharSequence)params.get("packagename")))) {
/* 458:740 */       packageName = (String)params.get("packagename");
/* 459:    */     }
/* 460:742 */     if (params != null) {
/* 461:743 */       openInWeiboBrowser(context, String.format(mapUrl, new Object[] { lon, lat, offset }), "default", 
/* 462:744 */         (String)params.get("extparam"), packageName);
/* 463:    */     }
/* 464:    */   }
/* 465:    */   
/* 466:    */   public static void openQrcodeScanner(Context context, HashMap<String, String> params)
/* 467:    */     throws WeiboNotInstalledException
/* 468:    */   {
/* 469:764 */     if (context == null) {
/* 470:765 */       throw new WeiboIllegalParameterException("context不能为空");
/* 471:    */     }
/* 472:767 */     StringBuilder uri = new StringBuilder("sinaweibo://qrcode");
/* 473:769 */     if (params != null) {
/* 474:770 */       uri.append(CommonUtils.buildUriQuery(params));
/* 475:    */     }
/* 476:773 */     StringBuilder packageuri = null;
/* 477:774 */     if ((params != null) && (!TextUtils.isEmpty((CharSequence)params.get("packagename"))))
/* 478:    */     {
/* 479:775 */       packageuri = new StringBuilder("sinaweibo://qrcode");
/* 480:776 */       if (params != null) {
/* 481:777 */         packageuri.append(CommonUtils.buildUriQuery(params));
/* 482:    */       }
/* 483:780 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), 
/* 484:781 */         (String)params.get("packagename"));
/* 485:    */     }
/* 486:    */     else
/* 487:    */     {
/* 488:783 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), null);
/* 489:    */     }
/* 490:    */   }
/* 491:    */   
/* 492:    */   public static void weiboDetail(Context context, HashMap<String, String> params)
/* 493:    */     throws WeiboNotInstalledException
/* 494:    */   {
/* 495:804 */     if (context == null) {
/* 496:805 */       throw new WeiboIllegalParameterException("context不能为空");
/* 497:    */     }
/* 498:807 */     if (params == null) {
/* 499:808 */       throw new WeiboIllegalParameterException("mblogId(微博id)不能为空");
/* 500:    */     }
/* 501:811 */     if (TextUtils.isEmpty((CharSequence)params.get("mblogid"))) {
/* 502:812 */       throw new WeiboIllegalParameterException("mblogId(微博id)不能为空");
/* 503:    */     }
/* 504:815 */     StringBuilder uri = new StringBuilder("sinaweibo://detail");
/* 505:817 */     if (params != null) {
/* 506:818 */       uri.append(CommonUtils.buildUriQuery(params));
/* 507:    */     }
/* 508:820 */     StringBuilder packageuri = null;
/* 509:821 */     if ((params != null) && (!TextUtils.isEmpty((CharSequence)params.get("packagename"))))
/* 510:    */     {
/* 511:822 */       packageuri = new StringBuilder("sinaweibo://detail");
/* 512:823 */       if (params != null) {
/* 513:824 */         packageuri.append(CommonUtils.buildUriQuery(params));
/* 514:    */       }
/* 515:827 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), 
/* 516:828 */         (String)params.get("packagename"));
/* 517:    */     }
/* 518:    */     else
/* 519:    */     {
/* 520:830 */       CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString(), null);
/* 521:    */     }
/* 522:    */   }
/* 523:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.call.WeiboPageUtilsV2
 * JD-Core Version:    0.7.0.1
 */