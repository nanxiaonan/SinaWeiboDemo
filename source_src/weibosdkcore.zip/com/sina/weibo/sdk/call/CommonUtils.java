/*   1:    */ package com.sina.weibo.sdk.call;
/*   2:    */ 
/*   3:    */ import android.content.ActivityNotFoundException;
/*   4:    */ import android.content.Context;
/*   5:    */ import android.content.Intent;
/*   6:    */ import android.net.Uri;
/*   7:    */ import java.util.HashMap;
/*   8:    */ import java.util.Set;
/*   9:    */ 
/*  10:    */ class CommonUtils
/*  11:    */ {
/*  12:    */   public static String buildUriQuery(HashMap<String, String> paramsMap)
/*  13:    */   {
/*  14: 38 */     StringBuilder queryBuilder = new StringBuilder();
/*  15: 39 */     Set<String> keySet = paramsMap.keySet();
/*  16: 40 */     for (String key : keySet)
/*  17:    */     {
/*  18: 41 */       String value = (String)paramsMap.get(key);
/*  19: 42 */       if (value != null) {
/*  20: 43 */         queryBuilder.append("&").append(key).append("=").append(value);
/*  21:    */       }
/*  22:    */     }
/*  23: 46 */     String query = queryBuilder.toString();
/*  24: 47 */     return query.replaceFirst("&", "?");
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static void openWeiboActivity(Context context, String action, String uri, String packageName)
/*  28:    */     throws WeiboNotInstalledException
/*  29:    */   {
/*  30:    */     try
/*  31:    */     {
/*  32: 87 */       if (packageName != null)
/*  33:    */       {
/*  34: 88 */         Intent intent = new Intent();
/*  35: 89 */         intent.setAction(action);
/*  36: 90 */         intent.setData(Uri.parse(uri));
/*  37: 91 */         intent.setPackage(packageName);
/*  38: 92 */         context.startActivity(intent);
/*  39:    */       }
/*  40:    */       else
/*  41:    */       {
/*  42: 94 */         Intent intent = new Intent();
/*  43: 95 */         intent.setAction(action);
/*  44: 96 */         intent.setData(Uri.parse(uri));
/*  45: 97 */         context.startActivity(intent);
/*  46:    */       }
/*  47:    */     }
/*  48:    */     catch (ActivityNotFoundException exception)
/*  49:    */     {
/*  50:101 */       if (packageName != null) {
/*  51:    */         try
/*  52:    */         {
/*  53:103 */           Intent intent = new Intent();
/*  54:104 */           intent.setAction(action);
/*  55:105 */           intent.setData(Uri.parse(uri));
/*  56:106 */           context.startActivity(intent);
/*  57:    */         }
/*  58:    */         catch (ActivityNotFoundException e)
/*  59:    */         {
/*  60:108 */           throw new WeiboNotInstalledException(
/*  61:109 */             "无法找到微博官方客户端");
/*  62:    */         }
/*  63:    */       } else {
/*  64:112 */         throw new WeiboNotInstalledException(
/*  65:113 */           "无法找到微博官方客户端");
/*  66:    */       }
/*  67:    */     }
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static void openWeiboActivity(Context context, String action, String uri)
/*  71:    */     throws WeiboNotInstalledException
/*  72:    */   {
/*  73:    */     try
/*  74:    */     {
/*  75:123 */       Intent intent = new Intent();
/*  76:124 */       intent.setAction(action);
/*  77:125 */       intent.setData(Uri.parse(uri));
/*  78:126 */       context.startActivity(intent);
/*  79:    */     }
/*  80:    */     catch (ActivityNotFoundException exception)
/*  81:    */     {
/*  82:128 */       throw new WeiboNotInstalledException(
/*  83:129 */         "无法找到微博官方客户端");
/*  84:    */     }
/*  85:    */   }
/*  86:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.call.CommonUtils
 * JD-Core Version:    0.7.0.1
 */