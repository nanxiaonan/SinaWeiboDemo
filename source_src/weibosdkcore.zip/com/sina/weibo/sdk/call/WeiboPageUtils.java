/*   1:    */ package com.sina.weibo.sdk.call;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.text.TextUtils;
/*   5:    */ import java.io.UnsupportedEncodingException;
/*   6:    */ import java.net.URLEncoder;
/*   7:    */ import java.util.HashMap;
/*   8:    */ 
/*   9:    */ public final class WeiboPageUtils
/*  10:    */ {
/*  11:    */   public static void postNewWeibo(Context context, String content, String poiId, String poiName, Position position, String pageId, String extParam)
/*  12:    */     throws WeiboNotInstalledException
/*  13:    */   {
/*  14: 60 */     if (context == null) {
/*  15: 61 */       throw new WeiboIllegalParameterException("context不能为空");
/*  16:    */     }
/*  17: 64 */     StringBuilder uri = new StringBuilder("sinaweibo://sendweibo");
/*  18:    */     
/*  19: 66 */     HashMap<String, String> paramMap = new HashMap();
/*  20:    */     try
/*  21:    */     {
/*  22: 68 */       paramMap.put("content", URLEncoder.encode(content, "UTF-8").replaceAll("\\+", "%20"));
/*  23:    */     }
/*  24:    */     catch (UnsupportedEncodingException e)
/*  25:    */     {
/*  26: 70 */       e.printStackTrace();
/*  27:    */     }
/*  28: 72 */     paramMap.put("poiid", poiId);
/*  29: 73 */     paramMap.put("poiname", poiName);
/*  30: 74 */     if (position != null)
/*  31:    */     {
/*  32: 75 */       paramMap.put("longitude", position.getStrLongitude());
/*  33: 76 */       paramMap.put("latitude", position.getStrLatitude());
/*  34:    */     }
/*  35: 78 */     paramMap.put("pageid", pageId);
/*  36: 79 */     paramMap.put("extparam", extParam);
/*  37:    */     
/*  38: 81 */     uri.append(CommonUtils.buildUriQuery(paramMap));
/*  39:    */     
/*  40: 83 */     CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString());
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static void viewNearbyPeople(Context context, Position position, String extParam)
/*  44:    */     throws WeiboNotInstalledException
/*  45:    */   {
/*  46: 97 */     if (context == null) {
/*  47: 98 */       throw new WeiboIllegalParameterException("context不能为空");
/*  48:    */     }
/*  49:101 */     StringBuilder uri = new StringBuilder("sinaweibo://nearbypeople");
/*  50:    */     
/*  51:103 */     HashMap<String, String> paramMap = new HashMap();
/*  52:104 */     if (position != null)
/*  53:    */     {
/*  54:105 */       paramMap.put("longitude", position.getStrLongitude());
/*  55:106 */       paramMap.put("latitude", position.getStrLatitude());
/*  56:107 */       paramMap.put("offset", position.getStrOffset());
/*  57:    */     }
/*  58:109 */     paramMap.put("extparam", extParam);
/*  59:110 */     uri.append(CommonUtils.buildUriQuery(paramMap));
/*  60:    */     
/*  61:112 */     CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString());
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static void viewNearbyWeibo(Context context, Position position, String extParam)
/*  65:    */     throws WeiboNotInstalledException
/*  66:    */   {
/*  67:127 */     if (context == null) {
/*  68:128 */       throw new WeiboIllegalParameterException("context不能为空");
/*  69:    */     }
/*  70:131 */     StringBuilder uri = new StringBuilder("sinaweibo://nearbyweibo");
/*  71:    */     
/*  72:133 */     HashMap<String, String> paramMap = new HashMap();
/*  73:134 */     if (position != null)
/*  74:    */     {
/*  75:135 */       paramMap.put("longitude", position.getStrLongitude());
/*  76:136 */       paramMap.put("latitude", position.getStrLatitude());
/*  77:137 */       paramMap.put("offset", position.getStrOffset());
/*  78:    */     }
/*  79:139 */     paramMap.put("extparam", extParam);
/*  80:140 */     uri.append(CommonUtils.buildUriQuery(paramMap));
/*  81:    */     
/*  82:142 */     CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString());
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static void viewUserInfo(Context context, String uid, String nick, String extParam)
/*  86:    */     throws WeiboNotInstalledException
/*  87:    */   {
/*  88:158 */     if (context == null) {
/*  89:159 */       throw new WeiboIllegalParameterException("context不能为空");
/*  90:    */     }
/*  91:161 */     if ((TextUtils.isEmpty(uid)) && (TextUtils.isEmpty(nick))) {
/*  92:162 */       throw new WeiboIllegalParameterException("uid和nick必须至少有一个不为空");
/*  93:    */     }
/*  94:165 */     StringBuilder uri = new StringBuilder("sinaweibo://userinfo");
/*  95:    */     
/*  96:167 */     HashMap<String, String> paramMap = new HashMap();
/*  97:168 */     paramMap.put("uid", uid);
/*  98:169 */     paramMap.put("nick", nick);
/*  99:170 */     paramMap.put("extparam", extParam);
/* 100:    */     
/* 101:172 */     uri.append(CommonUtils.buildUriQuery(paramMap));
/* 102:    */     
/* 103:174 */     CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString());
/* 104:    */   }
/* 105:    */   
/* 106:    */   public static void viewUsertrends(Context context, String uid, String extParam)
/* 107:    */     throws WeiboNotInstalledException
/* 108:    */   {
/* 109:188 */     if (context == null) {
/* 110:189 */       throw new WeiboIllegalParameterException("context不能为空");
/* 111:    */     }
/* 112:191 */     if (TextUtils.isEmpty(uid)) {
/* 113:192 */       throw new WeiboIllegalParameterException("uid和nick必须至少有一个不为空");
/* 114:    */     }
/* 115:195 */     StringBuilder uri = new StringBuilder("sinaweibo://usertrends");
/* 116:    */     
/* 117:197 */     HashMap<String, String> paramMap = new HashMap();
/* 118:    */     
/* 119:199 */     paramMap.put("uid", uid);
/* 120:200 */     paramMap.put("extparam", extParam);
/* 121:    */     
/* 122:202 */     uri.append(CommonUtils.buildUriQuery(paramMap));
/* 123:    */     
/* 124:204 */     CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString());
/* 125:    */   }
/* 126:    */   
/* 127:    */   public static void viewPageInfo(Context context, String pageId, String title, String extParam)
/* 128:    */     throws WeiboNotInstalledException
/* 129:    */   {
/* 130:219 */     if (context == null) {
/* 131:220 */       throw new WeiboIllegalParameterException("context不能为空");
/* 132:    */     }
/* 133:222 */     if (TextUtils.isEmpty(pageId)) {
/* 134:223 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 135:    */     }
/* 136:226 */     StringBuilder uri = new StringBuilder("sinaweibo://pageinfo");
/* 137:    */     
/* 138:228 */     HashMap<String, String> paramMap = new HashMap();
/* 139:229 */     paramMap.put("pageid", pageId);
/* 140:230 */     paramMap.put("title", title);
/* 141:231 */     paramMap.put("extparam", extParam);
/* 142:    */     
/* 143:233 */     uri.append(CommonUtils.buildUriQuery(paramMap));
/* 144:    */     
/* 145:235 */     CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString());
/* 146:    */   }
/* 147:    */   
/* 148:    */   public static void viewPageProductList(Context context, String pageId, String cardId, String title, Integer count, String extParam)
/* 149:    */     throws WeiboNotInstalledException
/* 150:    */   {
/* 151:253 */     if (context == null) {
/* 152:254 */       throw new WeiboIllegalParameterException("context不能为空");
/* 153:    */     }
/* 154:256 */     if (TextUtils.isEmpty(pageId)) {
/* 155:257 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 156:    */     }
/* 157:259 */     if (TextUtils.isEmpty(cardId)) {
/* 158:260 */       throw new WeiboIllegalParameterException("cardId不能为空");
/* 159:    */     }
/* 160:262 */     if ((count != null) && (count.intValue() < 0)) {
/* 161:263 */       throw new WeiboIllegalParameterException("count不能为负数");
/* 162:    */     }
/* 163:266 */     StringBuilder uri = new StringBuilder("sinaweibo://pageproductlist");
/* 164:    */     
/* 165:268 */     HashMap<String, String> paramMap = new HashMap();
/* 166:269 */     paramMap.put("pageid", pageId);
/* 167:270 */     paramMap.put("cardid", cardId);
/* 168:271 */     paramMap.put("title", title);
/* 169:272 */     paramMap.put("page", "1");
/* 170:273 */     paramMap.put("count", String.valueOf(count));
/* 171:274 */     paramMap.put("extparam", extParam);
/* 172:    */     
/* 173:276 */     uri.append(CommonUtils.buildUriQuery(paramMap));
/* 174:    */     
/* 175:278 */     CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString());
/* 176:    */   }
/* 177:    */   
/* 178:    */   public static void viewPageUserList(Context context, String pageId, String cardId, String title, Integer count, String extParam)
/* 179:    */     throws WeiboNotInstalledException
/* 180:    */   {
/* 181:296 */     if (context == null) {
/* 182:297 */       throw new WeiboIllegalParameterException("context不能为空");
/* 183:    */     }
/* 184:299 */     if (TextUtils.isEmpty(pageId)) {
/* 185:300 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 186:    */     }
/* 187:302 */     if (TextUtils.isEmpty(cardId)) {
/* 188:303 */       throw new WeiboIllegalParameterException("cardId不能为空");
/* 189:    */     }
/* 190:305 */     if ((count != null) && (count.intValue() < 0)) {
/* 191:306 */       throw new WeiboIllegalParameterException("count不能为负数");
/* 192:    */     }
/* 193:309 */     StringBuilder uri = new StringBuilder("sinaweibo://pageuserlist");
/* 194:    */     
/* 195:311 */     HashMap<String, String> paramMap = new HashMap();
/* 196:312 */     paramMap.put("pageid", pageId);
/* 197:313 */     paramMap.put("cardid", cardId);
/* 198:314 */     paramMap.put("title", title);
/* 199:315 */     paramMap.put("page", "1");
/* 200:316 */     paramMap.put("count", String.valueOf(count));
/* 201:317 */     paramMap.put("extparam", extParam);
/* 202:    */     
/* 203:319 */     uri.append(CommonUtils.buildUriQuery(paramMap));
/* 204:    */     
/* 205:321 */     CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString());
/* 206:    */   }
/* 207:    */   
/* 208:    */   public static void viewPageWeiboList(Context context, String pageId, String cardId, String title, Integer count, String extParam)
/* 209:    */     throws WeiboNotInstalledException
/* 210:    */   {
/* 211:339 */     if (context == null) {
/* 212:340 */       throw new WeiboIllegalParameterException("context不能为空");
/* 213:    */     }
/* 214:342 */     if (TextUtils.isEmpty(pageId)) {
/* 215:343 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 216:    */     }
/* 217:345 */     if (TextUtils.isEmpty(cardId)) {
/* 218:346 */       throw new WeiboIllegalParameterException("cardId不能为空");
/* 219:    */     }
/* 220:348 */     if ((count != null) && (count.intValue() < 0)) {
/* 221:349 */       throw new WeiboIllegalParameterException("count不能为负数");
/* 222:    */     }
/* 223:352 */     StringBuilder uri = new StringBuilder("sinaweibo://pageweibolist");
/* 224:    */     
/* 225:354 */     HashMap<String, String> paramMap = new HashMap();
/* 226:355 */     paramMap.put("pageid", pageId);
/* 227:356 */     paramMap.put("cardid", cardId);
/* 228:357 */     paramMap.put("title", title);
/* 229:358 */     paramMap.put("page", "1");
/* 230:359 */     paramMap.put("count", String.valueOf(count));
/* 231:360 */     paramMap.put("extparam", extParam);
/* 232:    */     
/* 233:362 */     uri.append(CommonUtils.buildUriQuery(paramMap));
/* 234:    */     
/* 235:364 */     CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString());
/* 236:    */   }
/* 237:    */   
/* 238:    */   public static void viewPagePhotoList(Context context, String pageId, String cardId, String title, Integer count, String extParam)
/* 239:    */     throws WeiboNotInstalledException
/* 240:    */   {
/* 241:382 */     if (context == null) {
/* 242:383 */       throw new WeiboIllegalParameterException("context不能为空");
/* 243:    */     }
/* 244:385 */     if (TextUtils.isEmpty(pageId)) {
/* 245:386 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 246:    */     }
/* 247:388 */     if (TextUtils.isEmpty(cardId)) {
/* 248:389 */       throw new WeiboIllegalParameterException("cardId不能为空");
/* 249:    */     }
/* 250:391 */     if ((count != null) && (count.intValue() < 0)) {
/* 251:392 */       throw new WeiboIllegalParameterException("count不能为负数");
/* 252:    */     }
/* 253:395 */     StringBuilder uri = new StringBuilder("sinaweibo://pagephotolist");
/* 254:    */     
/* 255:397 */     HashMap<String, String> paramMap = new HashMap();
/* 256:398 */     paramMap.put("pageid", pageId);
/* 257:399 */     paramMap.put("cardid", cardId);
/* 258:400 */     paramMap.put("title", title);
/* 259:401 */     paramMap.put("page", "1");
/* 260:402 */     paramMap.put("count", String.valueOf(count));
/* 261:403 */     paramMap.put("extparam", extParam);
/* 262:    */     
/* 263:405 */     uri.append(CommonUtils.buildUriQuery(paramMap));
/* 264:    */     
/* 265:407 */     CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString());
/* 266:    */   }
/* 267:    */   
/* 268:    */   public static void viewPageDetailInfo(Context context, String pageId, String cardId, String title, String extParam)
/* 269:    */     throws WeiboNotInstalledException
/* 270:    */   {
/* 271:425 */     if (context == null) {
/* 272:426 */       throw new WeiboIllegalParameterException("context不能为空");
/* 273:    */     }
/* 274:428 */     if (TextUtils.isEmpty(pageId)) {
/* 275:429 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 276:    */     }
/* 277:431 */     if (TextUtils.isEmpty(cardId)) {
/* 278:432 */       throw new WeiboIllegalParameterException("cardId不能为空");
/* 279:    */     }
/* 280:435 */     StringBuilder uri = new StringBuilder("sinaweibo://pagedetailinfo");
/* 281:    */     
/* 282:437 */     HashMap<String, String> paramMap = new HashMap();
/* 283:438 */     paramMap.put("pageid", pageId);
/* 284:439 */     paramMap.put("cardid", cardId);
/* 285:440 */     paramMap.put("title", title);
/* 286:441 */     paramMap.put("extparam", extParam);
/* 287:    */     
/* 288:443 */     uri.append(CommonUtils.buildUriQuery(paramMap));
/* 289:    */     
/* 290:445 */     CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString());
/* 291:    */   }
/* 292:    */   
/* 293:    */   public static void openInWeiboBrowser(Context context, String url, String sinainternalbrowser, String extParam)
/* 294:    */     throws WeiboNotInstalledException
/* 295:    */   {
/* 296:462 */     if (context == null) {
/* 297:463 */       throw new WeiboIllegalParameterException("context不能为空");
/* 298:    */     }
/* 299:466 */     if (TextUtils.isEmpty(url)) {
/* 300:467 */       throw new WeiboIllegalParameterException("url不能为空");
/* 301:    */     }
/* 302:470 */     if ((!TextUtils.isEmpty(sinainternalbrowser)) && 
/* 303:471 */       (!"topnav".equals(sinainternalbrowser)) && 
/* 304:472 */       (!"default".equals(sinainternalbrowser)) && 
/* 305:473 */       (!"fullscreen".equals(sinainternalbrowser))) {
/* 306:474 */       throw new WeiboIllegalParameterException("sinainternalbrowser不合法");
/* 307:    */     }
/* 308:478 */     StringBuilder uri = new StringBuilder("sinaweibo://browser");
/* 309:    */     
/* 310:480 */     HashMap<String, String> paramMap = new HashMap();
/* 311:    */     
/* 312:482 */     paramMap.put("url", url);
/* 313:483 */     paramMap.put("sinainternalbrowser", sinainternalbrowser);
/* 314:484 */     paramMap.put("extparam", extParam);
/* 315:    */     
/* 316:486 */     uri.append(CommonUtils.buildUriQuery(paramMap));
/* 317:    */     
/* 318:488 */     CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString());
/* 319:    */   }
/* 320:    */   
/* 321:    */   public static void displayInWeiboMap(Context context, Position position, String extParam)
/* 322:    */     throws WeiboNotInstalledException
/* 323:    */   {
/* 324:504 */     if (context == null) {
/* 325:505 */       throw new WeiboIllegalParameterException("context不能为空");
/* 326:    */     }
/* 327:508 */     String mapUrl = "http://weibo.cn/dpool/ttt/maps.php?xy=%s,%s&amp;size=320x320&amp;offset=%s";
/* 328:509 */     String lon = "";
/* 329:510 */     String lat = "";
/* 330:511 */     String offset = "";
/* 331:513 */     if (position != null)
/* 332:    */     {
/* 333:514 */       lon = position.getStrLongitude();
/* 334:515 */       lat = position.getStrLatitude();
/* 335:516 */       offset = position.getStrOffset();
/* 336:    */     }
/* 337:519 */     openInWeiboBrowser(context, String.format(mapUrl, new Object[] { lon, lat, offset }), "default", extParam);
/* 338:    */   }
/* 339:    */   
/* 340:    */   public static void openQrcodeScanner(Context context, String extParam)
/* 341:    */     throws WeiboNotInstalledException
/* 342:    */   {
/* 343:533 */     if (context == null) {
/* 344:534 */       throw new WeiboIllegalParameterException("context不能为空");
/* 345:    */     }
/* 346:536 */     StringBuilder uri = new StringBuilder("sinaweibo://qrcode");
/* 347:    */     
/* 348:538 */     HashMap<String, String> paramMap = new HashMap();
/* 349:539 */     paramMap.put("extparam", extParam);
/* 350:    */     
/* 351:541 */     uri.append(CommonUtils.buildUriQuery(paramMap));
/* 352:    */     
/* 353:543 */     CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString());
/* 354:    */   }
/* 355:    */   
/* 356:    */   public static void viewNearPhotoList(Context context, String longitude_X, String latitude_Y, Integer count, String extParam)
/* 357:    */     throws WeiboNotInstalledException
/* 358:    */   {
/* 359:560 */     viewPagePhotoList(context, "100101" + longitude_X + "_" + latitude_Y, "nearphoto", "周边热图", count, extParam);
/* 360:    */   }
/* 361:    */   
/* 362:    */   public static void viewPoiPhotoList(Context context, String poiid, Integer count, String extParam)
/* 363:    */     throws WeiboNotInstalledException
/* 364:    */   {
/* 365:576 */     viewPagePhotoList(context, "100101" + poiid, "nearphoto", "周边热图", count, extParam);
/* 366:    */   }
/* 367:    */   
/* 368:    */   public static void viewPoiPage(Context context, String longitude_X, String latitude_Y, String title, String extParam)
/* 369:    */     throws WeiboNotInstalledException
/* 370:    */   {
/* 371:591 */     viewPageInfo(context, "100101" + longitude_X + "_" + latitude_Y, title, extParam);
/* 372:    */   }
/* 373:    */   
/* 374:    */   public static void weiboDetail(Context context, String mblogid, String extParam)
/* 375:    */     throws WeiboNotInstalledException
/* 376:    */   {
/* 377:605 */     if (context == null) {
/* 378:606 */       throw new WeiboIllegalParameterException("context不能为空");
/* 379:    */     }
/* 380:608 */     if (TextUtils.isEmpty(mblogid)) {
/* 381:609 */       throw new WeiboIllegalParameterException("pageId不能为空");
/* 382:    */     }
/* 383:612 */     StringBuilder uri = new StringBuilder("sinaweibo://detail");
/* 384:    */     
/* 385:614 */     HashMap<String, String> paramMap = new HashMap();
/* 386:615 */     paramMap.put("mblogid", mblogid);
/* 387:616 */     paramMap.put("extparam", extParam);
/* 388:    */     
/* 389:618 */     uri.append(CommonUtils.buildUriQuery(paramMap));
/* 390:619 */     CommonUtils.openWeiboActivity(context, "android.intent.action.VIEW", uri.toString());
/* 391:    */   }
/* 392:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.call.WeiboPageUtils
 * JD-Core Version:    0.7.0.1
 */