/*   1:    */ package com.sina.weibo.sdk.call;
/*   2:    */ 
/*   3:    */ public class Position
/*   4:    */ {
/*   5:    */   private float mLongitude;
/*   6:    */   private float mLatitude;
/*   7:    */   private boolean mOffset;
/*   8:    */   
/*   9:    */   public Position(float longitude, float latitude)
/*  10:    */   {
/*  11: 46 */     this.mLongitude = longitude;
/*  12: 47 */     this.mLatitude = latitude;
/*  13: 48 */     this.mOffset = true;
/*  14:    */   }
/*  15:    */   
/*  16:    */   public Position(float longitude, float latitude, boolean offset)
/*  17:    */   {
/*  18: 55 */     this.mLongitude = longitude;
/*  19: 56 */     this.mLatitude = latitude;
/*  20: 57 */     this.mOffset = offset;
/*  21:    */   }
/*  22:    */   
/*  23:    */   public float getLongitude()
/*  24:    */   {
/*  25: 66 */     return this.mLongitude;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public float getLatitude()
/*  29:    */   {
/*  30: 75 */     return this.mLatitude;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public boolean isOffset()
/*  34:    */   {
/*  35: 84 */     return this.mOffset;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public String getStrLongitude()
/*  39:    */   {
/*  40: 93 */     return String.valueOf(this.mLongitude);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public String getStrLatitude()
/*  44:    */   {
/*  45:102 */     return String.valueOf(this.mLatitude);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public String getStrOffset()
/*  49:    */   {
/*  50:111 */     return this.mOffset ? "1" : "0";
/*  51:    */   }
/*  52:    */   
/*  53:    */   boolean checkValid()
/*  54:    */   {
/*  55:120 */     if ((Float.isNaN(this.mLongitude)) || (this.mLongitude < -180.0F) || (this.mLongitude > 180.0F)) {
/*  56:121 */       return false;
/*  57:    */     }
/*  58:123 */     if ((Float.isNaN(this.mLatitude)) || (this.mLatitude < -180.0F) || (this.mLatitude > 180.0F)) {
/*  59:124 */       return false;
/*  60:    */     }
/*  61:126 */     return true;
/*  62:    */   }
/*  63:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.call.Position
 * JD-Core Version:    0.7.0.1
 */