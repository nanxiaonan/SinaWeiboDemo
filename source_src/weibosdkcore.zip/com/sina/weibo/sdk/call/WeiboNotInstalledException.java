/*  1:   */ package com.sina.weibo.sdk.call;
/*  2:   */ 
/*  3:   */ public class WeiboNotInstalledException
/*  4:   */   extends Exception
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 1249685537943340248L;
/*  7:   */   
/*  8:   */   public WeiboNotInstalledException() {}
/*  9:   */   
/* 10:   */   public WeiboNotInstalledException(String msg)
/* 11:   */   {
/* 12:44 */     super(msg);
/* 13:   */   }
/* 14:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.call.WeiboNotInstalledException
 * JD-Core Version:    0.7.0.1
 */