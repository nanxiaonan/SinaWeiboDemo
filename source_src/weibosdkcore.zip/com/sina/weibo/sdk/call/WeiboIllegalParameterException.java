/*  1:   */ package com.sina.weibo.sdk.call;
/*  2:   */ 
/*  3:   */ class WeiboIllegalParameterException
/*  4:   */   extends RuntimeException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = 7965739598010960851L;
/*  7:   */   
/*  8:   */   public WeiboIllegalParameterException() {}
/*  9:   */   
/* 10:   */   public WeiboIllegalParameterException(String msg)
/* 11:   */   {
/* 12:45 */     super(msg);
/* 13:   */   }
/* 14:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.call.WeiboIllegalParameterException
 * JD-Core Version:    0.7.0.1
 */