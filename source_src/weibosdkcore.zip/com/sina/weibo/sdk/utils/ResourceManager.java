/*   1:    */ package com.sina.weibo.sdk.utils;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.content.res.AssetManager;
/*   5:    */ import android.content.res.Configuration;
/*   6:    */ import android.content.res.Resources;
/*   7:    */ import android.content.res.XmlResourceParser;
/*   8:    */ import android.graphics.Bitmap;
/*   9:    */ import android.graphics.BitmapFactory;
/*  10:    */ import android.graphics.Rect;
/*  11:    */ import android.graphics.drawable.BitmapDrawable;
/*  12:    */ import android.graphics.drawable.Drawable;
/*  13:    */ import android.graphics.drawable.NinePatchDrawable;
/*  14:    */ import android.text.TextUtils;
/*  15:    */ import android.util.DisplayMetrics;
/*  16:    */ import android.util.SparseArray;
/*  17:    */ import android.util.SparseIntArray;
/*  18:    */ import android.util.TypedValue;
/*  19:    */ import android.view.LayoutInflater;
/*  20:    */ import android.view.View;
/*  21:    */ import android.view.ViewGroup;
/*  22:    */ import java.io.IOException;
/*  23:    */ import java.io.InputStream;
/*  24:    */ import java.util.HashMap;
/*  25:    */ import java.util.Locale;
/*  26:    */ 
/*  27:    */ public class ResourceManager
/*  28:    */ {
/*  29: 51 */   private static final String TAG = ResourceManager.class.getName();
/*  30:    */   public static final int dimen_dialog_left_margin = 1;
/*  31:    */   public static final int dimen_dialog_top_margin = 2;
/*  32:    */   public static final int dimen_dialog_right_margin = 3;
/*  33:    */   public static final int dimen_dialog_bottom_margin = 4;
/*  34:    */   public static final int DIALOG_LEFT_MARGIN = 10;
/*  35:    */   public static final int DIALOG_TOP_MARGIN = 30;
/*  36:    */   public static final int DIALOG_RIGHT_MARGIN = 10;
/*  37:    */   public static final int DIALOG_BOTTOM_MARGIN = 10;
/*  38: 74 */   private static final SparseIntArray sLayoutMap = new SparseIntArray();
/*  39:    */   public static final int drawable_dialog_background = 1;
/*  40:    */   public static final int drawable_dialog_close_button = 2;
/*  41:    */   private static final String DIALOG_BACKGROUND_IMAGE_NAME = "weibosdk_dialog_bg.9.png";
/*  42:    */   private static final String DIALOG_CLOSE_BUTTON_IMAGE_NAME = "ic_com_sina_weibo_sdk_close.png";
/*  43:    */   private static final String DRAWABLE = "drawable";
/*  44:    */   private static final String DRAWABLE_LDPI = "drawable-ldpi";
/*  45:    */   private static final String DRAWABLE_MDPI = "drawable-mdpi";
/*  46:    */   private static final String DRAWABLE_HDPI = "drawable-hdpi";
/*  47:    */   private static final String DRAWABLE_XHDPI = "drawable-xhdpi";
/*  48:    */   private static final String DRAWABLE_XXHDPI = "drawable-xxhdpi";
/*  49:    */   private static final String[] PRE_INSTALL_DRAWBLE_PATHS;
/*  50:    */   private static final SparseArray<String> sDrawableMap;
/*  51:    */   public static final int string_loading = 1;
/*  52:    */   public static final int string_network_not_available = 2;
/*  53:    */   private static final String LOADING_EN = "Loading...";
/*  54:    */   private static final String LOADING_ZH_CN = "加载中...";
/*  55:    */   private static final String LOADING_ZH_TW = "載入中...";
/*  56:    */   private static final String NETWORK_NOT_AVAILABLE_EN = "Network is not available";
/*  57:    */   private static final String NETWORK_NOT_AVAILABLE_ZH_CN = "无法连接到网络，请检查网络配置";
/*  58:    */   private static final String NETWORK_NOT_AVAILABLE_ZH_TW = "無法連接到網络，請檢查網络配置";
/*  59:    */   private static final HashMap<Locale, SparseArray<String>> sLanguageMap;
/*  60:    */   
/*  61:    */   static
/*  62:    */   {
/*  63: 75 */     sLayoutMap.put(1, 10);
/*  64: 76 */     sLayoutMap.put(2, 30);
/*  65: 77 */     sLayoutMap.put(3, 10);
/*  66: 78 */     sLayoutMap.put(4, 10);
/*  67:    */     
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:    */ 
/*  85:    */ 
/*  86: 98 */     PRE_INSTALL_DRAWBLE_PATHS = new String[] {
/*  87: 99 */       "drawable-xxhdpi", 
/*  88:100 */       "drawable-xhdpi", 
/*  89:101 */       "drawable-hdpi", 
/*  90:102 */       "drawable-mdpi", 
/*  91:103 */       "drawable-ldpi", 
/*  92:104 */       "drawable" };
/*  93:    */     
/*  94:    */ 
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:    */ 
/* 102:    */ 
/* 103:115 */     sDrawableMap = new SparseArray();
/* 104:116 */     sDrawableMap.put(1, "weibosdk_dialog_bg.9.png");
/* 105:117 */     sDrawableMap.put(2, "ic_com_sina_weibo_sdk_close.png");
/* 106:    */     
/* 107:    */ 
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:    */ 
/* 114:    */ 
/* 115:    */ 
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:    */ 
/* 120:    */ 
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:    */ 
/* 125:    */ 
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:    */ 
/* 134:146 */     sLanguageMap = new HashMap();
/* 135:    */     
/* 136:148 */     SparseArray<String> stringMap = new SparseArray();
/* 137:149 */     stringMap.put(1, "加载中...");
/* 138:150 */     stringMap.put(2, "无法连接到网络，请检查网络配置");
/* 139:151 */     sLanguageMap.put(Locale.SIMPLIFIED_CHINESE, stringMap);
/* 140:    */     
/* 141:153 */     stringMap = new SparseArray();
/* 142:154 */     stringMap.put(1, "載入中...");
/* 143:155 */     stringMap.put(2, "無法連接到網络，請檢查網络配置");
/* 144:156 */     sLanguageMap.put(Locale.TRADITIONAL_CHINESE, stringMap);
/* 145:    */     
/* 146:158 */     stringMap = new SparseArray();
/* 147:159 */     stringMap.put(1, "Loading...");
/* 148:160 */     stringMap.put(2, "Network is not available");
/* 149:161 */     sLanguageMap.put(Locale.ENGLISH, stringMap);
/* 150:    */   }
/* 151:    */   
/* 152:    */   public static String getString(Context context, int id)
/* 153:    */   {
/* 154:173 */     Locale locale = getLanguage();
/* 155:174 */     SparseArray<String> stringMap = (SparseArray)sLanguageMap.get(locale);
/* 156:175 */     return (String)stringMap.get(id, "");
/* 157:    */   }
/* 158:    */   
/* 159:    */   public static Drawable getDrawable(Context context, int id)
/* 160:    */   {
/* 161:187 */     String path = getAppropriatePathOfDrawable(context, (String)sDrawableMap.get(id, ""));
/* 162:188 */     return getDrawableFromAssert(context, path, false);
/* 163:    */   }
/* 164:    */   
/* 165:    */   public static Drawable getNinePatchDrawable(Context context, int id)
/* 166:    */   {
/* 167:200 */     String path = getAppropriatePathOfDrawable(context, (String)sDrawableMap.get(id, ""));
/* 168:201 */     return getDrawableFromAssert(context, path, true);
/* 169:    */   }
/* 170:    */   
/* 171:    */   public static int getDimensionPixelSize(int id)
/* 172:    */   {
/* 173:212 */     return sLayoutMap.get(id, 0);
/* 174:    */   }
/* 175:    */   
/* 176:    */   public static Locale getLanguage()
/* 177:    */   {
/* 178:221 */     Locale locale = Locale.getDefault();
/* 179:222 */     if ((Locale.SIMPLIFIED_CHINESE.equals(locale)) || 
/* 180:223 */       (Locale.TRADITIONAL_CHINESE.equals(locale))) {
/* 181:224 */       return locale;
/* 182:    */     }
/* 183:226 */     return Locale.ENGLISH;
/* 184:    */   }
/* 185:    */   
/* 186:    */   public static String getAppropriatePathOfDrawable(Context context, String fileName)
/* 187:    */   {
/* 188:241 */     if (TextUtils.isEmpty(fileName))
/* 189:    */     {
/* 190:242 */       LogUtil.e(TAG, "id is NOT correct!");
/* 191:243 */       return null;
/* 192:    */     }
/* 193:246 */     String pathPrefix = getCurrentDpiFolder(context);
/* 194:247 */     String path = pathPrefix + "/" + fileName;
/* 195:248 */     LogUtil.i(TAG, "Maybe the appropriate path: " + path);
/* 196:249 */     if (isFileExisted(context, path)) {
/* 197:250 */       return path;
/* 198:    */     }
/* 199:252 */     LogUtil.d(TAG, "Not the correct path, we need to find one...");
/* 200:    */     
/* 201:254 */     int ix = 0;
/* 202:255 */     boolean bFound = false;
/* 203:256 */     for (ix = 0; ix < PRE_INSTALL_DRAWBLE_PATHS.length; ix++) {
/* 204:257 */       if (!bFound)
/* 205:    */       {
/* 206:258 */         if (pathPrefix.equals(PRE_INSTALL_DRAWBLE_PATHS[ix]))
/* 207:    */         {
/* 208:259 */           bFound = true;
/* 209:260 */           LogUtil.i(TAG, "Have Find index: " + ix + ", " + PRE_INSTALL_DRAWBLE_PATHS[ix]);
/* 210:    */         }
/* 211:    */       }
/* 212:    */       else
/* 213:    */       {
/* 214:263 */         path = PRE_INSTALL_DRAWBLE_PATHS[ix] + "/" + fileName;
/* 215:264 */         if (isFileExisted(context, path)) {
/* 216:265 */           return path;
/* 217:    */         }
/* 218:    */       }
/* 219:    */     }
/* 220:271 */     LogUtil.e(TAG, "Not find the appropriate path for drawable");
/* 221:    */     
/* 222:273 */     return null;
/* 223:    */   }
/* 224:    */   
/* 225:    */   public static Drawable getDrawableFromAssert(Context context, String relativePath, boolean isNinePatch)
/* 226:    */   {
/* 227:288 */     Drawable rtDrawable = null;
/* 228:289 */     AssetManager asseets = context.getAssets();
/* 229:290 */     InputStream is = null;
/* 230:    */     try
/* 231:    */     {
/* 232:292 */       is = asseets.open(relativePath);
/* 233:293 */       if (is != null)
/* 234:    */       {
/* 235:294 */         Bitmap bitmap = BitmapFactory.decodeStream(is);
/* 236:295 */         DisplayMetrics metrics = context.getResources().getDisplayMetrics();
/* 237:296 */         if (isNinePatch)
/* 238:    */         {
/* 239:297 */           Configuration config = context.getResources().getConfiguration();
/* 240:298 */           Resources res = new Resources(context.getAssets(), metrics, config);
/* 241:299 */           rtDrawable = new NinePatchDrawable(
/* 242:300 */             res, bitmap, bitmap.getNinePatchChunk(), new Rect(0, 0, 0, 0), null);
/* 243:    */         }
/* 244:    */         else
/* 245:    */         {
/* 246:302 */           bitmap.setDensity(metrics.densityDpi);
/* 247:303 */           rtDrawable = new BitmapDrawable(context.getResources(), bitmap);
/* 248:    */         }
/* 249:    */       }
/* 250:    */     }
/* 251:    */     catch (IOException e)
/* 252:    */     {
/* 253:307 */       e.printStackTrace();
/* 254:    */     }
/* 255:    */     finally
/* 256:    */     {
/* 257:309 */       if (is != null)
/* 258:    */       {
/* 259:    */         try
/* 260:    */         {
/* 261:311 */           is.close();
/* 262:    */         }
/* 263:    */         catch (IOException e)
/* 264:    */         {
/* 265:313 */           e.printStackTrace();
/* 266:    */         }
/* 267:316 */         is = null;
/* 268:    */       }
/* 269:    */     }
/* 270:320 */     return rtDrawable;
/* 271:    */   }
/* 272:    */   
/* 273:    */   private static boolean isFileExisted(Context context, String filePath)
/* 274:    */   {
/* 275:331 */     if ((context == null) || (TextUtils.isEmpty(filePath))) {
/* 276:332 */       return false;
/* 277:    */     }
/* 278:335 */     AssetManager asseets = context.getAssets();
/* 279:336 */     InputStream is = null;
/* 280:    */     try
/* 281:    */     {
/* 282:338 */       is = asseets.open(filePath);
/* 283:339 */       LogUtil.d(TAG, "file [" + filePath + "] existed");
/* 284:340 */       return true;
/* 285:    */     }
/* 286:    */     catch (IOException e)
/* 287:    */     {
/* 288:343 */       LogUtil.d(TAG, "file [" + filePath + "] NOT existed");
/* 289:    */     }
/* 290:    */     finally
/* 291:    */     {
/* 292:    */       try
/* 293:    */       {
/* 294:346 */         if (is != null) {
/* 295:347 */           is.close();
/* 296:    */         }
/* 297:    */       }
/* 298:    */       catch (IOException e)
/* 299:    */       {
/* 300:350 */         e.printStackTrace();
/* 301:351 */         is = null;
/* 302:    */       }
/* 303:    */     }
/* 304:355 */     return false;
/* 305:    */   }
/* 306:    */   
/* 307:    */   private static String getCurrentDpiFolder(Context context)
/* 308:    */   {
/* 309:366 */     DisplayMetrics dm = context.getResources().getDisplayMetrics();
/* 310:367 */     int density = dm.densityDpi;
/* 311:368 */     if (density <= 120) {
/* 312:369 */       return "drawable-ldpi";
/* 313:    */     }
/* 314:370 */     if ((density > 120) && (density <= 160)) {
/* 315:371 */       return "drawable-mdpi";
/* 316:    */     }
/* 317:372 */     if ((density > 160) && (density <= 240)) {
/* 318:373 */       return "drawable-hdpi";
/* 319:    */     }
/* 320:374 */     if ((density > 240) && (density <= 320)) {
/* 321:375 */       return "drawable-xhdpi";
/* 322:    */     }
/* 323:377 */     return "drawable-xxhdpi";
/* 324:    */   }
/* 325:    */   
/* 326:    */   private static View extractView(Context context, String fileName, ViewGroup root)
/* 327:    */     throws Exception
/* 328:    */   {
/* 329:384 */     XmlResourceParser parser = context.getAssets().openXmlResourceParser(fileName);
/* 330:385 */     LayoutInflater inflater = (LayoutInflater)context
/* 331:386 */       .getSystemService("layout_inflater");
/* 332:387 */     return inflater.inflate(parser, root);
/* 333:    */   }
/* 334:    */   
/* 335:    */   private static Drawable extractDrawable(Context context, String fileName)
/* 336:    */     throws Exception
/* 337:    */   {
/* 338:392 */     InputStream inputStream = context.getAssets().open(fileName);
/* 339:393 */     DisplayMetrics dm = context.getResources().getDisplayMetrics();
/* 340:394 */     TypedValue value = new TypedValue();
/* 341:    */     
/* 342:396 */     value.density = dm.densityDpi;
/* 343:    */     
/* 344:398 */     Drawable drawable = Drawable.createFromResourceStream(
/* 345:399 */       context.getResources(), value, inputStream, fileName);
/* 346:400 */     inputStream.close();
/* 347:401 */     return drawable;
/* 348:    */   }
/* 349:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.utils.ResourceManager
 * JD-Core Version:    0.7.0.1
 */