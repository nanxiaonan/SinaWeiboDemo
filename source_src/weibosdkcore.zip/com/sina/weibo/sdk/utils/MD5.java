/*  1:   */ package com.sina.weibo.sdk.utils;
/*  2:   */ 
/*  3:   */ import java.io.PrintStream;
/*  4:   */ import java.security.MessageDigest;
/*  5:   */ 
/*  6:   */ public class MD5
/*  7:   */ {
/*  8:29 */   private static final char[] hexDigits = {
/*  9:30 */     '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/* 10:   */   
/* 11:   */   public static String hexdigest(String string)
/* 12:   */   {
/* 13:33 */     String s = null;
/* 14:   */     try
/* 15:   */     {
/* 16:36 */       s = hexdigest(string.getBytes());
/* 17:   */     }
/* 18:   */     catch (Exception e)
/* 19:   */     {
/* 20:38 */       e.printStackTrace();
/* 21:   */     }
/* 22:40 */     return s;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public static String hexdigest(byte[] bytes)
/* 26:   */   {
/* 27:44 */     String s = null;
/* 28:   */     try
/* 29:   */     {
/* 30:46 */       MessageDigest md = MessageDigest.getInstance("MD5");
/* 31:47 */       md.update(bytes);
/* 32:48 */       byte[] tmp = md.digest();
/* 33:49 */       char[] str = new char[32];
/* 34:50 */       int k = 0;
/* 35:51 */       for (int i = 0; i < 16; i++)
/* 36:   */       {
/* 37:52 */         byte byte0 = tmp[i];
/* 38:53 */         str[(k++)] = hexDigits[(byte0 >>> 4 & 0xF)];
/* 39:54 */         str[(k++)] = hexDigits[(byte0 & 0xF)];
/* 40:   */       }
/* 41:56 */       s = new String(str);
/* 42:   */     }
/* 43:   */     catch (Exception e)
/* 44:   */     {
/* 45:58 */       e.printStackTrace();
/* 46:   */     }
/* 47:60 */     return s;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public static void main(String[] args)
/* 51:   */   {
/* 52:64 */     System.out.println(hexdigest("c"));
/* 53:   */   }
/* 54:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.utils.MD5
 * JD-Core Version:    0.7.0.1
 */