/*   1:    */ package com.sina.weibo.sdk.utils;
/*   2:    */ 
/*   3:    */ import android.graphics.BitmapFactory;
/*   4:    */ import android.graphics.BitmapFactory.Options;
/*   5:    */ import android.graphics.Rect;
/*   6:    */ import java.io.BufferedInputStream;
/*   7:    */ import java.io.ByteArrayInputStream;
/*   8:    */ import java.io.FileInputStream;
/*   9:    */ import java.io.FileNotFoundException;
/*  10:    */ import java.io.IOException;
/*  11:    */ import java.io.InputStream;
/*  12:    */ 
/*  13:    */ public final class BitmapHelper
/*  14:    */ {
/*  15:    */   public static boolean makesureSizeNotTooLarge(Rect rect)
/*  16:    */   {
/*  17: 42 */     int FIVE_M = 5242880;
/*  18: 43 */     if (rect.width() * rect.height() * 2 > 5242880) {
/*  19: 45 */       return false;
/*  20:    */     }
/*  21: 47 */     return true;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public static int getSampleSizeOfNotTooLarge(Rect rect)
/*  25:    */   {
/*  26: 51 */     int FIVE_M = 5242880;
/*  27: 52 */     double ratio = rect.width() * rect.height() * 2.0D / 5242880.0D;
/*  28: 53 */     return ratio >= 1.0D ? (int)ratio : 1;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static int getSampleSizeAutoFitToScreen(int vWidth, int vHeight, int bWidth, int bHeight)
/*  32:    */   {
/*  33: 61 */     if ((vHeight == 0) || (vWidth == 0)) {
/*  34: 62 */       return 1;
/*  35:    */     }
/*  36: 65 */     int ratio = Math.max(bWidth / vWidth, bHeight / vHeight);
/*  37:    */     
/*  38: 67 */     int ratioAfterRotate = Math.max(bHeight / vWidth, bWidth / vHeight);
/*  39:    */     
/*  40: 69 */     return Math.min(ratio, ratioAfterRotate);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static boolean verifyBitmap(byte[] datas)
/*  44:    */   {
/*  45: 76 */     return verifyBitmap(new ByteArrayInputStream(datas));
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static boolean verifyBitmap(InputStream input)
/*  49:    */   {
/*  50: 83 */     if (input == null) {
/*  51: 84 */       return false;
/*  52:    */     }
/*  53: 86 */     BitmapFactory.Options options = new BitmapFactory.Options();
/*  54: 87 */     options.inJustDecodeBounds = true;
/*  55: 88 */     input = (input instanceof BufferedInputStream) ? input : new BufferedInputStream(input);
/*  56: 89 */     BitmapFactory.decodeStream(input, null, options);
/*  57:    */     try
/*  58:    */     {
/*  59: 91 */       input.close();
/*  60:    */     }
/*  61:    */     catch (IOException e)
/*  62:    */     {
/*  63: 93 */       e.printStackTrace();
/*  64:    */     }
/*  65: 96 */     return (options.outHeight > 0) && (options.outWidth > 0);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public static boolean verifyBitmap(String path)
/*  69:    */   {
/*  70:    */     try
/*  71:    */     {
/*  72:104 */       return verifyBitmap(new FileInputStream(path));
/*  73:    */     }
/*  74:    */     catch (FileNotFoundException e)
/*  75:    */     {
/*  76:106 */       e.printStackTrace();
/*  77:    */     }
/*  78:108 */     return false;
/*  79:    */   }
/*  80:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.utils.BitmapHelper
 * JD-Core Version:    0.7.0.1
 */