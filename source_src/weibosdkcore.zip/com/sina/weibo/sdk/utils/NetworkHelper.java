/*   1:    */ package com.sina.weibo.sdk.utils;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.net.ConnectivityManager;
/*   5:    */ import android.net.NetworkInfo;
/*   6:    */ import android.net.NetworkInfo.DetailedState;
/*   7:    */ import android.net.wifi.ScanResult;
/*   8:    */ import android.net.wifi.WifiConfiguration;
/*   9:    */ import android.net.wifi.WifiInfo;
/*  10:    */ import android.net.wifi.WifiManager;
/*  11:    */ import android.webkit.CookieManager;
/*  12:    */ import android.webkit.CookieSyncManager;
/*  13:    */ import java.util.List;
/*  14:    */ 
/*  15:    */ public class NetworkHelper
/*  16:    */ {
/*  17:    */   public static boolean hasInternetPermission(Context context)
/*  18:    */   {
/*  19: 51 */     if (context != null) {
/*  20: 52 */       return context.checkCallingOrSelfPermission("android.permission.INTERNET") == 0;
/*  21:    */     }
/*  22: 56 */     return true;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static boolean isNetworkAvailable(Context context)
/*  26:    */   {
/*  27: 67 */     if (context != null)
/*  28:    */     {
/*  29: 68 */       NetworkInfo info = getActiveNetworkInfo(context);
/*  30: 69 */       return (info != null) && (info.isConnected());
/*  31:    */     }
/*  32: 72 */     return false;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static boolean isWifiValid(Context context)
/*  36:    */   {
/*  37: 83 */     if (context != null)
/*  38:    */     {
/*  39: 84 */       NetworkInfo info = getActiveNetworkInfo(context);
/*  40:    */       
/*  41: 86 */       return (info != null) && 
/*  42: 87 */         (1 == info.getType()) && 
/*  43: 88 */         (info.isConnected());
/*  44:    */     }
/*  45: 91 */     return false;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static boolean isMobileNetwork(Context context)
/*  49:    */   {
/*  50:102 */     if (context != null)
/*  51:    */     {
/*  52:103 */       NetworkInfo info = getActiveNetworkInfo(context);
/*  53:105 */       if (info == null) {
/*  54:106 */         return false;
/*  55:    */       }
/*  56:109 */       return (info != null) && 
/*  57:110 */         (info.getType() == 0) && 
/*  58:111 */         (info.isConnected());
/*  59:    */     }
/*  60:114 */     return false;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static NetworkInfo getActiveNetworkInfo(Context context)
/*  64:    */   {
/*  65:125 */     ConnectivityManager connectivity = 
/*  66:126 */       (ConnectivityManager)context.getSystemService("connectivity");
/*  67:127 */     return connectivity.getActiveNetworkInfo();
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static NetworkInfo getNetworkInfo(Context context, int networkType)
/*  71:    */   {
/*  72:150 */     ConnectivityManager connectivityManager = 
/*  73:151 */       (ConnectivityManager)context.getSystemService("connectivity");
/*  74:152 */     return connectivityManager.getNetworkInfo(networkType);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public static int getNetworkType(Context context)
/*  78:    */   {
/*  79:174 */     if (context != null)
/*  80:    */     {
/*  81:175 */       NetworkInfo info = getActiveNetworkInfo(context);
/*  82:    */       
/*  83:177 */       return info == null ? -1 : info.getType();
/*  84:    */     }
/*  85:180 */     return -1;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public static int getWifiState(Context context)
/*  89:    */   {
/*  90:196 */     WifiManager wifi = (WifiManager)context.getSystemService("wifi");
/*  91:198 */     if (wifi == null) {
/*  92:199 */       return 4;
/*  93:    */     }
/*  94:202 */     return wifi.getWifiState();
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static NetworkInfo.DetailedState getWifiConnectivityState(Context context)
/*  98:    */   {
/*  99:213 */     NetworkInfo networkInfo = getNetworkInfo(context, 1);
/* 100:214 */     return networkInfo == null ? NetworkInfo.DetailedState.FAILED : networkInfo.getDetailedState();
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static boolean wifiConnection(Context context, String wifiSSID, String password)
/* 104:    */   {
/* 105:228 */     boolean isConnection = false;
/* 106:229 */     WifiManager wifi = (WifiManager)context.getSystemService("wifi");
/* 107:230 */     String strQuotationSSID = "\"" + wifiSSID + "\"";
/* 108:    */     
/* 109:232 */     WifiInfo wifiInfo = wifi.getConnectionInfo();
/* 110:233 */     if ((wifiInfo != null) && (
/* 111:234 */       (wifiSSID.equals(wifiInfo.getSSID())) || (strQuotationSSID.equals(wifiInfo.getSSID()))))
/* 112:    */     {
/* 113:235 */       isConnection = true;
/* 114:    */     }
/* 115:    */     else
/* 116:    */     {
/* 117:237 */       List<ScanResult> scanResults = wifi.getScanResults();
/* 118:238 */       if ((scanResults != null) && (scanResults.size() != 0)) {
/* 119:239 */         for (int nAllIndex = scanResults.size() - 1; nAllIndex >= 0; nAllIndex--)
/* 120:    */         {
/* 121:240 */           String strScanSSID = ((ScanResult)scanResults.get(nAllIndex)).SSID;
/* 122:241 */           if ((wifiSSID.equals(strScanSSID)) || (strQuotationSSID.equals(strScanSSID)))
/* 123:    */           {
/* 124:242 */             WifiConfiguration config = new WifiConfiguration();
/* 125:243 */             config.SSID = strQuotationSSID;
/* 126:244 */             config.preSharedKey = ("\"" + password + "\"");
/* 127:245 */             config.status = 2;
/* 128:    */             
/* 129:247 */             int nAddWifiId = wifi.addNetwork(config);
/* 130:248 */             isConnection = wifi.enableNetwork(nAddWifiId, false);
/* 131:249 */             break;
/* 132:    */           }
/* 133:    */         }
/* 134:    */       }
/* 135:    */     }
/* 136:255 */     return isConnection;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public static void clearCookies(Context context, String url)
/* 140:    */   {
/* 141:264 */     CookieSyncManager.createInstance(context);
/* 142:265 */     CookieManager cookieManager = CookieManager.getInstance();
/* 143:266 */     cookieManager.setAcceptCookie(true);
/* 144:267 */     cookieManager.removeSessionCookie();
/* 145:268 */     cookieManager.removeAllCookie();
/* 146:269 */     CookieSyncManager.getInstance().sync();
/* 147:    */   }
/* 148:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.utils.NetworkHelper
 * JD-Core Version:    0.7.0.1
 */