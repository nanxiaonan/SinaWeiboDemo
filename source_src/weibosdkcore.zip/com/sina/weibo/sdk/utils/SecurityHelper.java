/*   1:    */ package com.sina.weibo.sdk.utils;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.content.Intent;
/*   5:    */ import android.content.pm.ActivityInfo;
/*   6:    */ import android.content.pm.PackageInfo;
/*   7:    */ import android.content.pm.PackageManager;
/*   8:    */ import android.content.pm.PackageManager.NameNotFoundException;
/*   9:    */ import android.content.pm.ResolveInfo;
/*  10:    */ import android.content.pm.Signature;
/*  11:    */ import com.sina.weibo.sdk.api.share.ApiUtils;
/*  12:    */ import com.sina.weibo.sdk.api.share.ApiUtils.WeiboInfo;
/*  13:    */ 
/*  14:    */ public class SecurityHelper
/*  15:    */ {
/*  16:    */   private static final String WEIBO_MD5_SIGNATURE = "18da2bf10352443a00a5e046d9fca6bd";
/*  17:    */   
/*  18:    */   public static boolean validateAppSignatureForIntent(Context context, Intent intent)
/*  19:    */   {
/*  20: 57 */     PackageManager pkgMgr = context.getPackageManager();
/*  21: 58 */     if (pkgMgr == null) {
/*  22: 59 */       return false;
/*  23:    */     }
/*  24: 62 */     ResolveInfo resolveInfo = pkgMgr.resolveActivity(intent, 0);
/*  25: 63 */     if (resolveInfo == null) {
/*  26: 64 */       return false;
/*  27:    */     }
/*  28: 67 */     String packageName = resolveInfo.activityInfo.packageName;
/*  29:    */     try
/*  30:    */     {
/*  31: 69 */       PackageInfo packageInfo = pkgMgr.getPackageInfo(packageName, 64);
/*  32: 70 */       return containSign(packageInfo.signatures, "18da2bf10352443a00a5e046d9fca6bd");
/*  33:    */     }
/*  34:    */     catch (PackageManager.NameNotFoundException e)
/*  35:    */     {
/*  36: 72 */       e.printStackTrace();
/*  37:    */     }
/*  38:    */     catch (Exception e)
/*  39:    */     {
/*  40: 74 */       e.printStackTrace();
/*  41:    */     }
/*  42: 77 */     return false;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static boolean checkResponseAppLegal(Context context, Intent intent)
/*  46:    */   {
/*  47: 90 */     ApiUtils.WeiboInfo winfo = ApiUtils.queryWeiboInfo(context);
/*  48: 91 */     if ((winfo != null) && (winfo.supportApi <= 10352)) {
/*  49: 92 */       return true;
/*  50:    */     }
/*  51: 93 */     if (winfo == null) {
/*  52: 94 */       return true;
/*  53:    */     }
/*  54: 98 */     String appPackage = intent != null ? intent.getStringExtra("_weibo_appPackage") : null;
/*  55:100 */     if ((appPackage == null) || 
/*  56:101 */       (intent.getStringExtra("_weibo_transaction") == null) || 
/*  57:102 */       (!ApiUtils.validateWeiboSign(context, appPackage))) {
/*  58:103 */       return false;
/*  59:    */     }
/*  60:106 */     return true;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static boolean containSign(Signature[] signatures, String destSign)
/*  64:    */   {
/*  65:118 */     if ((signatures == null) || (destSign == null)) {
/*  66:119 */       return false;
/*  67:    */     }
/*  68:122 */     Signature[] arrayOfSignature = signatures;int j = signatures.length;
/*  69:122 */     for (int i = 0; i < j; i++)
/*  70:    */     {
/*  71:122 */       Signature signature = arrayOfSignature[i];
/*  72:123 */       String s = MD5.hexdigest(signature.toByteArray());
/*  73:124 */       if (destSign.equals(s)) {
/*  74:125 */         return true;
/*  75:    */       }
/*  76:    */     }
/*  77:129 */     return false;
/*  78:    */   }
/*  79:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.utils.SecurityHelper
 * JD-Core Version:    0.7.0.1
 */