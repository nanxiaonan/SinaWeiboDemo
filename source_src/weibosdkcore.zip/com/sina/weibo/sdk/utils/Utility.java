/*   1:    */ package com.sina.weibo.sdk.utils;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.content.pm.PackageInfo;
/*   5:    */ import android.content.pm.PackageManager;
/*   6:    */ import android.content.pm.PackageManager.NameNotFoundException;
/*   7:    */ import android.content.pm.Signature;
/*   8:    */ import android.content.res.Configuration;
/*   9:    */ import android.content.res.Resources;
/*  10:    */ import android.os.Bundle;
/*  11:    */ import android.text.TextUtils;
/*  12:    */ import java.io.UnsupportedEncodingException;
/*  13:    */ import java.net.MalformedURLException;
/*  14:    */ import java.net.URL;
/*  15:    */ import java.net.URLDecoder;
/*  16:    */ import java.util.Locale;
/*  17:    */ import java.util.UUID;
/*  18:    */ 
/*  19:    */ public class Utility
/*  20:    */ {
/*  21:    */   private static final String DEFAULT_CHARSET = "UTF-8";
/*  22:    */   
/*  23:    */   public static Bundle parseUrl(String url)
/*  24:    */   {
/*  25:    */     try
/*  26:    */     {
/*  27: 50 */       URL u = new URL(url);
/*  28: 51 */       Bundle b = decodeUrl(u.getQuery());
/*  29: 52 */       b.putAll(decodeUrl(u.getRef()));
/*  30: 53 */       return b;
/*  31:    */     }
/*  32:    */     catch (MalformedURLException e) {}
/*  33: 55 */     return new Bundle();
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static Bundle decodeUrl(String s)
/*  37:    */   {
/*  38: 65 */     Bundle params = new Bundle();
/*  39: 66 */     if (s != null)
/*  40:    */     {
/*  41: 67 */       String[] array = s.split("&");
/*  42: 68 */       for (String parameter : array)
/*  43:    */       {
/*  44: 69 */         String[] v = parameter.split("=");
/*  45:    */         try
/*  46:    */         {
/*  47: 71 */           params.putString(URLDecoder.decode(v[0], "UTF-8"), 
/*  48: 72 */             URLDecoder.decode(v[1], "UTF-8"));
/*  49:    */         }
/*  50:    */         catch (UnsupportedEncodingException e)
/*  51:    */         {
/*  52: 74 */           e.printStackTrace();
/*  53:    */         }
/*  54:    */       }
/*  55:    */     }
/*  56: 78 */     return params;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static boolean isChineseLocale(Context context)
/*  60:    */   {
/*  61:    */     try
/*  62:    */     {
/*  63: 90 */       Locale locale = context.getResources().getConfiguration().locale;
/*  64: 91 */       if ((Locale.CHINA.equals(locale)) || 
/*  65: 92 */         (Locale.CHINESE.equals(locale)) || 
/*  66: 93 */         (Locale.SIMPLIFIED_CHINESE.equals(locale)) || 
/*  67: 94 */         (Locale.TAIWAN.equals(locale))) {
/*  68: 95 */         return true;
/*  69:    */       }
/*  70:    */     }
/*  71:    */     catch (Exception e)
/*  72:    */     {
/*  73: 98 */       return true;
/*  74:    */     }
/*  75:100 */     return false;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public static String generateGUID()
/*  79:    */   {
/*  80:109 */     return UUID.randomUUID().toString().replace("-", "");
/*  81:    */   }
/*  82:    */   
/*  83:    */   public static String getSign(Context context, String pkgName)
/*  84:    */   {
/*  85:    */     try
/*  86:    */     {
/*  87:123 */       packageInfo = context.getPackageManager().getPackageInfo(pkgName, 
/*  88:124 */         64);
/*  89:    */     }
/*  90:    */     catch (PackageManager.NameNotFoundException localNameNotFoundException)
/*  91:    */     {
/*  92:    */       PackageInfo packageInfo;
/*  93:126 */       return null;
/*  94:    */     }
/*  95:    */     PackageInfo packageInfo;
/*  96:128 */     for (int j = 0; j < packageInfo.signatures.length; j++)
/*  97:    */     {
/*  98:129 */       byte[] str = packageInfo.signatures[j].toByteArray();
/*  99:130 */       if (str != null) {
/* 100:131 */         return MD5.hexdigest(str);
/* 101:    */       }
/* 102:    */     }
/* 103:134 */     return null;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public static String safeString(String orignal)
/* 107:    */   {
/* 108:138 */     return TextUtils.isEmpty(orignal) ? "" : orignal;
/* 109:    */   }
/* 110:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.utils.Utility
 * JD-Core Version:    0.7.0.1
 */