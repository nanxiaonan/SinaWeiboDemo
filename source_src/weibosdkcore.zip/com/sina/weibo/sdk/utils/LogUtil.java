/*   1:    */ package com.sina.weibo.sdk.utils;
/*   2:    */ 
/*   3:    */ import android.util.Log;
/*   4:    */ 
/*   5:    */ public class LogUtil
/*   6:    */ {
/*   7: 30 */   private static boolean sIsLogEnable = true;
/*   8:    */   
/*   9:    */   public static void enableLog()
/*  10:    */   {
/*  11: 36 */     sIsLogEnable = true;
/*  12:    */   }
/*  13:    */   
/*  14:    */   public static void disableLog()
/*  15:    */   {
/*  16: 43 */     sIsLogEnable = false;
/*  17:    */   }
/*  18:    */   
/*  19:    */   public static void d(String tag, String msg)
/*  20:    */   {
/*  21: 53 */     if (sIsLogEnable)
/*  22:    */     {
/*  23: 55 */       StackTraceElement stackTrace = java.lang.Thread.currentThread().getStackTrace()[3];
/*  24: 56 */       String fileInfo = stackTrace.getFileName() + "(" + 
/*  25: 57 */         stackTrace.getLineNumber() + ") " + 
/*  26: 58 */         stackTrace.getMethodName();
/*  27: 59 */       Log.d(tag, fileInfo + ": " + msg);
/*  28:    */     }
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static void i(String tag, String msg)
/*  32:    */   {
/*  33: 70 */     if (sIsLogEnable)
/*  34:    */     {
/*  35: 71 */       StackTraceElement stackTrace = java.lang.Thread.currentThread().getStackTrace()[3];
/*  36: 72 */       String fileInfo = stackTrace.getFileName() + "(" + 
/*  37: 73 */         stackTrace.getLineNumber() + ") " + 
/*  38: 74 */         stackTrace.getMethodName();
/*  39: 75 */       Log.i(tag, fileInfo + ": " + msg);
/*  40:    */     }
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static void e(String tag, String msg)
/*  44:    */   {
/*  45: 86 */     if (sIsLogEnable)
/*  46:    */     {
/*  47: 87 */       StackTraceElement stackTrace = java.lang.Thread.currentThread().getStackTrace()[3];
/*  48: 88 */       String fileInfo = stackTrace.getFileName() + "(" + 
/*  49: 89 */         stackTrace.getLineNumber() + ") " + 
/*  50: 90 */         stackTrace.getMethodName();
/*  51: 91 */       Log.e(tag, fileInfo + ": " + msg);
/*  52:    */     }
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static void w(String tag, String msg)
/*  56:    */   {
/*  57:102 */     if (sIsLogEnable)
/*  58:    */     {
/*  59:103 */       StackTraceElement stackTrace = java.lang.Thread.currentThread().getStackTrace()[3];
/*  60:104 */       String fileInfo = stackTrace.getFileName() + "(" + 
/*  61:105 */         stackTrace.getLineNumber() + ") " + 
/*  62:106 */         stackTrace.getMethodName();
/*  63:107 */       Log.w(tag, fileInfo + ": " + msg);
/*  64:    */     }
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static void v(String tag, String msg)
/*  68:    */   {
/*  69:118 */     if (sIsLogEnable)
/*  70:    */     {
/*  71:119 */       StackTraceElement stackTrace = java.lang.Thread.currentThread().getStackTrace()[3];
/*  72:120 */       String fileInfo = stackTrace.getFileName() + "(" + 
/*  73:121 */         stackTrace.getLineNumber() + ") " + 
/*  74:122 */         stackTrace.getMethodName();
/*  75:123 */       Log.v(tag, fileInfo + ": " + msg);
/*  76:    */     }
/*  77:    */   }
/*  78:    */   
/*  79:    */   public static String getStackTraceMsg()
/*  80:    */   {
/*  81:133 */     StackTraceElement stackTrace = java.lang.Thread.currentThread().getStackTrace()[3];
/*  82:134 */     String fileInfo = stackTrace.getFileName() + "(" + 
/*  83:135 */       stackTrace.getLineNumber() + ") " + 
/*  84:136 */       stackTrace.getMethodName();
/*  85:137 */     return fileInfo;
/*  86:    */   }
/*  87:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.utils.LogUtil
 * JD-Core Version:    0.7.0.1
 */