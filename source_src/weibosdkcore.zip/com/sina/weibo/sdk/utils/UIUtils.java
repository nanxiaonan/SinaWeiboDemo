/*  1:   */ package com.sina.weibo.sdk.utils;
/*  2:   */ 
/*  3:   */ import android.app.AlertDialog;
/*  4:   */ import android.app.AlertDialog.Builder;
/*  5:   */ import android.content.Context;
/*  6:   */ import android.widget.Toast;
/*  7:   */ 
/*  8:   */ public class UIUtils
/*  9:   */ {
/* 10:   */   public static void showAlert(Context context, String title, String text)
/* 11:   */   {
/* 12:40 */     if (context != null) {
/* 13:45 */       new AlertDialog.Builder(context).setTitle(title).setMessage(text).create().show();
/* 14:   */     }
/* 15:   */   }
/* 16:   */   
/* 17:   */   public static void showAlert(Context context, int titleId, int textId)
/* 18:   */   {
/* 19:57 */     if (context != null) {
/* 20:58 */       showAlert(context, context.getString(titleId), context.getString(textId));
/* 21:   */     }
/* 22:   */   }
/* 23:   */   
/* 24:   */   public static void showToast(Context context, int resId, int duration)
/* 25:   */   {
/* 26:70 */     if (context != null) {
/* 27:71 */       Toast.makeText(context, resId, duration).show();
/* 28:   */     }
/* 29:   */   }
/* 30:   */   
/* 31:   */   public static void showToast(Context context, CharSequence text, int duration)
/* 32:   */   {
/* 33:83 */     if (context != null) {
/* 34:84 */       Toast.makeText(context, text, duration).show();
/* 35:   */     }
/* 36:   */   }
/* 37:   */   
/* 38:   */   public static void showToastInCenter(Context context, int resId, int duration)
/* 39:   */   {
/* 40:96 */     if (context != null)
/* 41:   */     {
/* 42:97 */       Toast toast = Toast.makeText(context, resId, duration);
/* 43:98 */       toast.setGravity(17, 0, 0);
/* 44:99 */       toast.show();
/* 45:   */     }
/* 46:   */   }
/* 47:   */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.utils.UIUtils
 * JD-Core Version:    0.7.0.1
 */