/*   1:    */ package com.sina.weibo.sdk.utils;
/*   2:    */ 
/*   3:    */ import android.content.Context;
/*   4:    */ import android.graphics.Bitmap;
/*   5:    */ import android.graphics.Bitmap.CompressFormat;
/*   6:    */ import android.graphics.Bitmap.Config;
/*   7:    */ import android.graphics.BitmapFactory;
/*   8:    */ import android.graphics.BitmapFactory.Options;
/*   9:    */ import android.graphics.Canvas;
/*  10:    */ import android.graphics.Matrix;
/*  11:    */ import android.graphics.Paint;
/*  12:    */ import android.net.ConnectivityManager;
/*  13:    */ import android.net.NetworkInfo;
/*  14:    */ import android.text.TextUtils;
/*  15:    */ import java.io.File;
/*  16:    */ import java.io.FileInputStream;
/*  17:    */ import java.io.FileNotFoundException;
/*  18:    */ import java.io.FileOutputStream;
/*  19:    */ import java.io.IOException;
/*  20:    */ 
/*  21:    */ public class ImageUtils
/*  22:    */ {
/*  23:    */   private static void revitionImageSizeHD(String picfile, int size, int quality)
/*  24:    */     throws IOException
/*  25:    */   {
/*  26: 51 */     if (size <= 0) {
/*  27: 52 */       throw new IllegalArgumentException("size must be greater than 0!");
/*  28:    */     }
/*  29: 54 */     if (!isFileExisted(picfile)) {
/*  30: 55 */       throw new FileNotFoundException(picfile == null ? "null" : picfile);
/*  31:    */     }
/*  32: 58 */     if (!BitmapHelper.verifyBitmap(picfile)) {
/*  33: 59 */       throw new IOException("");
/*  34:    */     }
/*  35: 62 */     int photoSizesOrg = 2 * size;
/*  36: 63 */     FileInputStream input = new FileInputStream(picfile);
/*  37: 64 */     BitmapFactory.Options opts = new BitmapFactory.Options();
/*  38: 65 */     opts.inJustDecodeBounds = true;
/*  39: 66 */     BitmapFactory.decodeStream(input, null, opts);
/*  40:    */     try
/*  41:    */     {
/*  42: 68 */       input.close();
/*  43:    */     }
/*  44:    */     catch (Exception e1)
/*  45:    */     {
/*  46: 70 */       e1.printStackTrace();
/*  47:    */     }
/*  48: 73 */     int rate = 0;
/*  49: 74 */     for (int i = 0;; i++) {
/*  50: 75 */       if ((opts.outWidth >> i <= photoSizesOrg) && (opts.outHeight >> i <= photoSizesOrg))
/*  51:    */       {
/*  52: 76 */         rate = i;
/*  53: 77 */         break;
/*  54:    */       }
/*  55:    */     }
/*  56: 81 */     opts.inSampleSize = ((int)Math.pow(2.0D, rate));
/*  57: 82 */     opts.inJustDecodeBounds = false;
/*  58:    */     
/*  59: 84 */     Bitmap temp = safeDecodeBimtapFile(picfile, opts);
/*  60: 86 */     if (temp == null) {
/*  61: 87 */       throw new IOException("Bitmap decode error!");
/*  62:    */     }
/*  63: 90 */     deleteDependon(picfile);
/*  64: 91 */     makesureFileExist(picfile);
/*  65:    */     
/*  66: 93 */     int org = temp.getWidth() > temp.getHeight() ? temp.getWidth() : temp.getHeight();
/*  67: 94 */     float rateOutPut = size / org;
/*  68: 96 */     if (rateOutPut < 1.0F)
/*  69:    */     {
/*  70:    */       for (;;)
/*  71:    */       {
/*  72:    */         try
/*  73:    */         {
/*  74:100 */           outputBitmap = Bitmap.createBitmap((int)(temp.getWidth() * rateOutPut), 
/*  75:101 */             (int)(temp.getHeight() * rateOutPut), Bitmap.Config.ARGB_8888);
/*  76:    */         }
/*  77:    */         catch (OutOfMemoryError e)
/*  78:    */         {
/*  79:    */           Bitmap outputBitmap;
/*  80:104 */           System.gc();
/*  81:105 */           rateOutPut = (float)(rateOutPut * 0.8D);
/*  82:    */         }
/*  83:    */       }
/*  84:    */       Bitmap outputBitmap;
/*  85:108 */       if (outputBitmap == null) {
/*  86:109 */         temp.recycle();
/*  87:    */       }
/*  88:111 */       Canvas canvas = new Canvas(outputBitmap);
/*  89:112 */       Matrix matrix = new Matrix();
/*  90:113 */       matrix.setScale(rateOutPut, rateOutPut);
/*  91:114 */       canvas.drawBitmap(temp, matrix, new Paint());
/*  92:115 */       temp.recycle();
/*  93:116 */       temp = outputBitmap;
/*  94:    */     }
/*  95:118 */     FileOutputStream output = new FileOutputStream(picfile);
/*  96:119 */     if ((opts != null) && (opts.outMimeType != null) && (opts.outMimeType.contains("png"))) {
/*  97:120 */       temp.compress(Bitmap.CompressFormat.PNG, quality, output);
/*  98:    */     } else {
/*  99:122 */       temp.compress(Bitmap.CompressFormat.JPEG, quality, output);
/* 100:    */     }
/* 101:    */     try
/* 102:    */     {
/* 103:125 */       output.close();
/* 104:    */     }
/* 105:    */     catch (Exception e)
/* 106:    */     {
/* 107:127 */       e.printStackTrace();
/* 108:    */     }
/* 109:130 */     temp.recycle();
/* 110:    */   }
/* 111:    */   
/* 112:    */   private static void revitionImageSize(String picfile, int size, int quality)
/* 113:    */     throws IOException
/* 114:    */   {
/* 115:141 */     if (size <= 0) {
/* 116:142 */       throw new IllegalArgumentException("size must be greater than 0!");
/* 117:    */     }
/* 118:145 */     if (!isFileExisted(picfile)) {
/* 119:146 */       throw new FileNotFoundException(picfile == null ? "null" : picfile);
/* 120:    */     }
/* 121:149 */     if (!BitmapHelper.verifyBitmap(picfile)) {
/* 122:150 */       throw new IOException("");
/* 123:    */     }
/* 124:153 */     FileInputStream input = new FileInputStream(picfile);
/* 125:154 */     BitmapFactory.Options opts = new BitmapFactory.Options();
/* 126:155 */     opts.inJustDecodeBounds = true;
/* 127:156 */     BitmapFactory.decodeStream(input, null, opts);
/* 128:    */     try
/* 129:    */     {
/* 130:158 */       input.close();
/* 131:    */     }
/* 132:    */     catch (Exception e)
/* 133:    */     {
/* 134:160 */       e.printStackTrace();
/* 135:    */     }
/* 136:163 */     int rate = 0;
/* 137:164 */     for (int i = 0;; i++) {
/* 138:165 */       if ((opts.outWidth >> i <= size) && (opts.outHeight >> i <= size))
/* 139:    */       {
/* 140:166 */         rate = i;
/* 141:167 */         break;
/* 142:    */       }
/* 143:    */     }
/* 144:171 */     opts.inSampleSize = ((int)Math.pow(2.0D, rate));
/* 145:172 */     opts.inJustDecodeBounds = false;
/* 146:    */     
/* 147:174 */     Bitmap temp = safeDecodeBimtapFile(picfile, opts);
/* 148:176 */     if (temp == null) {
/* 149:177 */       throw new IOException("Bitmap decode error!");
/* 150:    */     }
/* 151:180 */     deleteDependon(picfile);
/* 152:181 */     makesureFileExist(picfile);
/* 153:182 */     FileOutputStream output = new FileOutputStream(picfile);
/* 154:183 */     if ((opts != null) && (opts.outMimeType != null) && (opts.outMimeType.contains("png"))) {
/* 155:184 */       temp.compress(Bitmap.CompressFormat.PNG, quality, output);
/* 156:    */     } else {
/* 157:186 */       temp.compress(Bitmap.CompressFormat.JPEG, quality, output);
/* 158:    */     }
/* 159:    */     try
/* 160:    */     {
/* 161:189 */       output.close();
/* 162:    */     }
/* 163:    */     catch (Exception e)
/* 164:    */     {
/* 165:191 */       e.printStackTrace();
/* 166:    */     }
/* 167:193 */     temp.recycle();
/* 168:    */   }
/* 169:    */   
/* 170:    */   public static boolean revitionPostImageSize(Context context, String picfile)
/* 171:    */   {
/* 172:    */     try
/* 173:    */     {
/* 174:207 */       if (NetworkHelper.isWifiValid(context)) {
/* 175:208 */         revitionImageSizeHD(picfile, 1600, 75);
/* 176:    */       } else {
/* 177:210 */         revitionImageSize(picfile, 1024, 75);
/* 178:    */       }
/* 179:213 */       return true;
/* 180:    */     }
/* 181:    */     catch (IOException e)
/* 182:    */     {
/* 183:215 */       e.printStackTrace();
/* 184:    */     }
/* 185:217 */     return false;
/* 186:    */   }
/* 187:    */   
/* 188:    */   private static Bitmap safeDecodeBimtapFile(String bmpFile, BitmapFactory.Options opts)
/* 189:    */   {
/* 190:229 */     BitmapFactory.Options optsTmp = opts;
/* 191:230 */     if (optsTmp == null)
/* 192:    */     {
/* 193:231 */       optsTmp = new BitmapFactory.Options();
/* 194:232 */       optsTmp.inSampleSize = 1;
/* 195:    */     }
/* 196:235 */     Bitmap bmp = null;
/* 197:236 */     FileInputStream input = null;
/* 198:    */     
/* 199:238 */     int MAX_TRIAL = 5;
/* 200:239 */     for (int i = 0; i < 5;) {
/* 201:    */       try
/* 202:    */       {
/* 203:241 */         input = new FileInputStream(bmpFile);
/* 204:242 */         bmp = BitmapFactory.decodeStream(input, null, opts);
/* 205:    */         try
/* 206:    */         {
/* 207:244 */           input.close();
/* 208:    */         }
/* 209:    */         catch (IOException e)
/* 210:    */         {
/* 211:246 */           e.printStackTrace();
/* 212:    */         }
/* 213:239 */         i++;
/* 214:    */       }
/* 215:    */       catch (OutOfMemoryError e)
/* 216:    */       {
/* 217:250 */         e.printStackTrace();
/* 218:251 */         optsTmp.inSampleSize *= 2;
/* 219:    */         try
/* 220:    */         {
/* 221:253 */           input.close();
/* 222:    */         }
/* 223:    */         catch (IOException e1)
/* 224:    */         {
/* 225:255 */           e1.printStackTrace();
/* 226:    */         }
/* 227:    */       }
/* 228:    */       catch (FileNotFoundException e) {}
/* 229:    */     }
/* 230:262 */     return bmp;
/* 231:    */   }
/* 232:    */   
/* 233:    */   private static void delete(File file)
/* 234:    */   {
/* 235:271 */     if ((file != null) && (file.exists()) && (!file.delete())) {
/* 236:272 */       throw new RuntimeException(file.getAbsolutePath() + " doesn't be deleted!");
/* 237:    */     }
/* 238:    */   }
/* 239:    */   
/* 240:    */   private static boolean deleteDependon(String filepath)
/* 241:    */   {
/* 242:283 */     if (TextUtils.isEmpty(filepath)) {
/* 243:284 */       return false;
/* 244:    */     }
/* 245:285 */     File file = new File(filepath);
/* 246:286 */     int retryCount = 1;int maxRetryCount = 0;
/* 247:287 */     maxRetryCount = maxRetryCount < 1 ? 5 : maxRetryCount;
/* 248:288 */     boolean isDeleted = false;
/* 249:289 */     if (file != null) {
/* 250:    */       do
/* 251:    */       {
/* 252:290 */         if ((goto 56) && 
/* 253:291 */           (!(isDeleted = file.delete()))) {
/* 254:292 */           retryCount++;
/* 255:    */         }
/* 256:290 */       } while ((!isDeleted) && (retryCount <= maxRetryCount) && (file.isFile()) && (file.exists()));
/* 257:    */     }
/* 258:295 */     return isDeleted;
/* 259:    */   }
/* 260:    */   
/* 261:    */   private static boolean isFileExisted(String filepath)
/* 262:    */   {
/* 263:304 */     if (TextUtils.isEmpty(filepath)) {
/* 264:305 */       return false;
/* 265:    */     }
/* 266:306 */     File file = new File(filepath);
/* 267:307 */     if ((file != null) && (file.exists())) {
/* 268:308 */       return true;
/* 269:    */     }
/* 270:310 */     return false;
/* 271:    */   }
/* 272:    */   
/* 273:    */   private static boolean isParentExist(File file)
/* 274:    */   {
/* 275:319 */     if (file == null) {
/* 276:320 */       return false;
/* 277:    */     }
/* 278:322 */     File parent = file.getParentFile();
/* 279:323 */     if ((parent != null) && (!parent.exists()))
/* 280:    */     {
/* 281:324 */       if ((!file.exists()) && (!file.mkdirs())) {
/* 282:325 */         return false;
/* 283:    */       }
/* 284:327 */       return true;
/* 285:    */     }
/* 286:330 */     return false;
/* 287:    */   }
/* 288:    */   
/* 289:    */   private static void makesureFileExist(String filePath)
/* 290:    */   {
/* 291:339 */     if (filePath == null) {
/* 292:340 */       return;
/* 293:    */     }
/* 294:341 */     File file = new File(filePath);
/* 295:342 */     if ((file != null) && (!file.exists()) && 
/* 296:343 */       (isParentExist(file)))
/* 297:    */     {
/* 298:344 */       if (file.exists()) {
/* 299:345 */         delete(file);
/* 300:    */       }
/* 301:    */       try
/* 302:    */       {
/* 303:347 */         file.createNewFile();
/* 304:    */       }
/* 305:    */       catch (IOException e)
/* 306:    */       {
/* 307:349 */         e.printStackTrace();
/* 308:    */       }
/* 309:    */     }
/* 310:    */   }
/* 311:    */   
/* 312:    */   public static boolean isWifi(Context mContext)
/* 313:    */   {
/* 314:361 */     ConnectivityManager connectivityManager = (ConnectivityManager)mContext
/* 315:362 */       .getSystemService("connectivity");
/* 316:363 */     NetworkInfo activeNetInfo = connectivityManager.getActiveNetworkInfo();
/* 317:364 */     if ((activeNetInfo != null) && (activeNetInfo.getType() == 1)) {
/* 318:365 */       return true;
/* 319:    */     }
/* 320:367 */     return false;
/* 321:    */   }
/* 322:    */ }


/* Location:           F:\android\weibo_android_sdk-master\weibo_android_sdk-master\weibosdkcore.jar
 * Qualified Name:     com.sina.weibo.sdk.utils.ImageUtils
 * JD-Core Version:    0.7.0.1
 */